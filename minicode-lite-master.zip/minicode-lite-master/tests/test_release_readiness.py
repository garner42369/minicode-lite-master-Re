"""Day 30：发布就绪的契约测试。"""

from minicode.release_readiness import (
    ReleaseCheck,
    classify_provider_outcome,
    summarize_release_status,
)


class TestClassifyProviderOutcome:
    def test_answered(self):
        outcome, _ = classify_provider_outcome(exit_code=0, stdout="OK", stderr="")
        assert outcome == "answered"
        print(f"\nanswered")

    def test_provider_outage(self):
        outcome, _ = classify_provider_outcome(exit_code=1, stdout="", stderr="provider availability failure")
        assert outcome == "provider_outage"
        print(f"\nprovider_outage")

    def test_empty_output(self):
        outcome, _ = classify_provider_outcome(exit_code=0, stdout="empty response", stderr="")
        assert outcome == "empty_output"
        print(f"\nempty_output")


class TestSummarizeStatus:
    def _check(self, status: str):
        return ReleaseCheck("x", "cmd", 0 if status == "passed" else 1, status, "summary")

    def test_blocked_on_local_failure(self):
        status = summarize_release_status(
            compile_check=self._check("failed"),
            test_check=self._check("passed"),
            smoke_checks=[],
            provider_outcomes=[],
        )
        assert status == "blocked"
        print(f"\n本地失败 → blocked")

    def test_at_risk_on_provider_outage(self):
        status = summarize_release_status(
            compile_check=self._check("passed"),
            test_check=self._check("passed"),
            smoke_checks=[],
            provider_outcomes=["answered", "provider_outage"],
        )
        assert status == "at-risk"
        print(f"\nProvider 阻塞 → at-risk")

    def test_pass(self):
        status = summarize_release_status(
            compile_check=self._check("passed"),
            test_check=self._check("passed"),
            smoke_checks=[],
            provider_outcomes=["answered"],
        )
        assert status == "pass"
        print(f"\n全通过 → pass")
