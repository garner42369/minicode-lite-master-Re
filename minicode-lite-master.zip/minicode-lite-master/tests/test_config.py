"""Day 3：配置合并、校验与脱敏的离线测试。"""

from minicode.config import (
    RuntimeConfig,
    load_runtime_config,
    merge_config,
    safe_snapshot,
    validate_config,
)


# ---- merge_config：合并优先级与过滤 ----

def test_merge_config_overrides_known_fields():
    base = RuntimeConfig()
    merged = merge_config(base, model="demo-model", api_key="secret-1234")
    assert merged.model == "demo-model"
    assert merged.api_key == "secret-1234"


def test_merge_config_ignores_unknown_fields():
    base = RuntimeConfig()
    merged = merge_config(base, not_a_field="x")
    assert merged == base  # 未知字段被忽略，配置不变


def test_merge_config_skips_none_and_empty():
    base = RuntimeConfig(model="demo-model", api_key="keep-me")
    merged = merge_config(base, model=None, api_key="")
    assert merged.model == "demo-model"  # None 不覆盖
    assert merged.api_key == "keep-me"   # 空串不覆盖


def test_merge_config_is_pure():
    base = RuntimeConfig()
    merged = merge_config(base, model="demo-model")
    assert base.model == "mock"  # 原对象不被改动
    assert merged is not base    # 返回新对象


# ---- validate_config：校验 ----

def test_validate_mock_passes_without_api_key():
    # mock 模式不需要凭据
    assert validate_config(RuntimeConfig(model="mock")) == []


def test_validate_real_model_requires_api_key():
    errors = validate_config(RuntimeConfig(model="claude-sonnet-4", api_key=""))
    assert any("api_key" in e for e in errors)


def test_validate_bad_base_url():
    errors = validate_config(RuntimeConfig(base_url="not-a-url"))
    assert any("base_url" in e for e in errors)


def test_validate_good_base_url_passes():
    config = RuntimeConfig(model="mock", base_url="https://api.example.com")
    assert validate_config(config) == []


# ---- safe_snapshot：脱敏 ----

def test_safe_snapshot_masks_api_key():
    config = RuntimeConfig(model="demo-model", api_key="secret-1234")
    snap = safe_snapshot(config)
    assert "secret-1234" not in str(snap)  # 完整密钥不得出现在快照里
    assert snap["api_key"] == "***1234"    # 只保留末四位


def test_safe_snapshot_no_key_shows_not_set():
    assert safe_snapshot(RuntimeConfig())["api_key"] == "not set"


# ---- load_runtime_config：从环境变量加载 ----

def test_load_runtime_config_defaults_to_mock():
    config = load_runtime_config(env={})
    assert config.model == "mock"
    assert config.api_key == ""


def test_load_runtime_config_reads_env():
    config = load_runtime_config(env={
        "MINI_CODE_MODEL": "demo-model",
        "MINI_CODE_API_KEY": "secret-1234",
        "MINI_CODE_BASE_URL": "https://api.example.com",
    })
    assert config.model == "demo-model"
    assert config.api_key == "secret-1234"
    assert config.base_url == "https://api.example.com"
