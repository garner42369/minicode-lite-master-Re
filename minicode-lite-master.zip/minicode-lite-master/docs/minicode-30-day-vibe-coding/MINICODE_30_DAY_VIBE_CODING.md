# MiniCode Python：30 天 Vibe Coding 完整复现课程

## 0. 这门课真正要复现什么

MiniCode 不是“给大模型套一个终端输入框”，而是一套本地 Agent Runtime。大模型只负责提出下一步；运行时负责把下一步变成受约束、可观察、可恢复、可验证的动作。

完整链路是：

```mermaid
flowchart LR
    U[用户任务] --> E[CLI / Headless / TUI]
    E --> P[配置与 Prompt]
    P --> L[Agent Loop]
    L --> M[Model Adapter]
    M -->|文本或 Tool Call| L
    L --> G[权限与策略门]
    G --> T[Tool Registry]
    T --> F[文件 / 搜索 / Shell / MCP / 子任务]
    F -->|ToolResult| L
    L --> V[Turn Kernel 与验证门槛]
    L --> C[上下文与记忆]
    L --> S[Session / Checkpoint / Rewind]
    V --> E
    C --> L
    S --> L
```

这张图里最重要的分工是：

- **Model Adapter** 翻译协议，不决定权限；
- **Agent Loop** 编排一轮工作，不直接读写文件；
- **Tool** 执行动作，不决定“任务是否完成”；
- **Permission** 决定动作是否被授权，不负责实际执行；
- **Turn Kernel** 维护阶段、预算、停止原因和验证要求；
- **Session** 保存可恢复状态，但回放不能重放副作用；
- **Context/Memory** 决定哪些信息进入下一次模型请求；
- **TUI/Headless** 是同一运行时的不同消费者，不是两套业务逻辑。

### 0.1 三层完成标准

| 层 | 含义 | 判断标准 |
| --- | --- | --- |
| 行为复现 | 用户能看到同类能力 | 能读、改、跑、恢复、扩展、评估 |
| 架构复现 | 能力通过清晰边界协作 | UI 不侵入 Loop，工具不绕过权限，Provider 不污染核心协议 |
| 工程复现 | 失败时仍可控 | 错误分类、预算停止、日志、测试、CI、回退范围明确 |

不要追求逐行复刻。参考项目中有大量演进痕迹和研究模块；真正的学习成果是你能用自己的实现达到同等职责覆盖，并解释每一层为何存在。

### 0.2 每天的固定 Vibe Coding 节奏

每天按同一闭环推进：

1. **先讲行为**：用一句话写出今天用户多了什么能力。
2. **再画数据流**：只画今天涉及的输入、输出和调用方向。
3. **向 AI 提一个小任务**：限定模块、接口、失败分支和验收命令。
4. **先跑失败证据**：测试或手工 Demo 必须先证明功能尚不存在。
5. **实现最小纵切片**：不是把整个模块写满，而是先让一条路径跑通。
6. **补边界和错误**：围绕真实失败方式补测试。
7. **接回主链路**：单测通过不代表已完成，必须从入口触发一次。
8. **用自己的话复盘**：讲清“模块作用”和“为什么放在这里”。

### 0.3 建议贯穿全程的演示仓库

在复现仓库之外创建 `fixtures/buggy_calculator/`：

```text
buggy_calculator/
  calculator.py       # divide(a, b) 错把 / 写成 //
  formatter.py        # 输出格式函数
  tests/
    test_calculator.py
  README.md            # 测试命令与约束
```

它会反复承担不同角色：只读解释、失败测试、受控编辑、Checkpoint、Rewind、上下文压缩、记忆召回、Headless 和最终评估。使用同一个小仓库能让你看到运行时能力是怎样逐层叠加的。

---

# 第一阶段：从产品定义到离线 Agent（Day 1–8）

## Day 1：冻结产品边界，画出真正的主链路

代码参照：[day01_product_contract.py](daily_code/day01_product_contract.py)

### 今天解决什么问题

先避免一个常见失败：一开始就照着 130 个模块建空文件，最后拥有目录结构，却没有可用产品。今天只定义“MiniCode 是什么、第一版不是什么、成功如何证明”。

### 参考内容

- `README.zh-CN.md`
- `docs/VIBE_CODING_WORKFLOW.zh-CN.md` 的 S00、验收矩阵
- `docs/STRUCTURE.md`
- `pyproject.toml`

### 必须理解的作用

MiniCode 的核心用户故事不是聊天，而是：

```text
用户要求修复失败测试
→ Agent 找到测试和实现
→ 运行测试取得失败证据
→ 申请并实施最小修改
→ 再次运行测试
→ 以实际结果结束，而不是以模型口头声明结束
```

今天建立四份活文档：

| 文档 | 作用 | 不应写成什么 |
| --- | --- | --- |
| `PRODUCT_SPEC.md` | 产品边界与用户故事 | 功能愿望清单 |
| `ARCHITECTURE.md` | 层次、依赖方向、核心协议 | 文件名堆砌 |
| `TASKS.md` | 可验收的开发单元 | “继续优化”之类模糊任务 |
| `DECISIONS.md` | 有代价的选择及复查条件 | 每次改代码的流水账 |

### 今日 Demo

先不写 Agent。只做 `buggy_calculator`，运行测试并稳定得到一个失败。然后在 `PRODUCT_SPEC.md` 写清：最终 MiniCode 要自动完成这条修复路径，但 Day 1 的系统尚不能做。

### 实现顺序

1. 建立独立复现仓库和 Git。
2. 建立四份文档。
3. 建立演示仓库与确定性失败测试。
4. 定义四种停止结果：成功、失败、等待用户、预算耗尽。
5. 画出“入口 → Loop → Model/Tools → 验证”的依赖图。
6. 写下暂缓项：TUI、MCP、向量检索、控制论均不能阻塞 V0。

### 验收证据

- 演示仓库测试稳定失败，失败原因就是预设缺陷。
- 你能回答“哪个命令证明最终修复成功”。
- 架构图中没有让 `tool` 直接调用 UI，也没有让 Provider 直接写文件。

### 给 AI 的任务提示词

```text
当前阶段 Day 1。请只建立产品说明、架构说明、任务清单、设计决策记录，
并创建一个带确定性失败测试的 buggy_calculator fixture。
不要实现 Agent、模型调用或文件工具。
每个用户故事写出输入、可观察行为、失败分支和验收命令。
完成后运行 fixture 测试，确认它因预设缺陷失败，而不是环境错误。
```

### 今日易错点

“设计完整”不等于把未来所有类都画出来。今天只冻结依赖方向和用户行为；具体接口会在出现真实调用方时确定。

---

## Day 2：包骨架与统一协议——让所有层说同一种语言

代码参照：[day02_protocols.py](daily_code/day02_protocols.py)

### 今天解决什么问题

模型、工具、Loop 和 UI 如果各用一套字典结构，后续每加一个 Provider 都会修改核心循环。今天建立系统中唯一的消息和动作协议。

### 参考模块

- `types.py`：`ChatMessage`、`ToolCall`、`AgentStep`、`RuntimeEvent`、`ModelAdapter`
- `tooling.py`：`ToolResult`、`ToolContext`、`ToolDefinition`
- `pyproject.toml`：包和入口

### 模块作用，而不是源码清单

`types.py` 是系统的“共同语言”。它不执行业务，只规定：

- 历史消息有哪些角色；
- 模型下一步是最终文本、进度文本还是工具请求；
- 一次工具调用怎样用 ID 与结果配对；
- 运行时怎样向 UI 发出结构化事件；
- 一个模型适配器最少要实现什么方法。

`ToolResult` 则是动作执行后的统一回执。即使工具内部抛异常，Loop 最终也应收到一个可处理的结果。

### 最小协议示意

```python
@dataclass(slots=True)
class AgentStep:
    type: Literal["assistant", "tool_calls"]
    content: str = ""
    kind: Literal["final", "progress"] | None = None
    calls: list[ToolCall] = field(default_factory=list)

class ModelAdapter(Protocol):
    def next(self, messages: list[ChatMessage], on_stream_chunk=None) -> AgentStep: ...
```

重点不在字段拼写，而在三个约束：

1. Provider 的原始 JSON 不离开 Adapter；
2. Tool Call 必须有稳定 ID；
3. 进度和最终回答必须可区分，否则 Loop 会在进度播报后错误结束。

### 今日 Demo

写一个只返回 `AgentStep(type="assistant", content="hello")` 的假 Adapter。入口创建消息，调用一次 Adapter，再把结果打印成 JSON。它还不是 Agent Loop，但协议已经贯通。

### 实现顺序

1. 建立 `pyproject.toml`、`minicode/__init__.py`、`tests/`。
2. 定义消息、工具调用、模型步骤和停止结果。
3. 定义 `ModelAdapter` Protocol。
4. 定义 `ToolResult` 和 `ToolContext`，暂不实现注册表。
5. 写类型构造、序列化和工具调用 ID 配对测试。

### 验收证据

- `python -m compileall -q minicode tests` 通过。
- 离线测试不读取 `.env`、不访问网络。
- 仓库中只有一个 `AgentStep` 定义；Provider 不自造第二套返回类型。

### 给 AI 的任务提示词

```text
当前阶段 Day 2。建立最小可安装 Python 3.11 包和统一核心协议。
只实现 types.py、tooling.py 中的数据协议和一个最小入口测试。
模型响应必须统一成 assistant 或 tool_calls；工具调用和结果用 ID 配对。
不要实现真实 Provider、文件工具、权限或完整循环。
请说明每个字段由谁产生、谁消费，再写实现和离线测试。
```

### 今日易错点

不要把“最终运行结果”和“模型返回文本”混为一谈。模型可以返回“完成”，运行时仍可能把任务判定为“未验证”。这一差异会在 Day 14 落实。

---

## Day 3：配置、日志与入口——把启动失败变成可诊断信息

代码参照：[day03_config_and_logging.py](daily_code/day03_config_and_logging.py)

### 今天解决什么问题

Agent 的大量“功能故障”实际是配置优先级、缺失凭据或编码问题。今天让程序在没有模型、配置错误和不同启动方式下都能给出确定结果。

### 参考模块

- `config.py`：设置合并、Provider 运行配置、MCP scope、诊断
- `logging_config.py`：轮转日志、结构化日志、API/工具/权限/会话事件
- `install.py`：启动器与 PATH
- `main.py`、`headless.py`：两个入口的职责边界
- `.env.example`、`pyproject.toml`

### 模块作用

`config.py` 不是“到处读取环境变量”的工具箱，而应形成一份有效运行配置：

```text
默认值
  ← 用户级 settings
  ← 项目级 settings
  ← .env / 环境变量
  ← 本次 CLI 参数
  = Effective Runtime Config
```

越靠近本次运行的配置优先级越高，但密钥不能写回项目文件。`logging_config.py` 负责记录事实，不负责吞掉异常；日志中不能出现完整 Token。

入口分工：

- `main.py` 处理人机交互、会话管理命令和 TTY 选择；
- `headless.py` 处理单轮非交互执行和机器可读退出；
- 二者只组装依赖，业务最终都调用同一个 Loop。

### 今日 Demo

实现 `minicode-py --validate-config`：

1. 未配置模型时返回明确问题；
2. 配置 Mock 模式时诊断通过；
3. 日志只显示 Provider、模型和 Base URL，不显示密钥。

### 实现顺序

1. 先定义 `RuntimeConfig` 的必需字段和来源说明。
2. 实现纯函数式字典合并，覆盖优先级测试。
3. 实现 Provider 配置校验和脱敏展示。
4. 实现日志初始化与结构化事件 helper。
5. 添加 console scripts，入口暂只支持 `--help`、`--validate-config`。
6. 验证 Windows UTF-8 输入输出重配置。

### 验收证据

- 空环境、Mock 环境、错误 URL、缺失密钥分别有确定输出。
- 运行日志中搜索真实测试密钥，结果为零。
- 可编辑安装后两个入口都能显示帮助。

### 给 AI 的任务提示词

```text
当前阶段 Day 3。实现配置合并、配置诊断、脱敏日志和两个最小命令入口。
配置读取与校验必须可以单测；入口只做依赖装配。
使用假密钥测试日志脱敏。不要连接真实模型，也不要实现 Agent Loop。
完成后验证 editable install、两个 --help 和 --validate-config。
```

### 今日易错点

参考项目当前大量函数返回 `dict`，方便演进但降低类型安全。复现时可以先保持兼容，再在优化章节迁移到不可变 `RuntimeConfig`；不要在首日为了完美配置模型阻塞主链路。

---

## Day 4：Mock Model——用确定性剧本替代昂贵且不稳定的真实模型

代码参照：[day04_scripted_model.py](daily_code/day04_scripted_model.py)

### 今天解决什么问题

没有 Mock Model，Agent Loop 的每个测试都依赖网络、费用和模型随机性。今天建立一个可以精确编排下一步的模型替身。

### 参考模块

- `mock_model.py`
- `types.py` 的 `ModelAdapter`
- `tests/test_mock_model.py`

### 模块作用

参考项目中的 `MockModelAdapter` 会根据 `/ls`、`/read`、`/cmd` 等输入生成工具请求。教学复现建议再抽象一层 `ScriptedModel`：测试传入一个步骤队列，模型每次 `next()` 取下一步。

两种 Mock 各有用途：

| 类型 | 用途 |
| --- | --- |
| 命令式 Mock | 手工演示 `/read file.py` 等快捷行为 |
| 剧本式 Mock | 精确测试“工具 → 结果 → 下一步”的复杂序列 |

### 今日 Demo

编排三步剧本：

```text
第 1 次调用：请求 list_files
第 2 次调用：请求 read_file README.md
第 3 次调用：返回最终总结
```

今天工具还未实现，可以用伪造的工具结果手工推进模型，验证它确实按历史变化进入下一步。

### 最小实现形态

```python
class ScriptedModel:
    def __init__(self, steps: list[AgentStep]):
        self.steps = iter(steps)

    def next(self, messages, on_stream_chunk=None, **kwargs):
        return next(self.steps)
```

真正重要的是测试能检查收到的 `messages`，否则 Mock 只证明自己会弹出队列，不能证明 Loop 回填了正确历史。

### 实现顺序

1. 实现 `ScriptedModel`，保存每次收到的消息快照。
2. 实现命令式 `MockModelAdapter` 作为手工 Demo。
3. 覆盖最终文本、单工具、多工具、进度文本、空响应、异常等剧本。
4. 为步骤耗尽定义明确错误，不要悄悄重复最后一步。

### 验收证据

- 完全离线执行。
- 能断言第二次模型调用已看到第一次工具结果。
- 固定剧本运行 100 次结果一致。

### 给 AI 的任务提示词

```text
当前阶段 Day 4。实现 ScriptedModel 和用于手工体验的 MockModelAdapter。
ScriptedModel 必须记录每次收到的消息快照，并在剧本耗尽时明确失败。
覆盖最终文本、工具请求、进度、空响应和模型异常。
暂不实现工具和主循环，只验证模型协议替身可靠。
```

### 今日易错点

Mock 的目标不是“模拟模型的聪明程度”，而是控制状态迁移。越确定、越笨的 Mock，越适合验证 Runtime。

---

## Day 5：Tool Registry——把模型的意图变成受控函数调用

代码参照：[day05_tool_registry.py](daily_code/day05_tool_registry.py)

### 今天解决什么问题

模型只能产生结构化意图，不能直接调用 Python 函数。今天建立工具注册、参数校验、异常归一化和输出预算这一层。

### 参考模块

- `tooling.py`
- `tools/__init__.py`
- `capability_registry.py`（先理解，Day 25 再实现完整能力统计）

### 模块作用

`ToolDefinition` 描述一个工具：名字、说明、输入 Schema、验证器和执行器。`ToolRegistry` 做五件事：

1. 按名字查找；
2. 拒绝未知工具；
3. 在执行前验证输入；
4. 把普通异常转成失败 `ToolResult`；
5. 对过大输出做可解释截断。

它不应做具体权限判断。权限需要使用 `ToolContext.permissions`，由工具或统一执行门在动作发生前检查。

### 工具生命周期

```mermaid
sequenceDiagram
    participant L as Agent Loop
    participant R as ToolRegistry
    participant D as ToolDefinition
    participant X as Tool Implementation
    L->>R: execute(name, raw_input, context)
    R->>D: find + validate
    D->>X: run(parsed_input, context)
    X-->>D: ToolResult
    D-->>R: result
    R-->>L: normalized + truncated result
```

### 今日 Demo

只注册一个 `echo_text` 教学工具。依次触发：成功、缺参数、未知工具、工具内部抛异常、返回 100KB 文本。观察五种情况都以 `ToolResult` 返回，进程不崩溃。

### 最少需要看的源码思想

参考项目的 `ToolRegistry.execute()` 是一个“异常防火墙”。它对验证错误和执行异常分别处理，并保留工具名和简短 Traceback。这里的价值不是大段 `try/except`，而是保证 Agent Loop 永远面对统一结果。

### 实现顺序

1. 实现 `ToolDefinition` 和 O(1) 名称索引。
2. 实现 `execute()` 的查找、验证、执行、异常归一化。
3. 增加 `ToolMetadata`：只读、破坏性、可并发、需审批。
4. 实现按工具类型的输出预算。
5. 实现 `dispose()`，为 Day 24 的 MCP 进程清理留接口。

### 验收证据

- 未知工具和畸形参数不调用 Runner。
- Runner 抛异常不终止会话。
- 截断结果包含原始规模和继续获取的提示。
- `dispose()` 多次调用行为明确。

### 给 AI 的任务提示词

```text
当前阶段 Day 5。实现 ToolDefinition、ToolMetadata、ToolContext、ToolResult 和 ToolRegistry。
Registry 是工具异常防火墙：未知工具、验证失败、执行异常、超大输出都返回结构化结果。
请用 echo_text 教学工具覆盖完整生命周期。
不要实现文件系统工具和权限；只保留 context 接口。
```

### 今日易错点

输出截断必须告诉模型“发生了截断、原始有多大、怎样继续”，否则省下了 Token，却让模型基于不完整内容做出错误结论。

---

## Day 6：工作区边界与只读工具——让 Agent 先学会观察

代码参照：[day06_readonly_tools.py](daily_code/day06_readonly_tools.py)

### 今天解决什么问题

Agent 在修改代码前必须可靠地定位文件。今天只开放读取能力，并建立所有本地工具共用的路径边界。

### 参考模块

- `workspace.py`
- `tools/list_files.py`
- `tools/read_file.py`
- `tools/grep_files.py`
- `tools/file_tree.py`
- `tools/code_nav.py`

### 各模块的作用

| 模块 | 用户能力 | 为什么不合成一个“大文件工具” |
| --- | --- | --- |
| `workspace.py` | 统一解析相对/绝对路径并检查边界 | 安全策略必须只有一个入口 |
| `list_files.py` | 看某一层目录 | 输出小，适合第一步探索 |
| `file_tree.py` | 看层级结构和文件元信息 | 适合项目地图，不适合内容搜索 |
| `read_file.py` | 按 offset/limit 读取文本 | 大文件必须分页 |
| `grep_files.py` | 按正则和 glob 找内容 | 先缩小候选，再读取正文 |
| `code_nav.py` | AST 符号、引用和结构 | 比纯文本更适合代码定位 |

### 路径安全的关键顺序

```text
输入路径
→ 相对 cwd 拼接
→ resolve 得到规范真实路径
→ 对规范路径做边界/权限检查
→ 执行读取
```

如果在 `resolve()` 前只检查字符串前缀，`..`、符号链接或 Windows junction 可能绕过边界。无 `PermissionManager` 时，安全默认值应是禁止逃离工作区。

### 今日 Demo

让 Mock Model 完成一次仓库侦察：

1. `list_files` 查看根目录；
2. `grep_files` 找 `divide`；
3. `read_file` 分页读取实现和测试；
4. 输出“缺陷可能在整数除法”的证据摘要。

此时仍不允许写文件或运行测试。

### 实现顺序

1. 实现 `resolve_tool_path()` 和越界测试。
2. 实现 `list_files`，限制条目数。
3. 实现 `read_file` 的 offset、limit、UTF-8、二进制判断和截断头。
4. 实现 `grep_files` 的跳过目录、二进制扩展、最大文件数和最大命中数。
5. 实现轻量 `file_tree`。
6. 最后加 AST 符号查询；它不是 V0 必需项。

### 验收证据

- 中文路径和中文内容读取正常。
- 不存在、目录误当文件、二进制、错误编码有明确结果。
- `../`、绝对外部路径、指向外部的链接按策略被拒绝。
- 大文件能分页，模型可以根据 `END` 继续读取。

### 给 AI 的任务提示词

```text
当前阶段 Day 6。实现统一工作区路径解析，以及 list_files、read_file、grep_files。
所有文件访问必须先经过 resolve_tool_path。
覆盖不存在、二进制、中文、分页、..、绝对路径和链接绕行。
本阶段只读，不添加任何写入或命令执行能力。
最后用 buggy_calculator 演示“目录 → 搜索 → 分页读取 → 缺陷定位”。
```

### 今日易错点

参考 `read_file` 的短时缓存时要注意：读取失败不能返回空字符串假装成功。缓存属于性能优化，文件不存在和解码失败仍要保留准确错误语义。

---

## Day 7：最小 Agent Loop——真正跑通“模型—工具—模型”闭环

代码参照：[day07_agent_loop.py](daily_code/day07_agent_loop.py)

### 今天解决什么问题

前六天只有零件。今天第一次让模型请求工具、运行时执行工具、结果回填历史、模型再根据结果继续。

### 参考模块

- `agent_loop.py` 的 `run_agent_turn`
- `types.py`
- `tooling.py`
- `tests/test_agent_loop.py`

### 先实现的最小循环

```text
在步数预算内循环：
  调用 model.next(history)
  若返回最终文本：记录并结束
  若返回进度文本：记录，继续
  若返回工具请求：
      对每个调用执行 registry.execute
      追加 assistant_tool_call
      追加同 ID 的 tool_result
      继续调用模型
超出预算：以 max_steps 结束
```

### 为什么工具调用要写入两条历史

一条 `assistant_tool_call` 表示模型要求做了什么；一条 `tool_result` 表示环境实际发生了什么。只有结果没有请求，Provider 无法维持协议；只有请求没有结果，下一轮模型不知道动作是否成功。

### 今日 Demo

把 Day 4 的三步 ScriptedModel 与 Day 6 的只读工具连接起来，真正完成：

```text
用户：解释这个仓库
模型：list_files
运行时：目录结果
模型：read_file calculator.py
运行时：文件内容
模型：最终解释
```

### 实现顺序

1. 复制输入消息，避免意外修改调用方列表。
2. 每轮递增 step，先检查取消和预算。
3. 处理最终文本和进度文本。
4. 顺序执行工具调用。
5. 按 ID 回填请求与结果。
6. 暴露 `on_tool_start`、`on_tool_result`、`on_assistant_message` 回调，但 Loop 不导入 TUI。
7. 统一停止原因：`done`、`max_steps`、`await_user`、`blocked`。

### 验收证据

- 第二次模型调用确实收到第一次工具结果。
- 工具失败也会回填，模型有机会改正。
- 进度消息不会让循环提前结束。
- 达到最大步数时没有额外模型请求。
- 回调关闭时核心行为不变。

### 给 AI 的任务提示词

```text
当前阶段 Day 7。实现最小 run_agent_turn，只支持消息、进度、工具请求、最终回答和最大步数。
每个工具调用必须产生同 ID 的 assistant_tool_call 与 tool_result。
工具失败是可观察结果，不应直接击穿 Loop。
UI 只通过可选回调接收事件，不得被核心模块导入。
用 ScriptedModel 跑通“列目录 → 读文件 → 总结”。
```

### 今日易错点

不要现在就把记忆、控制论、模型路由全部塞进 Loop。先保存一份 100–200 行的可工作的核心版本；后续复杂功能都应能解释为这个闭环前后的附加策略。

---

## Day 8：错误恢复、多工具与调度——让循环在真实世界里不脆弱

代码参照：[day08_tool_scheduler.py](daily_code/day08_tool_scheduler.py)

### 今天解决什么问题

真实模型会请求未知工具、给错参数、返回空响应或一次请求多个工具。今天把“理想循环”升级成可恢复运行时。

### 参考模块

- `agent_intelligence.py`：错误分类、恢复建议、Tool Scheduler
- `agent_metrics.py`：工具历史指标
- `api_retry.py`：网络错误分类思想（Provider 在 Day 10 接入）
- `circuit_breaker.py`：失败熔断思想
- `agent_loop.py` 的 `_execute_single_tool` 和并发工具段

### 各模块为何存在

`agent_intelligence.py` 不取代模型推理，而是把重复的运行时判断确定化：

- 网络错误建议重试；
- 权限错误建议缩小范围或等待用户；
- 资源错误建议减少输出；
- 逻辑错误建议重新检查参数；
- 只读且并发安全的多个工具可以并行；
- 写入和命令必须保持串行，避免副作用竞态。

`agent_metrics.py` 记录工具成功率和耗时，为调度提供证据，而不是凭感觉调并发。

### 今日 Demo

一轮中让 ScriptedModel 同时请求两个 `read_file` 和一个错误的未知工具：

- 两个读取可以并发；
- 未知工具返回结构化错误；
- 结果最终仍按原调用顺序回填；
- 模型根据三个结果给出总结。

### 调度规则

| 工具类别 | 示例 | 执行方式 |
| --- | --- | --- |
| 只读且线程安全 | read、grep、list | 可并发 |
| 有副作用 | write、edit、patch | 串行 |
| 外部进程 | run_command | 默认串行 |
| 等待用户 | ask_user | 执行后立即暂停本轮 |

### 实现顺序

1. 为工具加能力元数据，不依赖名字猜测为主逻辑。
2. 多调用先分为 concurrent 与 serial 两组。
3. 并发执行时捕获每个 Future 的异常。
4. 回填前恢复模型原始调用顺序。
5. 实现空响应有限重试和重复失败停止。
6. 记录工具名、耗时、成功状态和错误类别。
7. 将恢复建议附到工具结果的系统注记，而不是伪装成用户消息。

### 验收证据

- 两个只读慢工具总耗时接近一个工具而不是两倍。
- 写工具从不与另一写工具并发。
- 并发完成顺序不同，回填顺序仍稳定。
- 空响应达到上限后明确停止，没有死循环。
- 一个工具抛异常不会丢失其他调用的结果。

### 给 AI 的任务提示词

```text
当前阶段 Day 8。在现有最小 Loop 上增加多工具调度、错误分类、有限恢复和指标。
只读且声明 concurrency_safe 的工具可以并发；写入、命令和等待用户工具串行。
无论实际完成顺序如何，消息必须按原调用顺序回填。
覆盖未知工具、参数错误、Runner 异常、空响应、重复失败和并发单点失败。
不要接入真实 Provider 或控制论模块。
```

### 阶段复盘

至此你已拥有 V0 离线 Agent。它还不能改代码，但已经具备最重要的可测试闭环。后续所有高级能力都必须保持这条离线路径可用。

---

# 第二阶段：真实模型与安全修改闭环（Day 9–14）

## Day 9：Prompt Pipeline——系统提示词是一份运行时产品快照

代码参照：[day09_prompt_pipeline.py](daily_code/day09_prompt_pipeline.py)

### 今天解决什么问题

Agent 的系统提示词不仅定义语气，还告诉模型 cwd、权限、工具、Skills、MCP、记忆和运行规则。把它写成一个巨型字符串，会导致缓存失效、难测试和动态信息过期。

### 参考模块

- `prompt.py`
- `prompt_pipeline.py`
- `product_surfaces.py`（今天只消费其概念，Day 25 完整实现）
- `user_profile.py`

### 模块作用

`PromptPipeline` 把提示分为：

- **静态前缀**：角色、基本行为、安全约束，可跨轮缓存；
- **动态后缀**：cwd、权限、技能、MCP、记忆、项目指令、readiness，每轮按需重建。

边界标记的目的不是给用户看，而是帮助 Provider 做 Prompt Cache，也让测试能验证动态内容没有混入静态区。

### Prompt 不是授权

提示词里写“不要访问工作区外”只是引导；真正的授权必须在 `PermissionManager` 和工具执行路径中发生。仓库文件、MCP Prompt 或记忆内容即使声称“忽略权限”，也不能改变执行策略。

### 今日 Demo

同一静态前缀下分别构建两次 Prompt：

1. 第一次只有 core tools；
2. 第二次动态增加一个 skill 和一条项目记忆。

验证静态部分 Hash 不变、动态部分变化，模型能看到新能力。

### 实现顺序

1. 实现 `PromptSection` 和静态/动态注册。
2. 实现条件包含与 TTL 缓存。
3. 注入工具使用规则、权限摘要和 cwd。
4. 支持全局与项目指令文件，并记录来源和优先级。
5. 为 Skills、MCP、Memory 预留动态 section。
6. 对 malformed 动态条目容错，单个坏扩展不能让 Prompt 整体构建失败。

### 验收证据

- 动态能力变化后 Prompt 更新。
- 缓存未过期且文件 mtime 未变时不重复读文件。
- 坏 skill/MCP 项只产生诊断，不阻止启动。
- Prompt 中没有真实密钥。

### 给 AI 的任务提示词

```text
当前阶段 Day 9。实现静态前缀 + 动态后缀的 PromptPipeline。
注入 cwd、工具使用约束、权限摘要和可选项目指令；为 Skills/MCP/Memory 保留 section 接口。
Prompt 只能引导，不能替代执行权限。
测试缓存边界、条件 section、文件 mtime 失效、畸形动态条目和密钥不泄漏。
```

### 今日易错点

不要把每轮变化的 Token 用量、当前工具等高频状态全塞进系统 Prompt。高频运行状态应通过消息或事件表达，否则会破坏缓存并制造陈旧信息。

---

## Day 10：真实 Provider——只翻译协议，不接管运行时

代码参照：[day10_provider_adapter.py](daily_code/day10_provider_adapter.py)

### 今天解决什么问题

今天把统一 `ModelAdapter` 连接到一个真实支持 Tool Calling 的服务，并保留 Mock 路径。课程要求先实现一个 Provider，再扩展第二个。

### 参考模块

- `model_registry.py`
- `anthropic_adapter.py`
- `openai_adapter.py`
- `api_retry.py`
- `model_switcher.py`
- `cost_tracker.py`

### 模块作用

| 模块 | 职责 | 不应承担 |
| --- | --- | --- |
| `model_registry.py` | 模型元数据、Provider 检测、Adapter 工厂 | 发 HTTP 请求 |
| `anthropic_adapter.py` | Anthropic 消息/工具格式互转 | 文件权限和任务完成判断 |
| `openai_adapter.py` | OpenAI-compatible 格式互转 | 修改 Agent 历史协议 |
| `api_retry.py` | 错误分类、退避、Retry-After | 无限重试 |
| `model_switcher.py` | 有界 Fallback 与失败通道记录 | 在副作用中途偷偷换模型重放 |
| `cost_tracker.py` | Token/费用事实记录 | 决定用户预算政策 |

### Provider 转换的核心

内部历史保持 `ChatMessage`。Adapter 在请求前转换为 Provider 格式，在响应后转换回 `AgentStep`。Provider 特有的 thinking block、tool call delta 和 usage 只能保存在 Adapter 或明确的诊断字段中。

### 今日 Demo

先用录制/手写响应 fixture 测试：

1. 文本响应变成最终 `AgentStep`；
2. Tool Call 的 JSON 参数分片被完整组装；
3. Tool Result 使用同一个调用 ID 回传；
4. 认证失败、429、超时和畸形响应分类正确。

随后只做一次真实冒烟：让模型调用 `list_files` 和 `read_file` 解释演示仓库。真实测试无凭据时应明确跳过，而不是退回 Mock 并宣称成功。

### 重试原则

- 请求尚未产生工具副作用时，网络类错误可有限重试；
- 认证失败和参数错误不重试；
- 尊重 `Retry-After`，再加指数退避与 jitter；
- 工具已经执行后，不因 Provider 重试而重复执行工具；
- Fallback 模型只在明确的 Provider 可用性错误上尝试，并限制候选和次数。

### 实现顺序

1. 选择一个 Provider，先做非流式请求。
2. 为消息和工具 Schema 写纯转换函数。
3. 用 fixture 覆盖工具请求和错误。
4. 增加流式文本和工具参数拼装。
5. 增加 usage 更新和成本记录。
6. 建立模型注册与工厂。
7. 最后加第二种兼容 Provider 与有界 Fallback。

### 验收证据

- 默认测试不访问网络。
- 无凭据的真实测试显示 SKIP/未配置。
- Tool Call ID 往返不变。
- 日志无密钥、Authorization Header 或完整敏感请求。
- 真实模型成功使用只读工具完成一次解释。

### 给 AI 的任务提示词

```text
当前阶段 Day 10。选择一个我已配置的 Tool Calling Provider，实现 ModelAdapter。
Provider 原始格式只能存在于 Adapter；Loop 和工具协议不修改。
先写消息/工具转换 fixture，再实现非流式 HTTP，最后实现流式分片组装。
分类认证、限流、超时、服务不可用和格式错误；仅对适合的错误有限重试。
默认测试离线，真实冒烟无凭据时明确跳过。
```

### 今日易错点

模型目录中的价格、上下文窗口和模型名会随时间变化。把它们视为可更新配置，不要让正确性依赖某个永远不变的静态表。

---

## Day 11：权限系统——“模型想做”与“程序允许做”之间的硬边界

代码参照：[day11_permissions.py](daily_code/day11_permissions.py)

### 今天解决什么问题

真实模型已经能提出动作，但还不能让它自动修改和执行。今天建立路径、命令、编辑三条授权线，以及 default、auto、plan、bypass 四种运行模式。

### 参考模块

- `permissions.py`
- `auto_mode.py`
- `workspace.py`
- `logging_config.py` 的权限事件

### 权限系统的三个判断对象

| 判断对象 | 典型问题 | 授权最小粒度 |
| --- | --- | --- |
| 路径访问 | 是否允许读/写工作区外文件 | 规范路径 + intent |
| 命令执行 | 是否允许启动该命令 | executable + argv + cwd + 风险原因 |
| 文件编辑 | 是否接受这份具体修改 | 文件路径 + diff + 本轮/永久范围 |

权限不是简单的 True/False。交互式产品至少需要 `allow_once`、`allow_turn`、`allow_always`、`deny_once`、`deny_with_feedback`、`deny_always`。持久授权必须绑定明确 scope，不能因为用户允许写一个文件就放开整个磁盘。

### 四种模式

```text
plan    只读，执行与写入直接阻止
default 每个有副作用动作都询问
auto    明确安全的读取自动通过，中高风险仍询问或阻止
bypass  跳过审批，仅用于用户明确授权的隔离环境
```

### 今日 Demo

使用一个不真正写文件的 `preview_edit` 工具发起审批：

1. plan 模式下被阻止；
2. default 模式展示 diff 后允许一次；
3. deny_with_feedback 把用户原因送回模型；
4. 对工作区外路径单独询问；
5. 危险 shell 片段始终升级风险。

### 为什么正则风险检查不等于沙箱

命令分类只能帮助审批，不能阻止一个“看似安全”的 Python 脚本访问任意系统资源。MiniCode 的权限层是产品安全门，不是 OS 隔离。执行不可信代码时仍需容器、低权限账号或系统沙箱。

### 实现顺序

1. 定义结构化 `PermissionRequest` 与 `PermissionDecision`。
2. 路径访问始终基于解析后的绝对真实路径。
3. 区分 session、turn、persistent 三种授权寿命。
4. 实现命令风险分类和强制提示原因。
5. 实现编辑 diff 审批。
6. 将决策写入脱敏日志。
7. 无交互 prompt 时默认拒绝，而不是永久等待。

### 验收证据

- 拒绝后 Runner 未执行、文件未变化、进程未启动。
- Windows 路径大小写、盘符、UNC/外部路径有测试。
- `deny_with_feedback` 的文字进入模型上下文，但不会改变权限配置。
- 持久化权限测试使用临时路径，不污染用户配置。

### 给 AI 的任务提示词

```text
当前阶段 Day 11。实现路径、命令和编辑三类权限请求，以及 plan/default/auto/bypass 模式。
授权必须绑定规范路径、动作和生命周期；无交互界面时默认拒绝。
风险分类只用于决策，不宣称是 OS 沙箱。
覆盖 allow_once/turn/always、deny_once/feedback/always、Windows 路径和危险命令。
暂时不要真正写文件。
```

### 今日易错点

Prompt injection 检测只能作为风险信号。不要看到某个关键短语就永久拒绝合法任务，也不要因为未命中正则就自动信任外部内容。

---

## Day 12：受控写入——Diff、精确编辑与 Checkpoint 是一个原子流程

代码参照：[day12_reviewed_edit.py](daily_code/day12_reviewed_edit.py)

### 今天解决什么问题

今天第一次允许 Agent 改文件。目标不是“能写”，而是修改前可审查、修改后可追踪、出问题可恢复。

### 参考模块

- `file_review.py`
- `tools/write_file.py`
- `tools/edit_file.py`
- `tools/patch_file.py`
- `tools/modify_file.py`（兼容别名，复现时可不保留重复实现）
- `session.py` 的 `create_file_checkpoint`

### 三种编辑工具的职责

| 工具 | 适用场景 | 失败条件 |
| --- | --- | --- |
| `write_file` | 新建或完整替换文件 | 未授权、并发变化、写入失败 |
| `edit_file` | 单个精确旧文本替换 | 零匹配、多匹配且未声明 replace_all |
| `patch_file` | 同文件多个有序精确替换 | 任一替换找不到时整体失败 |

不要让模型默认用“整文件重写”完成小修改。精确编辑能保留未读内容、换行风格和用户并发修改，也更容易生成可靠 Diff。

### 正确的写入事务

```text
解析目标路径
→ 读取 before 与内容哈希
→ 构造 after
→ 生成 unified diff
→ 请求编辑授权
→ 建立修改前 checkpoint
→ 再检查文件哈希是否未变化
→ 原子写入临时文件并 replace
→ 返回摘要、diff 标识和 checkpoint ID
```

参考实现已经具备 Diff、审批、Checkpoint 和写入，但复现时应补上“审批后再次校验哈希”和原子替换，避免用户在审批窗口内修改文件后被覆盖。

### 今日 Demo

让 Agent 修复 `calculator.py`：

1. 使用 `edit_file` 把 `//` 改成 `/`；
2. TUI 尚未完成，用 CLI prompt 展示 Diff；
3. 用户拒绝一次，文件保持不变；
4. 再次允许，生成 Checkpoint 并写入；
5. 手工查看 Checkpoint 保存的旧内容。

今天先不运行测试，验证反馈在 Day 13 接入。

### 实现顺序

1. `build_unified_diff()` 与无变化短路。
2. Checkpoint 数据结构：路径、原是否存在、原始 bytes/hash、edit group。
3. `write_file` 走统一 review helper。
4. `edit_file` 严格处理零/多匹配。
5. `patch_file` 先在内存完成所有替换，任一失败不落盘。
6. 审批后做乐观并发检查。
7. 原子写入并保留编码/换行策略。

### 验收证据

- 拒绝、零匹配、多匹配、补丁中途失败时文件逐字节不变。
- 新建文件 Checkpoint 记录 `existed=False`。
- 已有文件保存原始内容，后续能恢复。
- 审批后外部修改会触发冲突，不静默覆盖。
- 同一用户任务的多个文件修改共享 edit group。

### 给 AI 的任务提示词

```text
当前阶段 Day 12。实现统一 reviewed file change 流程，以及 write_file、edit_file、patch_file。
顺序必须是 before/hash → diff → approval → checkpoint → hash recheck → atomic write。
精确编辑遇到零匹配或歧义必须失败，补丁多步替换要么全成要么不落盘。
覆盖拒绝、新文件、并发修改、编码、换行和部分补丁失败。
```

### 今日易错点

Checkpoint 只能承诺恢复文件内容，不能撤销 shell、网络和数据库副作用。恢复范围必须从设计开始就诚实。

---

## Day 13：命令与测试反馈——把“我觉得修好了”变成运行证据

代码参照：[day13_command_runner.py](daily_code/day13_command_runner.py)

### 今天解决什么问题

修改完成不是任务完成。今天加入可超时、可取消、输出受限的命令执行，以及专门的测试结果解析。

### 参考模块

- `tools/run_command.py`
- `tools/test_runner.py`
- `background_tasks.py`
- `tools/git.py`
- `tools/diff_viewer.py`

### 模块作用

`run_command` 是通用执行器，返回退出码语义；`test_runner` 在其上提供测试文件发现、pytest/unittest 摘要和“零测试”识别。`git` 和 `diff_viewer` 给 Agent 提供只读工作区证据，提交行为应单独审批。

参考实现的 `ToolResult` 主要携带文本。复现建议为命令结果增加结构化元数据：

```python
{
  "exit_code": 1,
  "stdout": "...",
  "stderr": "...",
  "duration_ms": 842,
  "timed_out": False,
  "truncated": False,
}
```

对模型仍可生成文本摘要，但 Runtime 不应再从一段字符串猜退出码。

### `argv` 与 shell 模式

- 普通命令优先使用 `executable + argv`，不经 shell；
- 只有用户/模型明确需要管道、重定向、条件执行时进入 shell 模式；
- shell 模式必须升级权限审查；
- `cwd` 仍经过工作区路径策略；
- 环境变量采用白名单或明确覆盖，不接受任意密钥回显。

### 今日 Demo

完成 Day 12 的闭环：

```text
运行 pytest（失败）
→ 模型读取失败信息
→ 请求 edit_file
→ 用户批准
→ 再运行目标测试（通过）
→ 查看 git diff
```

另外启动一个超时命令，确认进程树被清理，终端可立即接受下一任务。

### 实现顺序

1. 参数数组执行与结构化结果。
2. stdout/stderr 解码和可配置 Windows 编码。
3. 输出 head/tail 截断并保留错误行。
4. 超时、取消和进程组清理。
5. 明确 shell 模式和风险升级。
6. 测试运行器解析“通过、失败、错误、零测试”。
7. 后台模式只登记任务，Day 26 再完善生命周期。

### 验收证据

- 非零退出码保持失败，即使 stdout 看起来正常。
- 零测试不算验证成功。
- 大输出不会塞满模型上下文。
- 超时/取消后无遗留子进程。
- 无交互 headless 未显式授权时不启动有副作用命令。

### 给 AI 的任务提示词

```text
当前阶段 Day 13。实现结构化 run_command 和 test_runner。
优先 argv 执行，shell 语法走显式 shell 模式并触发更强审批。
返回 exit_code/stdout/stderr/duration/timed_out/truncated，支持超时和取消进程树。
测试解析必须识别失败、错误和零测试。
用 buggy_calculator 完成“失败 → 编辑 → 通过”的可观察闭环。
```

### 今日易错点

`subprocess.run(timeout=...)` 在部分平台只保证父进程结束，不保证整棵进程树退出。跨平台取消是产品行为，需要独立测试而不是相信 API 名称。

---

## Day 14：Turn Kernel、任务对象与验证门槛——由运行时决定何时结束

代码参照：[day14_turn_kernel.py](daily_code/day14_turn_kernel.py)

### 今天解决什么问题

模型可能在没读文件、没测试、甚至工具失败后说“完成”。今天把任务目标、阶段、预算、验证状态和停止原因从 Prompt 暗示升级为显式状态。

### 参考模块

- `turn_kernel.py`
- `task_object.py`
- `intent_parser.py`
- `task_tracker.py`
- `verification_controller.py`
- `runtime_profiles.py`

### 每个模块的角色

| 模块 | 回答的问题 |
| --- | --- |
| `intent_parser.py` | 用户想做 CODE、DEBUG、REFACTOR、SEARCH 中的哪类动作？ |
| `task_object.py` | 本轮稳定目标、约束、预期输出是什么？ |
| `turn_kernel.py` | 当前 explore/execute/verify 哪个阶段，还剩多少步？ |
| `task_tracker.py` | 多步骤待办进展如何？ |
| `verification_controller.py` | 本次改动需要无验证、目标测试还是全量验证？ |
| `runtime_profiles.py` | single 与 single-deep 的预算、重试、widen 策略有何不同？ |

### 阶段状态机

```mermaid
stateDiagram-v2
    [*] --> Explore
    Explore --> Execute: 有足够证据
    Execute --> Verify: 已修改或预算进入后段
    Verify --> Done: 证据覆盖当前文件版本
    Verify --> Execute: 验证失败需修复
    Explore --> Widen: 窄路径重复停滞
    Execute --> Widen: 工具错误/证据不足
    Widen --> Verify
    Explore --> Blocked: 需要用户/权限
    Execute --> Blocked
```

### Stable Task Pack 的作用

长上下文压缩后，最近对话可能被摘要。Stable Task Pack 把目标、约束、任务图进度、最新工具证据、验证状态和预算做成一小段受保护事实，避免 Agent 忘记“正在修什么”和“还没验证什么”。

### 今日 Demo

准备两个剧本：

1. 模型编辑后直接返回 `<final>已完成`，Kernel 因缺验证证据拒绝结束并要求运行测试；
2. 模型运行目标测试、引用结果后返回 final，任务状态变为 `COMPLETED`。

再演示只读解释任务可以在没有测试的情况下完成，因为验证策略应随风险变化。

### 实现顺序

1. 从用户输入构建 `TaskObject` 和约束。
2. 实现 `TurnRecurrentState`：step、错误、观察、停止原因。
3. 由预算与证据推导 explore/execute/verify。
4. 实现 `RuntimeProfile`，不要把阈值散落在 Loop。
5. 实现风险自适应验证计划。
6. 验证证据绑定内容哈希或 edit group；验证后再修改即失效。
7. 将 Kernel 决策接回 Agent Loop。

### 验收证据

- 提前 final 被拦截并产生明确 nudge。
- 文档解释任务不被强制要求 pytest。
- Python 核心代码修改至少要求目标测试。
- 验证后再次修改会清除 evidence-ready。
- max_steps、await_user、verification_failed、done 都映射为明确任务状态。

### 给 AI 的任务提示词

```text
当前阶段 Day 14。将任务目标、阶段、预算、停止原因和验证状态建模为独立 Turn Kernel。
Loop 负责执行，Kernel 负责决策；不要把策略散落回入口或工具。
验证证据必须绑定当前 edit group/文件版本，模型口头声明不能替代命令结果。
覆盖只读任务、行为修改、验证失败、验证后再编辑、提前 final、预算耗尽和等待用户。
```

### V0.1 里程碑

到这里应暂停添加功能，连续让系统完成 3–5 个小修复任务。记录失败模式：路径误判、审批体验、模型工具参数、命令取消、验证误判。真实可靠性问题优先于后续“高级感”模块。

---

# 第三阶段：会话、上下文与记忆（Day 15–20）

## Day 15：Session 持久化——保存的是运行状态，不只是聊天文本

代码参照：[day15_session_store.py](daily_code/day15_session_store.py)

### 今天解决什么问题

进程结束后，Agent 需要知道之前做过什么、改过哪些文件、验证是否有效。今天实现可版本化、可增量保存的会话。

### 参考模块

- `session.py`
- `history.py`
- `state.py`
- `cost_tracker.py`
- `tests/test_session.py`

### Session 应保存什么

| 数据 | 恢复后的用途 |
| --- | --- |
| messages | 继续模型对话 |
| transcript/events | 人类检查发生过什么 |
| task/turn state | 知道完成、暂停还是失败 |
| tool calls/results | 避免把未知副作用当没发生 |
| checkpoints | 预览和回退文件 |
| verification evidence | 判断是否仍对当前版本有效 |
| runtime/product snapshot | 诊断模型、扩展和权限环境变化 |
| token/cost usage | 预算与审计 |

`history.py` 只保存用户输入历史，服务于上/下键与快速复用；它不能代替 Session。

### 全量快照与 Delta

首版可以每次原子写完整 JSON。正确后再做 Delta：保存基线快照和自上次保存后新增的消息、事件、Checkpoint。载入时合并，定期压平。Delta 的价值是降低长会话频繁写盘成本，而不是改变权威状态。

### 今日 Demo

运行一个只读任务，保存 Session，关闭进程。使用：

- `--list-sessions` 查看摘要；
- `--inspect-session` 查看运行时、消息数、最近事件和 Checkpoint；
- 直接读取 JSON 验证 schema version 与 workspace identity。

今天先不恢复执行和回退，它们在 Day 16 完成。

### 实现顺序

1. `SessionMetadata`、`SessionData`、schema version。
2. workspace identity 使用规范路径和稳定标识。
3. 原子保存、载入、列表、删除、清理旧会话。
4. `AutosaveManager` 的 dirty、interval、force save。
5. Delta 的追加和幂等合并。
6. `format_session_inspect()` 只读展示。
7. State Store 作为进程内可观察状态，不取代持久 Session。

### 验收证据

- 保存中断不会留下被当作有效会话的半截 JSON。
- 没有变化时 Delta save 幂等。
- `None`、旧 schema、损坏文件有可诊断行为。
- 不同 workspace 的 latest session 不串用。
- Session 文件不包含 API Key。

### 给 AI 的任务提示词

```text
当前阶段 Day 15。实现带 schema version 与 workspace identity 的 SessionData。
先保证原子全量保存/加载/list/inspect 正确，再增加幂等 delta save 和 autosave。
保存消息、事件、任务状态、验证证据、checkpoint 索引和脱敏 runtime snapshot。
history 只保存用户输入，不与 Session 混用。
覆盖损坏文件、旧 schema、跨工作区和无变化重复保存。
```

### 今日易错点

不要 pickle 整个运行时对象。模型客户端、线程、进程和回调不可安全恢复；Session 保存的是重建运行时所需的数据，不是 Python 对象快照。

---

## Day 16：Replay、Resume 与 Rewind——恢复必须避免重复副作用

代码参照：[day16_safe_rewind.py](daily_code/day16_safe_rewind.py)

### 今天解决什么问题

保存只是第一步。今天让用户能只读回放、继续未完成任务、预览并安全撤回文件改动。

### 参考模块

- `session.py` 的 `format_session_replay`、`format_rewind_preview`、`rewind_session_data`
- `main.py` 的会话管理参数
- `tui/session_flow.py`（Day 22 再接 UI）

### 三个概念必须分开

| 操作 | 是否调用模型 | 是否执行工具 | 目的 |
| --- | --- | --- | --- |
| replay | 否 | 否 | 展示历史事实 |
| resume | 是 | 可能 | 以已保存状态继续 |
| rewind | 否 | 只恢复受管文件 | 撤回一个或多个 edit group |

Resume 时最危险的是“执行结果未知”的步骤。例如进程在命令已启动、结果尚未保存时崩溃，不能自动重跑。应标记 `unknown_side_effect`，先让用户或运行时核实。

### 安全 Rewind

Checkpoint 除 before 外，还需保存 Agent 写入后的 hash。回退时：

```text
当前文件 hash == checkpoint.after_hash
  → 可以恢复 before
当前 hash 不同
  → 用户或其他进程后来改过，报告冲突并停止
```

多个文件属于同一 edit group 时，先预检全部文件；任何一个冲突，默认整个组不写入。否则会产生半回退状态。

### 今日 Demo

1. 让 Agent 修复两个文件并保存 Session；
2. Replay，确认没有重新运行测试；
3. Preview Rewind，展示将恢复/删除的文件；
4. 手工改其中一个文件，Rewind 应报告冲突；
5. 撤销手工改动后按 edit group 原子回退；
6. Resume 会话，再次修复并验证。

### 实现顺序

1. replay 只基于持久事件格式化。
2. resume 重建配置、工具、权限和模型，再接历史。
3. 检查 workspace identity 和扩展版本变化。
4. 为副作用步骤定义 `pending/running/succeeded/failed/unknown`。
5. 实现 rewind preview。
6. 实现 edit-group 预检、冲突检测、恢复与恢复记录。
7. 新建文件的 before 是“不存在”，回退动作是删除该文件。

### 验收证据

- Replay 前后工作区 hash 一致，且没有新进程。
- Resume 不自动重复 unknown 命令。
- 用户后续编辑不会被 Rewind 静默覆盖。
- edit group 不发生部分恢复。
- Rewind 本身也留下可审计记录，必要时可以撤销一次回退。

### 给 AI 的任务提示词

```text
当前阶段 Day 16。实现 replay、resume、rewind preview 和 edit-group rewind。
Replay 必须纯只读；Resume 对 running/unknown 副作用先核实，不能自动重放。
Checkpoint 保存 before、after_hash、existed 和 edit_group；回退前预检整个组。
当前文件与 after_hash 不一致时报告冲突，绝不覆盖用户后续修改。
```

### 今日易错点

回退成功不等于系统完全恢复。依赖安装、数据库写入和网络调用仍可能存在；UI 和最终报告要明确“恢复了哪些文件、哪些副作用不在覆盖范围”。

---

## Day 17：上下文预算——先减少浪费，再谈智能摘要

代码参照：[day17_context_budget.py](daily_code/day17_context_budget.py)

### 今天解决什么问题

长任务最先爆掉的通常不是推理，而是重复文件内容、超大命令输出和每轮完整 Prompt。今天建立 Token 观测、工具输出预算和重复读取去重。

### 参考模块

- `context_manager.py`
- `context_compactor.py` 的 `ToolResultBudgetManager`、`ReadDedupManager`
- `micro_compact.py`
- `working_memory.py`（今天先定义受保护接口）

### 三类预算

| 预算 | 控制对象 | 超限动作 |
| --- | --- | --- |
| 模型上下文预算 | 整个请求 | 压缩旧历史，为输出留空间 |
| 工具结果预算 | 单个/累计 ToolResult | 持久化完整内容，注入摘要或 head/tail |
| 工作记忆预算 | 必须保留的事实 | 按重要度和 TTL 淘汰，不能无限增长 |

### Token 数的诚实表达

Provider usage 是已完成请求的事实；下一次请求只能估算。`ContextStats` 应标记来源，UI 显示“estimated”，不要拿字符数公式冒充精确计费。

### 今日 Demo

让工具返回一份 200KB 日志，并连续三次读取同一文件：

- 完整大结果被保存到本地 artifact；
- 模型只收到带路径和摘要的预算版内容；
- 第二、三次相同读取变成 dedup stub；
- 上下文统计显示节省量。

### 实现顺序

1. 维护模型上下文窗口表和未知模型默认值。
2. 实现消息 Token 估算与来源标记。
3. 为输出预留安全余量。
4. 工具大结果持久化，返回摘要、artifact path、原始大小。
5. 按 path + content hash 注册读取去重。
6. 文件变化时使 dedup 失效。
7. `micro_compact` 只做确定性轻量裁剪，不调用模型。

### 验收证据

- 同一内容重复读不会重复占满上下文。
- 文件修改后再次读取获得新内容，不被旧 dedup 拦截。
- 大结果 artifact 可查看，模型摘要明确说已截断。
- 上下文达到 50/75/90% 时产生一次阈值事件，不刷屏。

### 给 AI 的任务提示词

```text
当前阶段 Day 17。实现 ContextStats、工具结果预算、artifact 持久化、read dedup 和确定性 micro compact。
Provider usage 与估算值必须标记来源；为模型输出预留空间。
大结果保留完整本地副本，模型只收到可追踪摘要；相同 path+hash 的重复读取返回 stub。
先不要实现 LLM 摘要压缩。
```

### 今日易错点

只保留日志头部会丢掉最后的错误汇总，只保留尾部又可能丢命令和环境。不同工具要使用不同截断策略，通用策略至少保留 head、tail、错误行和规模信息。

---

## Day 18：压缩与工作记忆——减小历史，但不丢任务状态

代码参照：[day18_compaction.py](daily_code/day18_compaction.py)

### 今天解决什么问题

轻量裁剪不足时需要摘要压缩。今天实现自动压缩、溢出恢复、熔断和受保护工作记忆。

### 参考模块

- `context_compactor.py`
- `micro_compact.py`
- `circuit_breaker.py`
- `working_memory.py`
- `layered_context.py`
- `turn_kernel.py` 的 `StableTaskPack`

### 压缩层次

```text
Layer 1  Micro Compact：去掉重复/低价值细节，不调用模型
Layer 2  Tool Budget：大结果转 artifact + 摘要
Layer 3  Auto Compact：达到阈值时生成结构化摘要
Layer 4  Reactive Compact：Provider 报 context overflow 后激进恢复
Layer 5  Circuit Breaker：连续失败时停止反复压缩
```

### 结构化压缩产物

不要只生成一段“之前聊了很多”的文字。压缩产物至少包含：

- 被压缩的消息范围；
- 当前目标和用户约束；
- 已读/已改文件；
- 重要工具结果与错误；
- 已完成和未完成事项；
- 验证状态；
- 原始历史定位信息。

工具调用和对应结果是一个不可拆单元，绝不能只保留其中一半。

### 工作记忆与分层上下文

`working_memory.py` 保存当前任务中必须跨压缩存活的事实，带类型、重要度和 TTL。`layered_context.py` 则把系统指令、任务目标、工作记忆、近期交互和检索记忆分层分配预算。两者一个解决“保护什么”，一个解决“怎样装进请求”。

### 今日 Demo

把上下文窗口人为设成很小，进行多轮读取和失败测试：

1. 触发自动压缩；
2. 检查目标、禁止修改的文件、最新 edit group、测试仍失败等事实仍在；
3. 模拟摘要模型失败三次，熔断后采用保底截断并明确报告；
4. Session 中仍保留原始完整日志。

### 实现顺序

1. Working Memory 的 add、TTL、importance 和预算淘汰。
2. Stable Task Pack 写入受保护层。
3. 选择安全压缩边界，不拆工具对。
4. 构建结构化摘要并保留 source range。
5. 自动阈值和响应式 overflow 恢复。
6. 摘要失败计数、冷却与熔断。
7. 把压缩产物持久化到 Session。

### 验收证据

- 极小预算下仍能回答“当前目标、改了什么、还需验证什么”。
- Tool Call/Result 始终配对。
- 原始 Session 未被摘要覆盖。
- 连续压缩失败有限次结束，不死循环。
- 工作记忆超预算时按策略淘汰，关键用户约束优先保留。

### 给 AI 的任务提示词

```text
当前阶段 Day 18。实现分层上下文、受保护 Working Memory、结构化 Auto/Reactive Compaction 和熔断。
摘要必须保留目标、约束、文件、工具错误、未完成事项和验证状态，并记录原消息范围。
工具请求与结果不可拆分；原始 Session 永远保留。
构造极小窗口测试压缩成功、摘要失败、反复溢出和熔断退化。
```

### 今日易错点

摘要本身也会消耗上下文。如果每次压缩都把旧摘要再次全文摘要，信息会逐轮退化。应采用结构化增量合并，并保留不可覆盖的关键字段。

---

## Day 19：项目记忆——把跨会话知识变成可管理的数据

代码参照：[day19_project_memory.py](daily_code/day19_project_memory.py)

### 今天解决什么问题

上下文解决当前会话，项目记忆解决“下次还需要知道什么”。今天建立 user/project/local 三种 scope、BM25/TF-IDF 检索和显式管理。

### 参考模块

- `memory.py`
- `domain_classifier.py`
- `user_profile.py`
- `.mini-code-memory/`

### 记忆不等于聊天归档

适合长期记忆的内容：测试命令、目录约定、已确认的架构决定、用户代码风格。不能自动记忆：密钥、一次性错误、模型未验证的猜测、可从当前源码快速重新读取的全文。

### Memory Entry 最少字段

```text
id / content / category / tags
scope: user | project | local
source / created_at / updated_at
confidence / valid / expires_at
```

Scope 隔离比检索算法更重要。不同工作区不能因为关键词相同而互相注入私有事实。

### 搜索路径

```text
查询规范化
→ scope / domain / valid 过滤
→ 关键词与 BM25/TF-IDF 评分
→ recency / confidence 修正
→ 去重
→ 预算内格式化
```

### 今日 Demo

在项目 A 记住“测试命令是 `pytest tests/test_calculator.py -q`”，新会话询问如何验证，成功召回。切到项目 B 不应出现这条记忆。删除后项目 A 也不再注入。

### 实现顺序

1. `MemoryEntry` 和三个 scope 的存储路径。
2. 原子读写、损坏文件恢复和索引重建。
3. add/update/delete/list/tag。
4. 简单关键词搜索，再加入 BM25/TF-IDF。
5. domain 分类只作为过滤/加权信号。
6. 限制注入条数和每条 Token。
7. 增加冲突、过期、衰减和提升接口。

### 验收证据

- 跨会话召回，跨项目隔离。
- 删除和失效立即生效。
- 搜索结果包含来源和置信度。
- 记忆文件损坏时有备份/恢复，不静默清空。
- 敏感模式内容不会自动落盘。

### 给 AI 的任务提示词

```text
当前阶段 Day 19。实现 user/project/local 分层 MemoryManager 和可见管理接口。
首版使用文本/JSON 与关键词+BM25/TF-IDF，不引入向量数据库。
每条记忆记录来源、scope、置信度、有效状态和时间；限制注入预算。
覆盖跨会话、跨项目隔离、删除、过期、冲突、损坏恢复和敏感信息拒绝。
```

### 今日易错点

搜索命中不代表内容仍然真实。当前用户明确指令和重新读取的项目事实优先级高于旧记忆；冲突记忆应降低置信度或进入待确认状态。

---

## Day 20：记忆流水线、重排、向量与时间线——高级记忆能力如何组合

代码参照：[day20_memory_pipeline.py](daily_code/day20_memory_pipeline.py)

### 今天解决什么问题

今天补齐参考项目的高级记忆模块，同时明确哪些是主产品必需、哪些是可选研究能力。

### 参考模块

- `memory_pipeline.py`
- `memory_injector.py`
- `memory_reranker.py`
- `memory_curator_agent.py`
- `vector_memory.py`
- `timeline_memory.py`
- `agent_reflection.py`

### 每个模块的实际作用

| 模块 | 作用 | 默认是否必需 |
| --- | --- | --- |
| `memory_pipeline.py` | 统一 read → inject → write → feedback → maintain 生命周期 | 是，作为外观 |
| `memory_injector.py` | 根据上下文压力、失败状态和相关性决定注入多少 | 推荐 |
| `memory_reranker.py` | 用 LLM 对初筛结果重排 | 可选，昂贵且需降级 |
| `vector_memory.py` | 稀疏/向量相似度路径，与 BM25 合并 | 可选 |
| `memory_curator_agent.py` | 后台合并、过期、冲突和策展 | 可选 |
| `agent_reflection.py` | 任务后提炼可复用经验 | 可选且需验证后写入 |
| `timeline_memory.py` | 事件顺序、最新状态、日期与数值推理 | 专用研究能力 |

### 为什么 `MemoryPipeline` 很重要

没有统一外观，Agent Loop 会直接 import 七个记忆模块，任何内部替换都会扩大影响面。Loop 应只知道：

```text
pipeline.inject(task, budget)
pipeline.feedback(outcome)
pipeline.write(verified_fact)
pipeline.maintain()
```

### 时间线记忆的定位

参考项目 `timeline_memory.py` 超过 3000 行，包含大量事件短语、相对日期、数值状态和特定问法推理。它更接近 LongMemEval 风格的专用检索/推理引擎，不应成为 Coding Agent 主链路的硬依赖。复现时把它做成 `TimelineMemoryPlugin`：只有用户询问跨会话事件顺序或最新状态时启用。

### 今日 Demo

1. 先用 BM25 召回 10 条候选；
2. 可选 Reranker 选出 3 条；
3. Context 压力低时注入全文，高时注入摘要，临界时不注入；
4. 模拟一次任务失败，注入器加强与失败模式相关的记忆；
5. 建立三条带日期事件，让 Timeline 回答先后和最新状态；
6. 关闭所有高级模块，基础记忆仍工作。

### 实现顺序

1. 先让 Pipeline 包住 Day 19 的 MemoryManager。
2. 注入器做相关性、预算、cooldown 和重复任务 hash。
3. Reranker 必须有缓存、调用上限和 BM25 fallback。
4. 向量路径懒加载，依赖不可用时返回 disabled。
5. Curator 只操作候选副本，验证后再原子写回。
6. Reflection 只在任务有验证结果后写入经验。
7. Timeline 独立插件化，先实现最新状态和事件顺序最小集。

### 验收证据

- 禁用 Reranker/Vector/Timeline 时主流程测试全通过。
- Reranker 失败自动回到原始排序。
- 相同任务冷却期内不重复注入同一批记忆。
- 未验证任务不会被 Reflection 写成“成功经验”。
- Timeline 不污染普通代码项目记忆。

### 给 AI 的任务提示词

```text
当前阶段 Day 20。用 MemoryPipeline 统一 Day 19 的记忆生命周期，再接入可选 Injector、Reranker、Vector、Curator、Reflection 和 Timeline 插件。
所有高级路径必须可关闭、有预算、有 fallback；Loop 只能依赖 Pipeline 外观。
Timeline 作为专用插件，不得成为 Coding Agent 核心硬依赖。
覆盖重排失败、向量依赖缺失、注入 cooldown、未验证反思拒绝和全部高级能力关闭。
```

### 阶段复盘

现在系统可以长时间工作、跨进程恢复，并在下一会话复用已确认知识。你应能清楚区分：Context 是本次请求，Working Memory 是当前任务受保护事实，Project Memory 是跨会话知识，Session 是完整可恢复记录。

---

# 第四阶段：交互界面与扩展生态（Day 21–26）

## Day 21：CLI、Headless、历史与用户画像——同一内核的不同使用方式

代码参照：[day21_runtime_factory.py](daily_code/day21_runtime_factory.py)

### 今天解决什么问题

核心能力已经存在，今天把它包装成可日常使用的命令行产品，并保证交互入口和自动化入口共享同一个运行时。

### 参考模块

- `main.py`
- `headless.py`
- `cli_commands.py`
- `local_tool_shortcuts.py`
- `manage_cli.py`
- `history.py`
- `install.py`
- `user_profile.py`
- `state.py`

### 入口的装配职责

一个入口通常只做：

```text
解析参数
→ 解析工作区
→ 加载 effective config
→ 初始化日志
→ 创建工具/权限/模型/记忆/会话/上下文
→ 构建 Prompt
→ 调用共享 Runtime
→ 把事件输出到当前界面
→ dispose 资源并返回退出码
```

任何“如何判断完成、如何执行工具”的逻辑出现在入口里，都说明边界开始泄漏。

### CLI 命令分两类

| 类型 | 示例 | 是否进入模型 |
| --- | --- | --- |
| 本地管理命令 | `/sessions`、`/memory`、`/model status`、`/readiness` | 否 |
| 用户任务 | “修复这个测试” | 是 |

`local_tool_shortcuts.py` 的 `/read`、`/grep` 等可直接转成本地 Tool Call，适合调试；普通自然语言仍走模型。`manage_cli.py` 负责技能、MCP 和模型等管理面，避免 `main.py` 膨胀。

### Headless 的安全语义

Headless 没有人即时审批。默认必须拒绝写入与命令；只有显式 `--allow-edits` 或受控 CI 配置才自动批准本次运行，而且授权不能持久化为“永远允许”。输出应适合脚本消费，并用退出码区分成功、失败、配置错误和未验证。

### 今日 Demo

1. `minicode-py --validate-config`；
2. Mock 模式交互执行 `/read calculator.py`；
3. `minicode-headless "解释这个项目"` 成功；
4. Headless 未授权修改被拒绝；
5. 显式允许后完成一次修复，并输出消息 trace；
6. 新会话自动加载用户偏好但不越过项目指令。

### 实现顺序

1. 抽出 `RuntimeFactory` 或装配函数，两个入口复用。
2. 实现本地命令路由，明确是否进入模型。
3. 输入历史只保存非空、去重后的用户输入。
4. Headless 定义稳定退出码和 JSON/文本输出模式。
5. 安装器只做启动器和配置引导。
6. USER.md 解析用户语言、解释深度、代码风格偏好；偏好低于系统安全与当前任务指令。

### 验收证据

- 同一 ScriptedModel 任务在 CLI 与 Headless 产生相同业务结果。
- Headless 默认不会卡在审批输入。
- 本地管理命令不计入模型 Token。
- 输入历史与 Session 数据职责不混淆。
- 资源无论成功失败都调用 `tools.dispose()`。

### 给 AI 的任务提示词

```text
当前阶段 Day 21。实现共享 Runtime 装配，并完成 main CLI、headless、本地命令、输入历史和用户画像。
入口只装配依赖，不复制 Agent 逻辑；本地管理命令不进入模型。
Headless 默认拒绝副作用，显式 allow-edits 只对当前运行生效，并提供稳定退出码/trace。
覆盖成功、未授权、配置错误、异常和资源清理。
```

### 今日易错点

不要把 `Error: ...` 当普通成功文本从 Headless 返回 0。机器调用者必须能依靠退出码和结构化状态判断任务结果。

---

## Day 22：TUI——事件驱动的产品界面，而不是第二套 Agent

代码参照：[day22_tui_events.py](daily_code/day22_tui_events.py)

### 今天解决什么问题

今天复现完整终端体验：原始输入、流式响应、工具生命周期、审批、滚动、Markdown、中文宽度和异常恢复。

### 参考模块

- `tty_app.py`
- `tui/state.py`、`tui/types.py`
- `tui/input_parser.py`、`tui/event_flow.py`、`tui/input_handler.py`
- `tui/renderer.py`、`tui/transcript.py`、`tui/chrome.py`
- `tui/tool_lifecycle.py`、`tui/tool_helpers.py`
- `tui/session_flow.py`、`tui/runtime_control.py`
- `tui/navigation.py`、`tui/markdown.py`、`tui/screen.py`、`tui/theme.py`、`tui/input.py`、`tui/ui_hints.py`

### 按层理解 19 个 TUI 模块

```text
输入层：input_parser → event_flow → input_handler
状态层：state + types
业务桥：session_flow + tool_lifecycle + tool_helpers
布局层：transcript + navigation
渲染层：renderer + chrome + markdown + input + theme + ui_hints
终端层：screen + runtime_control
外观入口：tty_app + tui/__init__
```

### 为什么输入解析要独立

终端收到的是字节流，不是“按键”。方向键是转义序列，粘贴可能一次带多行，中文字符显示宽度可能为 2，窗口改变会打断布局。`input_parser.py` 把原始字节变成 `KeyEvent`、`TextEvent`、`WheelEvent`，上层不再理解 ANSI 细节。

### Transcript 不是消息列表

Transcript 还要表达：用户、助手、进度、工具 running/success/error、折叠摘要、运行时阶段、Checkpoint 和产品摘要。长会话只渲染可见窗口，并用 revision/hash 缓存布局，不能每个流式字符重排全部历史。

### 今日 Demo

手工走完整路径：

1. 粘贴三行代码，不自动提交；
2. Enter 提交自然语言任务；
3. 流式文本逐步显示；
4. 工具条目从 running 变 success 并折叠；
5. 编辑审批支持滚动 Diff；
6. Ctrl+C 取消当前任务但不退出整个应用；
7. 调整窗口、输入中文、滚动千条 Transcript；
8. 异常退出后恢复光标和主屏幕。

### 实现顺序

1. 先定义 `RuntimeEvent` 到 `TranscriptEntry` 的映射。
2. 实现纯输入解析器并用字节 fixture 测试。
3. 实现 ScreenState 和 reducer 风格事件处理。
4. 先普通增量输出，再全屏 alternate screen。
5. 实现 Transcript 可见窗口、滚动和缓存。
6. 工具生命周期与审批模式。
7. 渲染节流，避免每个 chunk 清屏。
8. 用 finally 恢复终端状态和信号处理。

### 验收证据

- 多行粘贴不提交，真实 Enter 会提交。
- 中文/CJK、ANSI、Markdown、长行换行不破坏边框。
- 100/1000/5000 条 Transcript 的渲染工作量与可见窗口相关，而非总量线性相关。
- 工具异常保持展开，成功可自动折叠。
- Ctrl+C 传播到 Runtime 取消令牌和子进程。

### 给 AI 的任务提示词

```text
当前阶段 Day 22。基于 RuntimeEvent 实现 TUI，不得把业务判断复制进 renderer/input_handler。
先完成纯 input parser、ScreenState、Transcript window，再加入全屏渲染、工具生命周期和权限审批。
覆盖多行粘贴、转义序列、CJK 宽度、滚动、resize、Ctrl+C、长 transcript 和异常终端恢复。
Headless 与 TUI 必须继续共享同一个 Runtime。
```

### 今日易错点

TUI 自动测试只能覆盖解析和渲染纯函数；Raw Mode、不同终端模拟器、Windows 控制台和 SSH 仍需手工验收清单。

---

## Day 23：Skills 与 Hooks——让工作流可扩展，但不让扩展污染核心

代码参照：[day23_skills_hooks.py](daily_code/day23_skills_hooks.py)

### 今天解决什么问题

今天加入两类不同扩展：Skill 是供模型按需读取的工作流说明；Hook 是运行时事件上的确定性自动化。它们不能合并成一个“万能插件”。

### 参考模块

- `skills.py`
- `tools/load_skill.py`
- `hooks.py`
- `manage_cli.py`
- `prompt.py`

### Skills 的生命周期

```text
发现 SKILL.md
→ 只读取名字和 description
→ Prompt 暴露可用清单
→ 用户任务匹配时模型调用 load_skill
→ 完整指令按预算加载
→ 记录来源和版本
```

发现阶段不要把所有 Skill 全文塞入 Prompt。Skill 是指令来源，不是新权限；它要求执行写入或命令时仍经过权限门。

### Hooks 的生命周期

常见事件：`USER_INPUT`、`PRE_TOOL_USE`、`POST_TOOL_USE`、`ASSISTANT_OUTPUT`、`SESSION_SAVE`、`TURN_END`。Hook 可用于日志、格式化、通知和策略检查，但必须有超时、失败策略和可见日志。

| Hook 类型 | 失败策略示例 |
| --- | --- |
| 审计日志 | 记录失败但不阻断主任务 |
| 安全预检 | fail-closed，阻止动作 |
| 格式化 | 报告失败，保留原内容 |
| 通知 | 异步失败不改变任务结果 |

### 今日 Demo

1. 创建 `testing-workflow/SKILL.md`，只在用户要求 TDD 时加载；
2. 创建一个 PRE_TOOL_USE 日志 Hook；
3. 创建一个故意超时的 Hook，验证运行时按策略继续或阻止；
4. 禁用所有 Skill/Hook，核心修复 Demo 仍成功。

### 实现顺序

1. Skill 搜索根和优先级：project > user > managed。
2. 解析 metadata，全文只在 load 时读取。
3. Skill 安装/删除只操作托管目录。
4. `HookManager` 注册、enable/disable、统计。
5. 同步/异步 Hook 超时和异常隔离。
6. Agent Loop 在稳定事件点 fire Hook。
7. Session 保存启用扩展清单与版本。

### 验收证据

- 未匹配 Skill 不加载全文。
- Skill 内容不能绕过权限。
- 一个坏 Hook 不令全部 Hook 消失且诊断可见。
- 安全 Hook 和通知 Hook 可配置不同失败策略。
- 扩展全部关闭时离线主链路不变。

### 给 AI 的任务提示词

```text
当前阶段 Day 23。分别实现 Skills 和 Hooks，两者共享日志但不共享万能管理器。
Skill 只在发现阶段加载摘要，匹配后通过 load_skill 读取全文；Hook 绑定确定性 RuntimeEvent。
所有 Hook 有超时和明确失败策略，扩展来源/版本进入 Session。
证明禁用全部扩展后核心 Agent 仍可运行。
```

### 今日易错点

外部 Skill 和 Hook 文件都是不受信内容。解析失败、超长内容、路径逃逸和恶意脚本都必须按扩展信任边界处理。

---

## Day 24：MCP——把外部能力翻译成内部 Tool，而不是开一条旁路

代码参照：[day24_mcp_protocol.py](daily_code/day24_mcp_protocol.py)

### 今天解决什么问题

MCP 允许 MiniCode 发现外部工具、资源和提示词。今天实现 stdio 客户端、懒启动、请求关联、断线与关闭。

### 参考模块

- `mcp.py`
- `tools/__init__.py`
- `tests/fixtures/fake_mcp_server.py`
- `tests/test_mcp.py`
- `.mcp.json`

### MCP 在架构中的位置

```mermaid
flowchart LR
    L[Agent Loop] --> R[Tool Registry]
    R --> W[MCP Tool Wrapper]
    W --> C[Stdio MCP Client]
    C --> P[External MCP Process]
    P --> C --> W
    W -->|ToolResult| R --> L
```

关键是 MCP Tool Wrapper 仍然是 `ToolDefinition`：同样的参数校验、权限、截断、日志和 Session 记录。不要让 Loop 直接调用 MCP Client。

### 工具、资源、提示词的区别

- **Tool**：可执行动作，可能有副作用；
- **Resource**：可读取的外部数据，通常只读但仍需来源/大小控制；
- **Prompt**：外部提供的提示模板，是内容而不是高优先级系统指令。

### 客户端生命周期

1. 配置发现，但不立即启动所有进程；
2. 首次访问时 spawn；
3. initialize/协议协商；
4. 后台线程读取 stdout，用 request ID 唤醒等待者；
5. stderr 独立消费，避免管道阻塞；
6. 超时、进程退出或坏 JSON 时让 pending request 失败；
7. Registry dispose 时关闭全部进程。

### 今日 Demo

使用本地 fake MCP server：列出工具、调用 `echo`、列资源、读取资源、列 Prompt、获取 Prompt。然后让服务器中途退出，观察请求得到清晰错误，基础本地工具继续可用。

### 实现顺序

1. 先实现单服务器、单请求 stdio JSON-RPC。
2. 增加 request ID → Future/Condition 映射。
3. 增加 reader/stderr 线程和消息大小限制。
4. list_tools，并转成带 `mcp__server__tool` 前缀的 ToolDefinition。
5. 再加入资源与 Prompt 网关工具。
6. 懒启动、超时、断线、有限重连和 close。
7. 项目级 MCP 配置默认不信任，需显式启用。

### 验收证据

- 假服务完整端到端，无网络依赖。
- 工具名称冲突被前缀隔离。
- 服务超时/退出会释放等待者，不永久挂起。
- 超大/畸形消息被拒绝且有诊断。
- 关闭 Registry 后没有遗留 MCP 进程。

### 给 AI 的任务提示词

```text
当前阶段 Day 24。实现懒启动 stdio MCP 客户端及 Tool/Resource/Prompt 包装。
所有外部能力必须转换为现有 ToolDefinition/ToolResult，并复用权限、日志、输出预算和 Session。
覆盖初始化、请求 ID、stderr 消费、超时、坏 JSON、进程退出、有限重连、命名冲突和 dispose。
项目级 .mcp.json 默认不信任。
```

### 今日易错点

不要把 MCP Prompt 直接拼到最高优先级系统指令。它是带来源的外部内容，可能包含冲突或注入文本。

---

## Day 25：Product Surfaces 与 Capability Registry——让系统知道自己当前能做什么

代码参照：[day25_product_surfaces.py](daily_code/day25_product_surfaces.py)

### 今天解决什么问题

扩展越来越多后，启动成功不代表产品真的可用。今天建立统一的能力注册、指令层、扩展清单、Hook/委派状态和 Readiness 快照。

### 参考模块

- `product_surfaces.py`
- `capability_registry.py`
- `release_readiness.py`
- `prompt.py`
- `cli_commands.py`

### Product Surface 的含义

它不是 UI 页面，而是用户和模型都能感知的运行时能力摘要：

| Surface | 回答的问题 |
| --- | --- |
| Instruction Layers | 当前哪些指令生效，优先级是什么？ |
| Extensions | 哪些本地扩展被发现/启用？ |
| Hook Status | 哪些 Hook 正在运行、最近是否失败？ |
| Delegation Status | 还有多少后台槽位、哪些任务活跃？ |
| Readiness | 配置、Provider、权限、扩展是否足以完成任务？ |
| Prompt Bundle | 本轮 Prompt 与上述快照是否一致？ |

`CapabilityRegistry` 则面向代码：注册能力的 domain、scope、启用状态、调用统计和 handler。它让 Orchestrator 和诊断代码不必通过 import/hasattr 猜系统能力。

### 今日 Demo

执行 `/readiness` 输出：模型通道、核心工具、MCP 状态、Hook 状态、后台槽位、Memory 和 Session 存储可用性。故意让 MCP 服务失效，Readiness 应为 degraded，但本地只读任务仍可运行。

### 实现顺序

1. 定义产品快照数据类，不把可执行对象放进去。
2. 收集指令层并标明来源/优先级。
3. 收集扩展、Hook、Delegation 状态。
4. Readiness 区分 ready/degraded/blocked。
5. Capability Registry 注册 Tool、Memory、Compaction 等能力。
6. Prompt 和 Session 使用同一份 snapshot，避免描述与实际不一致。
7. `/readiness`、`/instructions`、`/extensions` 只读展示。

### 验收证据

- 单个扩展失败只降低相关能力，不把整个系统误判为不可用。
- Snapshot 不含密钥、进程对象或 callback。
- Prompt 展示的启用能力与 Registry 一致。
- Session inspect 能看到当时的产品快照。

### 给 AI 的任务提示词

```text
当前阶段 Day 25。实现 CapabilityRegistry 和不可执行、可序列化的 ProductSnapshot。
统一收集 instructions/extensions/hooks/delegation/readiness，并让 Prompt、CLI、Session 共用该快照。
Readiness 必须区分 ready、degraded、blocked，局部扩展故障不能误杀核心能力。
覆盖脱敏、畸形扩展、状态变化和快照一致性。
```

### 今日易错点

不要让 Readiness 变成“所有可选模块都必须绿色”。它应回答当前目标能否执行，而不是追求仪表盘全绿。

---

## Day 26：后台任务、子 Agent 与任务图——扩展吞吐但保持主控

代码参照：[day26_delegation.py](daily_code/day26_delegation.py)

### 今天解决什么问题

长命令和大型代码探索不应永久阻塞主会话。今天加入后台任务、受限子 Agent、任务图和工作区隔离。

### 参考模块

- `background_tasks.py`
- `tools/task.py`
- `task_graph.py`
- `task_tracker.py`
- `pipeline_engine.py`
- `decoupling_controller.py`（Day 28 再从控制角度看）

### 三种对象不要混淆

| 对象 | 例子 | 特点 |
| --- | --- | --- |
| 后台进程 | 长时间 pytest、构建 | OS 进程，有 PID、输出和取消 |
| 子 Agent | 独立探索某模块 | 自己的消息/预算/工具范围 |
| Task Graph | “分析→修改→验证”的依赖图 | 逻辑任务状态，不必对应进程 |

### 子 Agent 的任务合同

```text
goal：明确目标
inputs：允许读取的上下文
scope：工作区/文件/只读限制
budget：步数、时间、Token、费用
agent_type：explore | plan | general
output：summary / inspected / changed / risks / verification
parent_trace_id：关联父任务
```

首版 `explore` 和 `plan` 强制只读；`general` 写入时使用独立 worktree 或明确文件所有权。禁止无限递归，限制深度和并发槽位。

### 今日 Demo

父 Agent 委派两个只读子任务：一个分析模型层，一个分析工具层；二者并发返回结构化报告。父 Agent 汇总后自己决定修改。再启动一个后台测试，查看状态、读取输出并取消。

### 实现顺序

1. 后台任务 Registry：task ID、PID、cwd、状态、开始/结束时间。
2. list/get/output/cancel/refresh，重启后核对 PID 是否仍代表原进程。
3. 全局 slot 限制与完成通知。
4. Task Graph 的 dependency、slot、state、progress。
5. 子 Agent 创建隔离的 messages、budget 和 Tool Registry view。
6. 结构化交付格式和 parent trace。
7. 写任务隔离、冲突检查和取消传播。

### 验收证据

- 取消父任务会传播给子 Agent/后台进程。
- 子 Agent 失败不会被父任务当作空成功。
- explore/plan 无法调用写工具。
- 达到并发/递归上限时明确拒绝。
- 多写任务不会无隔离修改同一文件。

### 给 AI 的任务提示词

```text
当前阶段 Day 26。先实现后台进程完整生命周期，再实现受限子 Agent 和 TaskGraph。
子任务合同包含 goal/input/scope/budget/type/structured output/parent trace；explore 和 plan 强制只读。
限制并发、递归、时间和费用，支持取消传播；写任务必须隔离或声明文件所有权。
覆盖失败、超时、重启核对、槽位耗尽和写冲突。
```

### 今日易错点

把整个父会话原样复制给子 Agent 会浪费上下文并扩大敏感信息范围。只传完成目标所需的最小输入，并让子 Agent 返回摘要和证据位置。

---

# 第五阶段：自适应运行时、评估与发布（Day 27–30）

## Day 27：指标、路由、成本与验证控制——先有信号，再谈自动调节

代码参照：[day27_routing_and_verification.py](daily_code/day27_routing_and_verification.py)

### 今天解决什么问题

今天开始复现高级运行时，但先不做复杂 PID。第一步是定义可信观测：任务复杂度、错误率、延迟、上下文压力、成本和验证风险。

### 参考模块

- `agent_metrics.py`
- `agent_router.py`
- `smart_router.py`
- `model_switcher.py`
- `cost_tracker.py`
- `verification_controller.py`
- `progress_controller.py`
- `decision_audit.py`
- `domain_classifier.py`

### 信号到决策

```text
观测：复杂度、预算压力、延迟、近期失败、是否需工具/长上下文
→ 规则/评分控制器
→ 决策：模型、reasoning effort、验证范围、是否停滞
→ 执行
→ 记录结果作为下一次反馈
```

`smart_router.py` 是 AgentRouter、ModelSwitcher 和 FeedbackLearner 的组合外观；它不应让模型选择自己。`decision_audit.py` 记录候选、理由、结果和证据，帮助回答“为什么换模型/扩大验证”。

### 今日 Demo

构造三类任务：解释 README、修一个小测试、跨模块重构。观察路由建议、预算估算和验证计划不同。然后模拟强模型连续失败，Fallback 只能沿配置候选尝试一次，不在两个坏模型间来回跳。

### 实现顺序

1. 指标采集只记录事实：次数、耗时、状态、Token、费用。
2. 任务复杂度提取返回理由和置信度。
3. 纯函数模型评分，价格和能力来自可更新目录。
4. Fallback 维护本轮已失败集合。
5. 验证控制器根据改动风险选择 none/targeted/full。
6. Progress Controller 用新证据、重复动作和剩余预算判断停滞。
7. 所有自动决策进入 Audit。

### 验收证据

- 相同输入和目录产生确定性建议。
- 缺失价格/能力信息时安全降级。
- Fallback 不循环、不跨越用户限制的 Provider。
- 成本显示区分估算和 Provider 实际 usage。
- 验证计划能解释选择了哪些测试及原因。

### 给 AI 的任务提示词

```text
当前阶段 Day 27。建立可信指标，再实现任务路由、模型 fallback、成本、进度和风险验证控制器。
控制器输入输出都用数据类，并返回理由；模型目录可更新，缺失时降级。
Fallback 维护本轮失败集合，禁止循环；所有自动决策写入 DecisionAudit。
今天不要实现 PID 或自愈。
```

### 今日易错点

“智能路由”最容易变成不可验证的启发式堆叠。每个决策都要能在固定信号下单测，并通过消融证明比固定策略更好，否则默认关闭。

---

## Day 28：控制论基础——把 Agent 当成受扰动的动态系统

代码参照：[day28_pid_control.py](daily_code/day28_pid_control.py)

### 今天解决什么问题

今天理解并实现反馈、前馈、预测、状态观测、解耦和自适应整定。目的不是炫技，而是在长任务中稳定上下文、成本、错误率和进度。

### 参考模块

- `feedback_controller.py`
- `feedforward_controller.py`
- `predictive_controller.py`
- `state_observer.py`
- `decoupling_controller.py`
- `adaptive_pid_tuner.py`
- `context_cybernetics.py`
- `cost_control.py`

### 控制论映射

| 控制概念 | MiniCode 中的对象 |
| --- | --- |
| 被控对象 Plant | Agent Loop + Model + Tools |
| 设定值 Setpoint | 目标上下文占用、成本速率、错误率 |
| 传感器 Sensor | Token、延迟、错误、进度、费用 |
| 控制器 Controller | PID、规则、预测器 |
| 执行器 Actuator | 压缩、减少并发、收紧预算、换模型 |
| 扰动 Disturbance | Provider 抖动、大工具输出、测试失败 |

### 前馈与反馈的区别

- 前馈：任务开始前根据“这是跨模块重构”预先增加预算、选择更强模型；
- 反馈：运行后发现错误率升高，再降低并发或调整策略；
- 预测：根据上下文增长趋势，在真正溢出前压缩；
- 状态观测：从噪声指标估算“真实健康度”；
- 解耦：避免压缩上下文同时恶化记忆召回或成本控制。

### PID 只需理解这一点

```text
error = setpoint - measurement
output = Kp*error + Ki*累计误差 + Kd*误差变化
```

工程重点是采样周期、输出限幅、anti-windup 和 actuator 是否真的执行。没有真实 actuator 的 Controller 只是日志装饰。

### 今日 Demo

做一个纯模拟器，不先接主 Loop：上下文占用从 40% 连续升到 95%，Controller 依次给出 no-op、减小工具预算、micro compact、full compact。再模拟成本激增，预算乘数下降但不低于安全下限。

### 实现顺序

1. 纯 `SystemState` 与 `ControlSignal`。
2. PID 加限幅、anti-windup、reset。
3. Feedforward 预配置。
4. 指数平滑/移动平均预测。
5. State Observer 对噪声信号平滑。
6. Context 与 Cost 两个具体闭环。
7. 自适应调参只在离线模拟/足够样本后运行。

### 验收证据

- 固定输入序列输出可重复。
- 积分项不会无限累积，输出受限。
- 禁用控制器时零副作用。
- Controller 决策有对应 actuator 测试。
- 预测失败时回退阈值策略。

### 给 AI 的任务提示词

```text
当前阶段 Day 28。先在纯模拟环境实现 feedback/feedforward/predictive/state observer/decoupling/adaptive PID，
再落地 Context 与 Cost 两个小闭环。
每个控制输出都必须映射到真实 actuator；包含限幅、anti-windup、reset 和 disabled 模式。
不要直接把全部控制器塞进 Agent Loop，先用确定性时间序列验证稳定性。
```

### 今日易错点

控制器数量不是质量。若一个阈值规则已足够稳定，PID 可能只增加调参和解释成本。课程要求复现参考能力，也要求你用消融决定默认是否启用。

---

## Day 29：Orchestrator、自愈与消融——把增强层接入，同时保持可拆除

代码参照：[day29_control_orchestrator.py](daily_code/day29_control_orchestrator.py)

### 今天解决什么问题

今天把高级控制模块通过一个 Orchestrator 接入 Runtime，并用 Supervisor、Stability Monitor、Self-Healing 和 Ablation 验证它们确实有价值。

### 参考模块

- `cybernetic_orchestrator.py`
- `cybernetic_supervisor.py`
- `stability_monitor.py`
- `self_healing_engine.py`
- `cybernetic_ablation.py`
- `context_cybernetics.py`
- `agent_reflection.py`
- `memory_pipeline.py`

### Orchestrator 的正确职责

它负责构建、接线、启停和一个控制周期，不应成为第二个 Agent Loop。建议接口：

```text
initialize(runtime_dependencies)
before_turn(task, signals) -> preemptive actions
before_model_call(context signals) -> budget/compact actions
after_tool(result, metrics) -> recovery/stability actions
after_turn(outcome) -> feedback/reflection
snapshot() -> supervisor report
close()
```

参考项目的 `agent_loop.py` 直接初始化很多控制器，导致主文件过长。复现时把整个增强层放在 `RuntimeControlExtension` 后面，Loop 只调用少数生命周期钩子。

### Self-Healing 的边界

自愈可以：重试幂等模型请求、清理失败状态、触发压缩、降低并发、切换已授权 fallback。它不可以：自动重放未知副作用、绕过权限、覆盖用户文件或无限尝试。

### Stability 与 Supervisor

`StabilityMonitor` 观察趋势和振荡；`CyberneticSupervisor` 汇总风险、最近动作、失败和当前启用控制器。它们提供诊断，不直接修改文件。

### 消融实验

至少对以下条件运行同一任务集：

| 条件 | 启用能力 |
| --- | --- |
| baseline | 核心 Loop，无控制论 |
| context-only | 上下文控制 |
| recovery-only | 自愈与稳定性 |
| full | 全部增强层 |

比较成功率、工具错误率、步数、Token、费用、延迟和越权副作用。没有稳定收益的模块保持默认关闭。

### 今日 Demo

构造上下文压力 + 工具间歇失败场景。Baseline 在预算前失败，context-only 能压缩继续，recovery-only 能降低并发，full 完成任务。然后构造简单任务，证明 full 不应显著增加延迟/费用，否则调整触发条件。

### 实现顺序

1. 定义可选 `RuntimeControlExtension` Protocol。
2. Orchestrator 只在配置启用时构建控制器。
3. 所有 Controller 接受依赖注入，无模块级隐式单例。
4. Supervisor 汇总只读快照。
5. Self-Healing 的动作白名单、次数和冷却。
6. Reflection 仅基于验证结果写记忆。
7. Ablation Runner 用固定任务和随机种子输出可比较报告。

### 验收证据

- 完全移除/屏蔽 cybernetic 模块时核心包仍可 import 和运行。
- 自愈不会重放 unknown 副作用。
- 同一故障不会无上限重复 healing。
- Supervisor 报告包含信号、动作和理由。
- 消融报告能指出收益与代价，而不是只给“通过”。

### 给 AI 的任务提示词

```text
当前阶段 Day 29。用可选 RuntimeControlExtension 接入 CyberneticOrchestrator，
加入 Supervisor、StabilityMonitor、SelfHealing 和固定任务 Ablation。
核心 Loop 只调用少数生命周期钩子；控制层关闭或模块不可导入时仍可运行。
SelfHealing 只执行白名单、有限、可审计动作，绝不重放未知副作用或绕过权限。
对 baseline/context/recovery/full 输出可比较指标。
```

### 今日易错点

“模块能 import、测试能构造”不代表控制回路闭合。必须验证传感器值真的影响 Controller、Controller 真的驱动 Actuator、Actuator 结果又回到下一周期。

---

## Day 30：Harness、CI、打包与最终复现——用证据结束课程

代码参照：[day30_eval_harness.py](daily_code/day30_eval_harness.py)

### 今天解决什么问题

最后一天不再加功能，而是证明这个系统能安装、能完成固定任务、失败时能准确分类，并整理为可维护的产品。

### 参考模块与目录

- `runtime_profile_eval.py`
- `release_readiness.py`
- `paper_a_task_completion_eval.py`
- `cybernetic_ablation.py`
- `benchmarks/runtime_profile_eval.py`
- `benchmarks/release_readiness.py`
- `benchmarks/performance_benchmark.py`
- `benchmarks/multi_round_stress_test.py`
- `benchmarks/cluster_stress_test.py`
- `.github/workflows/ci.yml`
- `Dockerfile`、`docker-compose.yml`
- `pyproject.toml`

### 三层验证

| 层 | 是否默认运行 | 证明什么 |
| --- | --- | --- |
| 单元/离线集成 | 是 | 协议、状态机和失败分支确定正确 |
| 临时工作区端到端 | 是 | 真实文件/进程/Session 能协作 |
| 真实 Provider 冒烟 | 有凭据时 | 外部 API 当前可用，不用于替代离线正确性 |

### 固定任务集

1. 解释一个未知仓库；
2. 定位并修复失败测试；
3. 新增一个小功能；
4. 受限重构且不改公开行为；
5. 拒绝一次编辑；
6. 阻止路径逃逸和危险命令；
7. 取消长命令；
8. 进程重启后 Resume；
9. Rewind 正常和冲突；
10. 极低上下文预算；
11. MCP 故障降级；
12. 子 Agent 超时/取消；
13. 控制论 baseline/full 消融。

### 指标定义

- task success：最终工作区符合预期；
- verification success：相关验证真实运行并通过；
- permission safety：拒绝后无副作用；
- recovery success：Resume/Rewind 符合预期；
- runtime failures：代码错误、死锁、进程泄漏；
- provider blocked：凭据/配额/服务不可用，单独统计；
- efficiency：步数、Token、费用、耗时、工具错误率。

### 当前参考仓库给出的工程提醒

本次课程梳理时，本地测试收集得到 1164 个测试，但 `tests/test_property_based.py` 因缺少 `hypothesis` 产生收集错误；当前 `pyproject.toml` 的 `dev` extra 只声明了 `pytest`，而 CI 运行中还临时安装 `ruff` 与 `mypy`。这说明“测试很多”不等于“干净环境可复现”。你的复现项目应把所有默认测试依赖完整写入 `dev` 或拆分成明确 extras。

### 最终 Demo

在一个全新虚拟环境中：

```text
构建 wheel
→ 安装 wheel
→ 运行 --validate-config
→ Mock 模式解释仓库
→ 真实/Mock 修复 buggy_calculator
→ inspect/replay session
→ rewind preview + rewind
→ 运行 readiness 和固定任务报告
```

同时验证包里没有 `.env`、Session、Memory、缓存、测试输出和本地密钥。

### 实现顺序

1. 固定离线 fixture 和可独立判定的期望。
2. 实现 Harness 隔离每次运行，收集结构化证据。
3. Runtime Profile Eval 比较 single/single-deep。
4. Release Readiness 分类本地错误与 Provider 阻塞。
5. 性能测试区分算法断言与易抖动耗时。
6. CI 覆盖 Python 3.11/3.12 与 Windows/Linux/macOS。
7. compile、lint、type baseline、pytest、packaging smoke。
8. 干净 venv 安装 wheel 并运行入口。
9. Docker 只作为可选隔离/部署路径，不掩盖本地安装问题。

### 验收证据

- 默认离线检查可在无密钥机器运行。
- 测试依赖从项目配置完整安装，不靠开发机残留。
- 每个真实任务重新复制 fixture，前次改动不污染后次结果。
- 报告区分 PASS/FAIL/SKIP/BLOCKED。
- README 的命令与实际入口一致。
- 发布物对应同一个 Git commit 和评估报告。

### 给 AI 的任务提示词

```text
当前阶段 Day 30。停止新增功能，建立固定任务 Harness、Runtime Profile Eval、Release Readiness、CI 和干净环境打包检查。
默认离线；真实 Provider 只做可选冒烟，并将外部不可用与代码失败分开。
每次任务重置 fixture，记录工作区结果、验证、权限副作用、恢复、步数、Token、费用和耗时。
补齐所有测试依赖，构建 wheel 后在新 venv 安装并跑入口。
输出已知限制，不用跳过或放宽断言制造绿色报告。
```

---

# 第六部分：完整整合视图

## 1. 启动时发生什么

```text
main/headless
  ├─ config.load_effective_settings
  ├─ logging.setup
  ├─ session.load_or_create
  ├─ permissions.create
  ├─ tools.create_default_tool_registry
  │    ├─ core tools
  │    ├─ discovered skills + load_skill
  │    ├─ lazy MCP wrappers
  │    └─ optional utility profile
  ├─ memory_pipeline.initialize
  ├─ product_surfaces.build_snapshot
  ├─ prompt.build_bundle
  ├─ model_registry.create_model_adapter
  ├─ context_manager.create
  └─ runtime/agent_loop.run
```

## 2. 一次工具调用发生什么

```text
Provider response
→ Adapter 转成 AgentStep(tool_calls)
→ Loop/Kernel 检查预算与状态
→ Tool Scheduler 按能力分类
→ Permission preview / approval
→ Registry 验证参数
→ Tool 通过 workspace 边界执行
→ 写操作先 Diff + Checkpoint
→ ToolResult 归一化、截断/持久化
→ Hook、Metrics、Session、Transcript 记录
→ assistant_tool_call + tool_result 回填
→ 下一次模型调用
```

## 3. 一次任务如何真正结束

```text
模型产生 final
→ Turn Kernel 检查当前 phase
→ 判断任务类型是否需要 evidence
→ evidence 是否绑定当前文件版本/edit group
→ 若不足：添加验证 nudge，继续
→ 若满足：标记 stop_reason=done
→ 更新 Task/Session/Memory feedback
→ 发送 TurnDone RuntimeEvent
→ UI/Headless 展示结构化结果
```

## 4. 四种“记住”的区别

| 机制 | 生命周期 | 典型内容 | 权威性 |
| --- | --- | --- | --- |
| Message History | 当前上下文 | 对话和工具交互 | 可能被压缩 |
| Working Memory | 当前任务 | 目标、约束、验证状态 | 压缩时受保护 |
| Session | 跨进程、按任务 | 完整事件和恢复数据 | 运行历史权威来源 |
| Project Memory | 跨会话、按项目 | 已确认约定和经验 | 可过期、可冲突、可删除 |

## 5. 模块的依赖原则

```text
UI/Entry → Runtime → Protocols
Runtime → ModelAdapter / ToolRegistry / Policies / Stores
Adapters → Protocols
Tools → Tooling + Workspace + 专用服务
Policies → State/Signals，不依赖 UI
Stores → Serializable Data，不保存活进程/客户端
Optional Extensions → Runtime Hooks，不成为核心反向依赖
```

如果你发现 `types.py` 导入 TUI、工具直接调用 Provider、Memory 直接修改文件或 Session 保存线程对象，说明依赖方向已经反转。

---

# 第七部分：针对当前项目的优化专题

## 优化 1：拆解超过 2000 行的 `agent_loop.py`

### 现状问题

主循环同时承担任务构建、上下文、记忆注入、模型路由、控制器初始化、模型调用、工具调度、错误恢复、UI 回调和收尾。虽然 `turn_kernel.py` 已经抽走部分策略，但 Loop 仍是集成热点，任何改动都扩大回归面。

### 优化方案

```text
RuntimeBuilder       创建并连接本轮依赖
TurnPrelude          建 Task/Context/Memory 初始状态
ModelGateway         调 Adapter + retry/fallback
ToolExecutor         权限、调度、执行、结果记录
TurnEngine           极小 while loop + Kernel decision
TurnCoda             Session、Metrics、Reflection、最终事件
RuntimeExtensions    控制论/实验能力生命周期钩子
```

最小主循环可以缩成：

```python
while state.can_continue():
    policy = kernel.before_step(state)
    step = model_gateway.next(state.messages, policy)
    decision = kernel.decide(step, state)
    if decision.tool_calls:
        observations = tool_executor.execute(decision.tool_calls)
        state.observe(observations)
        continue
    if decision.is_terminal:
        return coda.finish(state, decision)
```

迁移时先用兼容外观包住旧函数，每次只抽一个职责，并用现有 Agent Loop 测试锁定行为。

## 优化 2：让 `ToolResult` 成为真正的结果通道

当前核心字段主要是 `ok` 和 `output`，导致命令退出码、artifact、摘要和错误类别常被编码进字符串。建议兼容扩展：

```python
@dataclass(slots=True)
class ToolResult:
    ok: bool
    output: str
    summary: str = ""
    error_code: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    artifacts: list[ArtifactRef] = field(default_factory=list)
    await_user: bool = False
```

TUI 使用 `summary`，模型按预算使用 `output`，Runtime 使用 `metadata.exit_code`，Session 保存 artifact 引用。这样不再从自然语言解析系统状态。

## 优化 3：统一类型化事件，替代分散回调

当前 Loop 接受多个 `on_tool_start`、`on_tool_result`、`on_assistant_message`、`on_progress_message`、`on_runtime_event` 回调。新增事件容易漏接某个界面。

建议建立单一 `EventSink.emit(RuntimeEvent)`，事件类型覆盖 AssistantDelta、Progress、ToolStart、ToolResult、PermissionRequested、PhaseChanged、TurnDone、TurnError。旧回调由兼容 Sink 转发，逐步迁移 TUI 和 Headless。

## 优化 4：配置从可变 `dict` 迁移到类型化快照

运行配置在多个模块通过字符串键读取，拼写错误只能运行时发现。建议：

```python
@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    model: str
    provider: ProviderConfig
    runtime_profile: RuntimeProfile
    tool_profile: str = "core"
    trust_project_mcp: bool = False
```

加载阶段可以继续合并字典，但跨越装配边界后只传不可变快照；敏感字段单独放 `SecretConfig`，序列化 Product Snapshot 时自动排除。

## 优化 5：控制论层变成真正可选的扩展

文档把控制论定位为可选层，但当前 `agent_loop.py` 顶部直接导入并在 work-chain 路径初始化大量控制器。建议核心只依赖 Protocol，动态加载扩展；加入不安装/屏蔽控制模块的架构隔离测试。每个控制器必须有 disabled、actuator 和消融证据。

## 优化 6：将 `timeline_memory.py` 从通用产品路径解耦

该模块约 3295 行，包含大量事件领域规则和 LongMemEval 风格的日期/数值问答。建议拆为：

```text
timeline/core.py       通用事件与最新状态索引
timeline/temporal.py   日期和相对时间
timeline/numeric.py    数值事实与聚合
timeline/eval_rules.py 基准专用规则
```

Coding Agent 默认只加载 core，基准或个人助理场景再启用其余插件。这样产品记忆不会被评估特定启发式主导。

## 优化 7：增强文件事务与恢复语义

参考文件审查流程已经有 Diff 和 Checkpoint，但可继续加强：保存原始 bytes、编码、换行、mode、before/after hash；审批后重新核对 hash；使用临时文件原子 replace；edit group 全量预检后统一提交/回退。命令和网络副作用建立单独 side-effect ledger，状态明确为 succeeded/failed/unknown。

## 优化 8：安全边界从“命令分类”升级为执行策略

保留正则风险提示，但增加：

- executable + argv 优先，shell mode 单独授权；
- 环境变量白名单和敏感值屏蔽；
- 可选容器/低权限执行器；
- 网络访问能力标签；
- 解压工具防 Zip Slip/Tar Slip；
- Path.resolve 后检查符号链接/junction；
- 子 Agent 工具视图和工作区 scope。

要在文档中明确：应用权限不等于 OS 沙箱。

## 优化 9：补齐可复现开发依赖

当前本地收集暴露 `hypothesis` 缺失，而 `dev` extra 仅包含 pytest。建议：

```toml
[project.optional-dependencies]
dev = [
  "pytest>=8",
  "hypothesis>=6",
  "ruff>=0.6",
  "mypy>=1.11",
  "build>=1.2",
]
```

若 property tests 或 benchmark 非默认，则分别建 `property`、`benchmark` extra 和 pytest marker；CI 使用项目声明安装，而不是零散 `pip install`。

## 优化 10：测试按风险和速度分层

给测试添加 `unit`、`integration`、`e2e`、`provider`、`benchmark`、`property` 标记。默认 PR 运行 unit + offline integration；平台矩阵跑关键跨平台路径；真实 Provider 单独且不作为离线正确性的替代。性能测试断言算法工作量，墙钟时间只作为报告，避免 CI 抖动。

## 优化 11：减少模块级单例和隐式状态

Auto Mode、Hook Manager、Global Store、Router、Working Memory 等模块存在单例入口，方便 CLI 但增加测试互相污染。复现时把实例收进 `RuntimeServices`，入口负责生命周期；保留 `get_*()` 只作为兼容层，并提供显式 reset/close。

## 优化 12：建立权威架构文档和自动模块清单

当前多个历史文档会随实现演进而过时。建议保留一份权威架构和一份自动生成模块清单；CI 检查所有 `minicode/*.py` 至少有层级、owner/day、核心/可选标记。历史计划移入 archive，README 只描述可验证的当前行为。

---

# 第八部分：毕业答辩题

完成课程后，不看源码回答以下问题：

1. 为什么 Provider Adapter 不能直接调用工具？
2. 为什么工具失败要回填模型，而不是立即抛出结束？
3. 为什么 Tool Call 和 Tool Result 必须用 ID 配对？
4. `workspace.py` 为什么要在 resolve 后判断边界？
5. Prompt 权限声明为什么不能替代执行时权限检查？
6. Checkpoint 能恢复什么，不能恢复什么？
7. Replay、Resume、Rewind 的副作用语义有何不同？
8. 模型说“测试通过”为什么不算验证证据？
9. Context、Working Memory、Session、Project Memory 的边界是什么？
10. 为什么要先做工具输出预算，再做 LLM 摘要？
11. Skills、Hooks、MCP 分别扩展哪一层？
12. 子 Agent 如何限制递归、写冲突和权限扩散？
13. TUI 为什么只能消费 Runtime Event？
14. 控制器输出如何证明真正驱动了 actuator？
15. 什么样的消融结果会让你默认关闭一个高级模块？
16. 为什么 1164 个测试被收集仍不代表项目能在干净环境测试？
17. 如果只能保留 15 个模块，你会保留哪些，为什么？
18. 如何让当前 2267 行的 Agent Loop 渐进拆分而不大爆炸重写？

如果你能用一次完整 Demo 和源码入口回答这些问题，你已经不只是“复现了 MiniCode”，而是掌握了一个本地 Coding Agent 从核心闭环到产品化运行时的设计方法。
