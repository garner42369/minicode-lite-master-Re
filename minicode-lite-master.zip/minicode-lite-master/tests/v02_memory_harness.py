"""第二次集成测试 harness：预置项目记忆 + 真实模型跑任务。

验证 Day 15-20 新能力（尤其跨会话记忆召回）。用法：

    python tests/v02_memory_harness.py "任务指令" --cwd <目录> --seed
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.agent_loop import run_agent_turn
from minicode.config import load_runtime_config
from minicode.cost_tracker import CostTracker
from minicode.hooks import HookManager
from minicode.memory import MemoryManager, MemoryScope
from minicode.memory_pipeline import MemoryPipeline
from minicode.model_registry import build_adapter
from minicode.permissions import Mode, PermissionDecision, PermissionManager, RiskLevel
from minicode.prompt import build_prompt
from minicode.task_object import build_task_object
from minicode.tools import create_full_tool_registry


# 预置的项目记忆：模拟「一个已经积累了几条可复用知识的 workspace」
_SEED_MEMORIES = [
    ("测试命令是 pytest -q", "testing", ["test", "pytest"]),
    ("CI 覆盖率测试命令是 pytest --cov --cov-report=term-missing", "testing", ["cov", "ci"]),
    ("目录约定：文档放 docs/，测试放 tests/", "convention", ["目录"]),
    ("架构决定：运行时零依赖，不用 LangChain 等框架", "architecture", ["架构"]),
]


def seed_memories(cwd: str) -> None:
    """往 workspace 的项目记忆里预置几条知识。"""
    mgr = MemoryManager(cwd)
    for content, category, tags in _SEED_MEMORIES:
        mgr.add(MemoryScope.PROJECT, content, category=category, tags=tags)
    mgr.save()
    print(f"    [预置记忆] 写入 {len(_SEED_MEMORIES)} 条项目记忆\n")


def run_task(task_text: str, cwd: str):
    config = load_runtime_config()
    tools = create_full_tool_registry()
    tracker = CostTracker()
    adapter = build_adapter(config, tools=tools.list(), cost_tracker=tracker)

    def prompt(request):
        if request.risk is RiskLevel.DANGEROUS:
            print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> deny")
            return PermissionDecision("deny_once")
        print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> allow")
        return PermissionDecision("allow_once")

    permissions = PermissionManager(cwd, Mode.AUTO, prompt=prompt)
    task = build_task_object(task_text, model=adapter)

    # Day 23：记忆流水线从 loop 挪到 hook，装配 memory hook 后传给 run_agent_turn
    hooks = HookManager()
    MemoryPipeline(MemoryManager(cwd)).register_hooks(hooks)

    messages = [
        {"role": "system", "content": build_prompt(cwd)},
        {"role": "user", "content": task_text},
    ]

    history, stop = run_agent_turn(
        adapter,
        tools,
        messages,
        cwd,
        task=task,
        permissions=permissions,
        hooks=hooks,
        on_tool_start=lambda c: print(f"    [工具] {c.name}({c.arguments})"),
        on_tool_result=lambda c, r: print(f"    [工具结果] {c.name} ok={r.ok}"),
        on_nudge=lambda n: print(f"    [Kernel拦截] {n}"),
    )
    return history, stop, tracker.totals()


def main():
    parser = argparse.ArgumentParser(description="第二次集成测试 harness")
    parser.add_argument("task", help="任务指令")
    parser.add_argument("--cwd", default=".", help="工作目录")
    parser.add_argument("--seed", action="store_true", help="预置项目记忆")
    args = parser.parse_args()

    if args.seed:
        seed_memories(args.cwd)

    history, stop, totals = run_task(args.task, args.cwd)
    print(f"\n=== 结果 ===")
    print(f"  stop_reason: {stop}")
    print(f"  最终回答: {history[-1]['content'][:800]}")
    print(f"  成本: 调用 {totals.calls} 次, 输入 {totals.input_tokens}, 输出 {totals.output_tokens}, ${totals.cost_usd:.6f}")


if __name__ == "__main__":
    main()
