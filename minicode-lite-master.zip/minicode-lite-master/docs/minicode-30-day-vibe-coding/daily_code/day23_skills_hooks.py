"""Day 23: Skill 按需读取；Hook 有超时和失败策略。"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, TimeoutError
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable


@dataclass(frozen=True, slots=True)
class SkillSummary:
    name: str
    description: str
    path: Path


def discover_skills(root: Path) -> list[SkillSummary]:
    results: list[SkillSummary] = []
    for path in root.glob("*/SKILL.md"):
        lines = path.read_text(encoding="utf-8").splitlines()
        description = next((line.removeprefix("description:").strip() for line in lines if line.startswith("description:")), "")
        results.append(SkillSummary(path.parent.name, description, path))
    return results


def load_skill(summary: SkillSummary, max_chars: int = 20_000) -> str:
    return summary.path.read_text(encoding="utf-8")[:max_chars]


class FailurePolicy(str, Enum):
    CONTINUE = "continue"
    BLOCK = "block"


@dataclass(slots=True)
class Hook:
    event: str
    handler: Callable[[dict], None]
    timeout: float = 1.0
    failure_policy: FailurePolicy = FailurePolicy.CONTINUE


class HookManager:
    def __init__(self) -> None:
        self.hooks: list[Hook] = []

    def fire(self, event: str, payload: dict) -> list[str]:
        errors: list[str] = []
        for hook in (item for item in self.hooks if item.event == event):
            try:
                with ThreadPoolExecutor(max_workers=1) as pool:
                    pool.submit(hook.handler, payload).result(timeout=hook.timeout)
            except (Exception, TimeoutError) as exc:
                errors.append(str(exc))
                if hook.failure_policy is FailurePolicy.BLOCK:
                    raise RuntimeError(f"blocking hook failed: {exc}") from exc
        return errors


if __name__ == "__main__":
    seen: list[str] = []
    manager = HookManager()
    manager.hooks.append(Hook("tool", lambda data: seen.append(data["name"])))
    assert not manager.fire("tool", {"name": "read_file"}) and seen == ["read_file"]
    print("skills/hooks: OK")

