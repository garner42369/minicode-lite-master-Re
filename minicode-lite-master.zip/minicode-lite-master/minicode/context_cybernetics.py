"""minicode 的上下文控制闭环（Day 28）。

两个策略控制上下文占用，回答「自动调整有没有让任务更稳定、更省资源」：

1. **基线（阈值 + 滞回/冷却）**：简单规则，usage 超阈值触发压缩，冷却避免频繁切换。
2. **PID**：连续控制输出，量化成离散压缩动作（课件 daily_code 的 context_action）。

关键（GPT 提醒）：PID 不天然优于阈值——压缩动作是离散的、一次压缩会突然跳变 usage。
所以做「可重复模拟」对比两个策略：同样的压力序列，比溢出次数（稳定）和压缩次数（省资源）。
"""

from __future__ import annotations

from dataclasses import dataclass

from minicode.pid_controller import PID


@dataclass(frozen=True, slots=True)
class ContextAction:
    action: str  # no_op / reduce_tool_budget / micro_compact / full_compact
    reason: str = ""


class ThresholdController:
    """基线策略：阈值 + 滞回/冷却。"""

    def __init__(self, high: float = 0.85, low: float = 0.70, cooldown_turns: int = 2) -> None:
        self.high = high
        self.low = low
        self.cooldown_turns = cooldown_turns
        self._cooldown = 0

    def decide(self, usage_ratio: float, trend_per_turn: float = 0.0) -> ContextAction:
        if self._cooldown > 0:
            self._cooldown -= 1
            return ContextAction("no_op", f"cooldown {self._cooldown + 1}")
        if usage_ratio >= self.high:
            self._cooldown = self.cooldown_turns
            return ContextAction("full_compact", f"usage={usage_ratio:.2f} >= high={self.high}")
        if usage_ratio >= self.low:
            return ContextAction("micro_compact", f"usage={usage_ratio:.2f} >= low={self.low}")
        return ContextAction("no_op", "below threshold")


class PIDContextController:
    """PID 策略：连续输出量化成离散压缩动作。"""

    def __init__(self, setpoint: float = 0.70, kp: float = 2.0, ki: float = 0.1, kd: float = 0.2) -> None:
        self.pid = PID(kp, ki, kd, output_min=-1.0, output_max=1.0)
        self.setpoint = setpoint

    def decide(self, usage_ratio: float, trend_per_turn: float = 0.0) -> ContextAction:
        control = self.pid.update(self.setpoint, usage_ratio)
        return context_action(usage_ratio, trend_per_turn, control)


def context_action(usage_ratio: float, trend_per_turn: float, control: float) -> ContextAction:
    """把 usage / trend / control 映射成离散压缩动作（课件 daily_code 对齐）。"""
    predicted = usage_ratio + trend_per_turn * 3
    if usage_ratio >= 0.90 or predicted >= 1.0:
        return ContextAction("full_compact", f"critical usage={usage_ratio:.2f}")
    if usage_ratio >= 0.75 or predicted >= 0.90:
        return ContextAction("micro_compact", f"high usage={usage_ratio:.2f}")
    if control < -0.4:
        return ContextAction("reduce_tool_budget", f"pid control={control:.2f}")
    return ContextAction("no_op", "healthy")


# 每种动作对 usage 的降低幅度（简化模型）
_COMPACTION_EFFECT = {
    "no_op": 0.0,
    "reduce_tool_budget": 0.05,
    "micro_compact": 0.15,
    "full_compact": 0.40,
}


@dataclass
class SimResult:
    actions: list[str]
    overflows: int       # usage >= 1.0 的次数（不稳定）
    compactions: int     # 压缩动作次数（省资源：越少越好，但太少会溢出）
    final_usage: float


def simulate(
    controller,
    turns: int,
    growth_per_turn: float,
    trend_per_turn: float = 0.0,
    start_usage: float = 0.4,
) -> SimResult:
    """可重复模拟：turns 轮，每轮 usage 增长 growth_per_turn，controller 压缩降 usage。

    溢出（usage >= 1.0）记一次不稳定。返回动作序列 + 溢出次数 + 压缩次数。
    """
    usage = start_usage
    actions: list[str] = []
    overflows = 0
    compactions = 0
    for _ in range(turns):
        action = controller.decide(usage, trend_per_turn)
        actions.append(action.action)
        effect = _COMPACTION_EFFECT.get(action.action, 0.0)
        if effect > 0:
            compactions += 1
        usage = max(0.2, usage - effect)   # 压缩降 usage
        usage += growth_per_turn            # 任务消耗上下文，usage 增长
        if usage >= 1.0:
            overflows += 1
    return SimResult(actions, overflows, compactions, usage)
