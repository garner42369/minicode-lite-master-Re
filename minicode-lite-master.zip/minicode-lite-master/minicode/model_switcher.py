"""minicode 的有界模型 fallback：主模型失败时切换候选，限制次数并记录失败通道。

Day 10 引入。真实模型可能因服务暂不可用（5xx）、限流（429）、网络故障而失败。
有界 fallback 提供「换一个模型再试」的能力，但有严格边界：

1. 只在「明确的 Provider 可用性错误」上切换——认证失败、参数错误这类配置
   问题，fallback 只会把同一个错误带到下一个模型，必须直接抛；
2. 限制候选数量与切换次数，不做无限切换；
3. 不在副作用中途偷偷换模型重放——本层只包装 next()，不碰工具执行。

关键：fallback 发生在「某次 next() 调用失败后、尚未产生工具副作用」的时刻。
工具一旦执行过，Agent 历史里已有 tool_result，此时换模型重放是上层（校验/
恢复）的决策，不是本层的职责。
"""

from __future__ import annotations

from typing import Any, Callable

from minicode.api_retry import classify_exception
from minicode.types import AgentStep, ChatMessage, ModelAdapter


def _adapter_label(adapter: ModelAdapter) -> str:
    """给 adapter 一个可读标识（模型名），用于记录失败通道。

    OpenAIAdapter 内部存了 _model；没有该属性的 adapter（如 Mock）退回类名。
    """
    return getattr(adapter, "_model", type(adapter).__name__)


class ModelSwitcher:
    """包装「主 adapter + 候选 adapter 列表」的有界 fallback。

    每次 next() 依次尝试候选：成功即返回；失败且是可用性错误则切下一个；
    非可用性错误（认证/参数）立即抛出。全部失败则抛最后一次异常。
    """

    def __init__(
        self,
        primary: ModelAdapter,
        fallbacks: list[ModelAdapter] | None = None,
        *,
        max_attempts: int | None = None,
    ) -> None:
        self._primary = primary
        self._fallbacks = list(fallbacks or [])
        # 默认尝试上限 = 主 + 全部候选；可用 max_attempts 收紧
        self._max_attempts = max_attempts if max_attempts is not None else 1 + len(self._fallbacks)
        # 失败通道记录：每切换一次记一条，供上层观测「为什么换了模型」
        self.failed_channels: list[str] = []

    def next(
        self,
        messages: list[ChatMessage],
        on_stream_chunk: Callable[[str], None] | None = None,
        store: Any | None = None,
    ) -> AgentStep:
        candidates = [self._primary] + self._fallbacks
        candidates = candidates[: self._max_attempts]

        last_error: BaseException | None = None
        for adapter in candidates:
            try:
                return adapter.next(messages, on_stream_chunk=on_stream_chunk, store=store)
            except Exception as exc:  # noqa: BLE001 — 需要分类后决定是否 fallback
                # 认证/参数等非可用性错误：换模型无意义，直接抛
                if not classify_exception(exc):
                    raise
                last_error = exc
                self.failed_channels.append(_adapter_label(adapter))

        # 所有候选都因可用性错误失败：抛最后一次异常
        assert last_error is not None
        raise last_error
