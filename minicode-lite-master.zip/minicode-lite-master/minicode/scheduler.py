"""minicode 的工具调度器：并发执行只读工具、串行执行有副作用工具，结果按原顺序回填。

Day 8 引入。核心价值：

1. 只读且并发安全的工具并行执行，缩短一轮多工具的总耗时；
2. 有副作用的工具保持串行，避免副作用竞态；
3. 无论并发完成顺序如何，observations 始终按模型原始调用顺序回填；
4. 每次调用记录指标（名称/耗时/成败/错误类别），供后续观测。

调度只做「分组 + 执行 + 回填 + 记录」，不做决策（并发上限怎么调、何时熔断）
——那属于 Day 27 的控制论。这里只回答「哪些能并发、哪些必须串行」。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from time import perf_counter

from minicode.tooling import ToolContext, ToolRegistry, ToolResult
from minicode.types import ToolCall


@dataclass(slots=True)
class ToolMetric:
    """一次工具执行的指标快照。只记录事实，不做判断。"""

    name: str
    duration_ms: float
    ok: bool
    error_code: str | None = None


@dataclass(slots=True)
class SchedulerResult:
    """一轮工具调度的结果：按原调用顺序的 (调用, 结果) 对 + 本轮指标。"""

    observations: list[tuple[ToolCall, ToolResult]]
    metrics: list[ToolMetric] = field(default_factory=list)


def _is_concurrency_safe(registry: ToolRegistry, name: str) -> bool:
    """工具是否声明并发安全。未知工具视为不安全（归入串行）。"""
    tool = registry.find(name)
    return tool is not None and tool.metadata.is_concurrency_safe


def execute_calls(
    calls: list[ToolCall],
    registry: ToolRegistry,
    context: ToolContext,
) -> SchedulerResult:
    """执行一批工具调用：并发安全的并发跑，其余串行跑，最后按原顺序回填。

    异常隔离由 ToolRegistry.execute 的「异常防火墙」保证——任何工具内部崩溃
    都会被归一化成 ToolResult（ok=False），因此这里的 future.result() 不会抛，
    一个工具的失败也不会丢失其他调用的结果。
    """
    indexed = list(enumerate(calls))
    parallel = [(i, call) for i, call in indexed if _is_concurrency_safe(registry, call.name)]
    serial = [(i, call) for i, call in indexed if not _is_concurrency_safe(registry, call.name)]

    completed: dict[int, tuple[ToolCall, ToolResult]] = {}
    metrics: list[ToolMetric] = []

    def run(item: tuple[int, ToolCall]) -> tuple[int, ToolCall, ToolResult, float]:
        index, call = item
        started = perf_counter()
        result = registry.execute(call.name, call.arguments, context)
        return index, call, result, (perf_counter() - started) * 1000

    if parallel:
        with ThreadPoolExecutor(max_workers=min(4, len(parallel))) as pool:
            futures = [pool.submit(run, item) for item in parallel]
            for future in as_completed(futures):
                index, call, result, duration = future.result()
                completed[index] = (call, result)
                metrics.append(ToolMetric(call.name, duration, result.ok, result.error_code))

    for item in serial:
        index, call, result, duration = run(item)
        completed[index] = (call, result)
        metrics.append(ToolMetric(call.name, duration, result.ok, result.error_code))

    # 关键：按原始索引回填，保证模型看到的顺序与它发出的调用顺序一致
    observations = [completed[i] for i in range(len(calls))]
    return SchedulerResult(observations, metrics)
