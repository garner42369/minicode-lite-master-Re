"""Day 13: 无 shell 的 argv 执行、结构化结果、超时和输出预算。"""

from __future__ import annotations

import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from time import perf_counter


@dataclass(frozen=True, slots=True)
class CommandResult:
    argv: tuple[str, ...]
    exit_code: int | None
    stdout: str
    stderr: str
    duration_ms: float
    timed_out: bool = False
    truncated: bool = False

    @property
    def ok(self) -> bool:
        return self.exit_code == 0 and not self.timed_out


def clip(text: str, limit: int) -> tuple[str, bool]:
    if len(text) <= limit:
        return text, False
    half = limit // 2
    return text[:half] + f"\n...[{len(text) - limit} chars omitted]...\n" + text[-half:], True


def run_command(argv: list[str], cwd: str, timeout: float = 30, output_limit: int = 20_000) -> CommandResult:
    if not argv:
        raise ValueError("argv cannot be empty")
    started = perf_counter()
    try:
        completed = subprocess.run(argv, cwd=Path(cwd), capture_output=True, check=False, timeout=timeout)
        stdout, cut_out = clip(completed.stdout.decode("utf-8", errors="replace"), output_limit)
        stderr, cut_err = clip(completed.stderr.decode("utf-8", errors="replace"), output_limit)
        return CommandResult(tuple(argv), completed.returncode, stdout, stderr, (perf_counter() - started) * 1000, truncated=cut_out or cut_err)
    except subprocess.TimeoutExpired as exc:
        stdout = (exc.stdout or b"").decode("utf-8", errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        return CommandResult(tuple(argv), None, stdout, "timeout", (perf_counter() - started) * 1000, timed_out=True)


if __name__ == "__main__":
    result = run_command([sys.executable, "-c", "print('verified')"], ".")
    assert result.ok and "verified" in result.stdout
    failed = run_command([sys.executable, "-c", "raise SystemExit(2)"], ".")
    assert not failed.ok and failed.exit_code == 2
    print(result)

