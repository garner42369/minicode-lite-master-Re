"""intent_parser：把用户输入分类为 CODE / DEBUG / REFACTOR / SEARCH。

Day 14 引入。意图决定了后续的验证策略（DEBUG 要测试，SEARCH 不用测试），
所以先粗分意图。

两类实现：
- `classify_intent_with_model`：用大模型分类（推荐）——prompt 规范四种意图，模型
  理解语义，不受关键词遗漏影响（「怎么」「如何」「为啥」这些疑问词漏一个就误判）；
- `parse_intent`：轻量关键词启发式（fallback）——模型不可用时的降级。
"""

from __future__ import annotations

from enum import Enum


class Intent(str, Enum):
    """用户意图分类。"""

    CODE = "code"        # 写新代码 / 新功能
    DEBUG = "debug"      # 修复 bug
    REFACTOR = "refactor"  # 重构（不改变行为）
    SEARCH = "search"    # 搜索 / 理解 / 解释


# 关键词集合。匹配顺序重要：先匹配更具体的 DEBUG/REFACTOR，再 SEARCH，
# 都不命中则默认 CODE（因为「做点改动」是最常见的兜底意图）。
_DEBUG_WORDS = {
    "bug", "fix", "debug", "修复", "报错", "错误", "失败", "崩溃",
    "异常", "exception", "error", "broken", "挂",
}
_REFACTOR_WORDS = {
    "refactor", "重构", "重写", "整理", "优化", "clean", "simplify", "改进",
}
_SEARCH_WORDS = {
    "search", "find", "解释", "理解", "查看", "查找", "找", "说明",
    "读取", "读", "打开", "看看", "看",
    "explain", "understand", "what", "how", "在哪里", "read", "list",
    # 中文疑问词（how-to / what / which / where 查询）：之前只补了只读动词，
    # 漏了疑问词，导致「怎么跑测试」这类 how-to 查询被误判为 CODE。
    "怎么", "如何", "为什么", "是什么", "哪些", "哪里",
}


def parse_intent(text: str) -> Intent:
    """从用户输入判断意图（大小写不敏感的关键词匹配，fallback 用）。"""
    lowered = text.lower()
    if any(word in lowered for word in _DEBUG_WORDS):
        return Intent.DEBUG
    if any(word in lowered for word in _REFACTOR_WORDS):
        return Intent.REFACTOR
    if any(word in lowered for word in _SEARCH_WORDS):
        return Intent.SEARCH
    return Intent.CODE


# LLM 意图分类的 prompt：定义四种意图 + 明确只输出标签，让模型结果可控。
_INTENT_CLASSIFY_PROMPT = (
    "你是意图分类器。判断用户输入属于哪一类，只输出一个类别标签。\n"
    "- CODE：写新代码 / 新功能\n"
    "- DEBUG：修复 bug / 错误\n"
    "- REFACTOR：重构（不改变行为）\n"
    "- SEARCH：搜索 / 理解 / 解释 / 查询（只读，不改代码）\n"
    "\n"
    "用户输入：{text}\n"
    "\n"
    "类别标签（只输出 CODE、DEBUG、REFACTOR 或 SEARCH 其中一个）："
)


def classify_intent_with_model(model, text: str) -> Intent:
    """用大模型分类意图；失败/异常 fallback 到关键词 parse_intent。

    为什么用 LLM：关键词启发式要不断补词（「怎么」「如何」「为啥」……漏一个就误判），
    LLM 能理解语义，一次到位。关键词保留作 fallback（模型不可用时的降级）。
    """
    try:
        step = model.next([
            {"role": "user", "content": _INTENT_CLASSIFY_PROMPT.format(text=text)}
        ])
        content = (step.content or "").strip().upper()
        for intent in Intent:
            if intent.value.upper() in content:
                return intent
    except Exception:
        pass
    return parse_intent(text)
