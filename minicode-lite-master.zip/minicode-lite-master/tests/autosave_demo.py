"""Day 15 AutosaveManager 演示：dirty / interval / force save + delta 幂等。

运行（项目根目录）：
    python tests/autosave_demo.py
"""

import sys
import tempfile
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.session import AutosaveManager, SessionData, list_sessions


def main():
    with tempfile.TemporaryDirectory() as directory:
        d = Path(directory)
        session = SessionData.create(".")
        mgr = AutosaveManager(session, d, interval=60.0)  # 大 interval，方便演示

        # 1. dirty + interval：没到时间不保存
        print("== dirty + interval（没到时间不保存）==")
        session.messages.append({"role": "user", "content": "hello"})
        mgr.mark_dirty()
        mgr.maybe_save()
        print(f"  maybe_save 后文件数: {len(list_sessions(d))}（应 0）")

        # 2. force_save：强制保存
        print("\n== force_save（强制保存）==")
        delta = mgr.force_save()
        print(f"  保存后文件数: {len(list_sessions(d))}（应 1）")
        print(f"  本次 delta: {delta}")

        # 3. 幂等：无新增不写盘
        print("\n== 幂等（无新增不写盘）==")
        delta2 = mgr.force_save()
        print(f"  delta2: {delta2}（应空）")
        print(f"  文件数: {len(list_sessions(d))}（应仍 1）")

        # 4. 有新增再保存
        print("\n== 有新增再保存 ==")
        session.messages.append({"role": "user", "content": "world"})
        mgr.mark_dirty()
        delta3 = mgr.force_save()
        print(f"  delta3: {delta3}")


if __name__ == "__main__":
    main()
