"""Day 20: MemoryManager 外面的统一 Pipeline、预算注入和可降级重排。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from day19_project_memory import MemoryEntry, MemoryStore


@dataclass(frozen=True, slots=True)
class InjectionDecision:
    mode: str
    max_entries: int
    max_chars_each: int


def decide_injection(context_ratio: float) -> InjectionDecision:
    if context_ratio >= 0.90:
        return InjectionDecision("off", 0, 0)
    if context_ratio >= 0.75:
        return InjectionDecision("summary", 2, 120)
    return InjectionDecision("full", 5, 500)


class MemoryPipeline:
    def __init__(self, store: MemoryStore, reranker: Callable[[str, list[MemoryEntry]], list[MemoryEntry]] | None = None) -> None:
        self.store, self.reranker = store, reranker

    def inject(self, query: str, context_ratio: float) -> str:
        decision = decide_injection(context_ratio)
        if decision.mode == "off":
            return ""
        candidates = self.store.search(query, limit=10)
        if self.reranker:
            try:
                candidates = self.reranker(query, candidates)
            except Exception:
                pass  # 保留基础检索排序
        selected = candidates[: decision.max_entries]
        return "\n".join(f"- [{m.source}] {m.content[:decision.max_chars_each]}" for m in selected)

    def write_verified_fact(self, content: str, source: str, tags: list[str], verified: bool) -> None:
        if not verified:
            raise ValueError("unverified reflection cannot become project memory")
        self.store.add(content, source, tags)
        self.store.save()


if __name__ == "__main__":
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as directory:
        store = MemoryStore(Path(directory) / "memory.json", "workspace")
        pipeline = MemoryPipeline(store)
        pipeline.write_verified_fact("测试使用 pytest -q", "verified run", ["pytest"], True)
        assert "pytest" in pipeline.inject("pytest", 0.5)
        assert pipeline.inject("pytest", 0.95) == ""
        print("memory pipeline: OK")

