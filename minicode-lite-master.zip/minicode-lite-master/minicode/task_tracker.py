"""task_tracker：多步骤待办进展（任务图）。

Day 14 引入。跟踪 Agent 的待办项及状态，生成 Stable Task Pack 里的进展摘要，
避免长上下文压缩后 Agent 忘记「哪些做了、哪些没做」。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class TodoStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"


@dataclass(slots=True)
class TodoItem:
    """一条待办。"""

    description: str
    status: TodoStatus = TodoStatus.PENDING


class TaskTracker:
    """多步骤待办进展。"""

    def __init__(self) -> None:
        self._items: list[TodoItem] = []

    def add(self, description: str) -> TodoItem:
        """新增一条待办，返回该项（可后续改状态）。"""
        item = TodoItem(description)
        self._items.append(item)
        return item

    def mark(self, index: int, status: TodoStatus) -> None:
        """按索引更新待办状态。"""
        self._items[index].status = status

    def items(self) -> list[TodoItem]:
        return list(self._items)

    def done_count(self) -> int:
        return sum(1 for i in self._items if i.status is TodoStatus.DONE)

    def summary(self) -> str:
        """生成进展摘要（供 Stable Task Pack），用 checkbox 风格标注状态。

        [x] 完成，[-] 进行中，[ ] 待办。
        """
        if not self._items:
            return "(no tasks tracked)"
        lines = []
        for item in self._items:
            if item.status is TodoStatus.DONE:
                mark = "x"
            elif item.status is TodoStatus.IN_PROGRESS:
                mark = "-"
            else:
                mark = " "
            lines.append(f"[{mark}] {item.description}")
        return "\n".join(lines)
