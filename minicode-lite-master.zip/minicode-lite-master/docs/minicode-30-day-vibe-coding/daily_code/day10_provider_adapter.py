"""Day 10: Provider JSON 与内部 AgentStep 之间的纯转换层。

真实 HTTP、流式读取和认证属于 Adapter 的外围；先把转换函数测准。
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from day02_protocols import AgentStep, ChatMessage, ToolCall


@dataclass(frozen=True, slots=True)
class ProviderConfig:
    model: str
    base_url: str
    api_key: str


def to_openai_messages(messages: list[ChatMessage]) -> list[dict[str, Any]]:
    converted: list[dict[str, Any]] = []
    for message in messages:
        role = message["role"]
        if role in {"system", "user", "assistant"}:
            converted.append({"role": role, "content": message.get("content", "")})
        elif role == "tool_result":
            converted.append({"role": "tool", "tool_call_id": message["tool_call_id"], "content": message.get("content", "")})
    return converted


def parse_openai_choice(choice: dict[str, Any]) -> AgentStep:
    message = choice.get("message", {})
    raw_calls = message.get("tool_calls") or []
    if raw_calls:
        calls = []
        for item in raw_calls:
            function = item["function"]
            calls.append(ToolCall(item["id"], function["name"], json.loads(function.get("arguments") or "{}")))
        return AgentStep(type="tool_calls", calls=calls)
    return AgentStep(type="assistant", kind="final", content=message.get("content") or "")


def should_retry(status: int) -> bool:
    return status in {408, 429, 500, 502, 503, 504}


if __name__ == "__main__":
    fixture = {"message": {"tool_calls": [{"id": "c1", "function": {"name": "read_file", "arguments": '{"path":"README.md"}'}}]}}
    step = parse_openai_choice(fixture)
    assert step.calls[0].id == "c1" and step.calls[0].arguments["path"] == "README.md"
    assert should_retry(429) and not should_retry(401)
    print(step)

