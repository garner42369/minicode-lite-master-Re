"""Day 30: 每个场景使用全新 fixture，结果明确区分 PASS/FAIL/SKIP/BLOCKED。"""

from __future__ import annotations

import shutil
import tempfile
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from time import perf_counter
from typing import Callable


class Status(str, Enum):
    PASS = "pass"
    FAIL = "fail"
    SKIP = "skip"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class Scenario:
    name: str
    fixture: Path
    run: Callable[[Path], None]
    verify: Callable[[Path], bool]


@dataclass(frozen=True, slots=True)
class EvalRow:
    name: str
    status: Status
    duration_ms: float
    evidence: str


@dataclass(slots=True)
class Harness:
    rows: list[EvalRow] = field(default_factory=list)

    def evaluate(self, scenario: Scenario) -> EvalRow:
        started = perf_counter()
        with tempfile.TemporaryDirectory() as directory:
            workspace = Path(directory) / "fixture"
            shutil.copytree(scenario.fixture, workspace)
            try:
                scenario.run(workspace)
                passed = scenario.verify(workspace)
                row = EvalRow(scenario.name, Status.PASS if passed else Status.FAIL, (perf_counter() - started) * 1000, "workspace expectation evaluated")
            except PermissionError as exc:
                row = EvalRow(scenario.name, Status.BLOCKED, (perf_counter() - started) * 1000, str(exc))
            except Exception as exc:
                row = EvalRow(scenario.name, Status.FAIL, (perf_counter() - started) * 1000, f"{type(exc).__name__}: {exc}")
        self.rows.append(row)
        return row

    def summary(self) -> dict[str, int]:
        return {status.value: sum(row.status is status for row in self.rows) for status in Status}


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as directory:
        fixture = Path(directory) / "source"
        fixture.mkdir()
        (fixture / "calculator.py").write_text("return a // b\n", encoding="utf-8")
        scenario = Scenario(
            "repair divide",
            fixture,
            lambda root: (root / "calculator.py").write_text("return a / b\n", encoding="utf-8"),
            lambda root: "a / b" in (root / "calculator.py").read_text(encoding="utf-8"),
        )
        harness = Harness()
        assert harness.evaluate(scenario).status is Status.PASS
        print(harness.summary())

