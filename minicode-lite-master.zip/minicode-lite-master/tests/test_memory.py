"""Day 19：项目记忆（MemoryManager）的契约测试。"""

from minicode.memory import MemoryManager, MemoryScope


class TestMemoryCRUD:
    def test_add_list_delete(self, tmp_path):
        mgr = MemoryManager(tmp_path)
        entry = mgr.add(
            MemoryScope.PROJECT, "测试命令是 pytest -q",
            category="convention", tags=["test"],
        )
        assert len(mgr.list(MemoryScope.PROJECT)) == 1
        assert mgr.delete(MemoryScope.PROJECT, entry.id) is True
        assert len(mgr.list(MemoryScope.PROJECT)) == 0
        print(f"\nadd → list → delete: 正常")

    def test_update_and_tag(self, tmp_path):
        mgr = MemoryManager(tmp_path)
        entry = mgr.add(MemoryScope.PROJECT, "旧内容", tags=["a"])
        assert mgr.update(MemoryScope.PROJECT, entry.id, "新内容") is True
        assert mgr.list(MemoryScope.PROJECT)[0].content == "新内容"
        assert mgr.add_tag(MemoryScope.PROJECT, entry.id, "b") is True
        assert mgr.remove_tag(MemoryScope.PROJECT, entry.id, "a") is True
        assert mgr.list(MemoryScope.PROJECT)[0].tags == ["b"]
        print(f"\nupdate + add_tag/remove_tag: 正常")

    def test_scope_isolation(self, tmp_path):
        # 核心契约：不同 workspace 的 project 记忆隔离，不因关键词相同串用
        mgr_a = MemoryManager(tmp_path / "A")
        mgr_b = MemoryManager(tmp_path / "B")
        mgr_a.add(MemoryScope.PROJECT, "A 项目的私有约定")
        assert len(mgr_b.list(MemoryScope.PROJECT)) == 0
        print(f"\nscope 隔离: A 的记忆 B 看不到")

    def test_reject_secret(self, tmp_path):
        # 核心契约：敏感模式内容拒绝落盘
        mgr = MemoryManager(tmp_path)
        for secret in ("api_key=sk-123", "password: abc", "secret token=xyz"):
            try:
                mgr.add(MemoryScope.PROJECT, secret)
                assert False, f"should reject: {secret}"
            except ValueError:
                pass
        assert len(mgr.list(MemoryScope.PROJECT)) == 0
        print(f"\n敏感拒绝: api_key/password/secret/token 一律拒绝")


class TestMemoryPersistence:
    def test_save_load_roundtrip(self, tmp_path):
        # 核心契约：save 后重新载入，记忆跨进程保留
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令 pytest -q", tags=["test"])
        mgr.save()

        mgr2 = MemoryManager(tmp_path)
        entries = mgr2.list(MemoryScope.PROJECT)
        assert len(entries) == 1
        assert entries[0].content == "测试命令 pytest -q"
        print(f"\nsave → 重新 load: 记忆跨进程保留")

    def test_corrupt_file_raises(self, tmp_path):
        # 边界契约：损坏文件抛可诊断 ValueError，不静默清空
        (tmp_path / ".mini-code-memory").mkdir(parents=True)
        (tmp_path / ".mini-code-memory" / "memory.json").write_text("{broken json", encoding="utf-8")
        try:
            MemoryManager(tmp_path)
            assert False, "should raise on corrupt file"
        except ValueError as e:
            print(f"\n损坏文件: {e}")


class TestMemorySearch:
    def test_search_ranks_relevant(self, tmp_path):
        # 核心契约：BM25 检索把最相关的排第一
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing", tags=["pytest"])
        mgr.add(MemoryScope.PROJECT, "架构决定：运行时零依赖", category="architecture")
        results = mgr.search("测试命令")
        assert results[0].content == "测试命令是 pytest -q"
        print(f"\nsearch 排序: {[r.content for r in results]}")

    def test_get_relevant_context_formats_markdown(self, tmp_path):
        # 核心契约：注入入口返回按 category 分组的 markdown
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing", tags=["pytest"])
        text = mgr.get_relevant_context(query="测试")
        assert "Project Memory" in text
        assert "测试命令是 pytest -q" in text
        print(f"\n注入文本:\n{text}")

    def test_delete_stops_injection(self, tmp_path):
        # 课件验收：删除后不再注入
        mgr = MemoryManager(tmp_path)
        entry = mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing")
        assert "测试命令" in mgr.get_relevant_context(query="测试")
        mgr.delete(MemoryScope.PROJECT, entry.id)
        assert "测试命令" not in mgr.get_relevant_context(query="测试")
        print(f"\n删除后不再注入: OK")


class TestMemoryRecovery:
    def test_recovers_corrupt_entries(self, tmp_path):
        # 核心契约：损坏条目恢复——去重 ID、去空 content、修空 category
        import json

        entries = [
            {"id": "a", "content": "正常", "scope": "project", "category": "general"},
            {"id": "a", "content": "重复 ID", "scope": "project", "category": "general"},
            {"id": "b", "content": "", "scope": "project", "category": "general"},
            {"id": "c", "content": "空 category", "scope": "project", "category": ""},
        ]
        (tmp_path / ".mini-code-memory").mkdir(parents=True)
        (tmp_path / ".mini-code-memory" / "memory.json").write_text(
            json.dumps({"entries": entries}, ensure_ascii=False), encoding="utf-8"
        )
        mgr = MemoryManager(tmp_path)
        result = mgr.list(MemoryScope.PROJECT)
        contents = [e.content for e in result]
        print(f"\n恢复后: {contents}")
        assert "正常" in contents            # 正常保留
        assert "重复 ID" not in contents      # 重复 ID 移除
        assert "空 category" in contents      # 空 category 修复保留
        fixed = next(e for e in result if e.content == "空 category")
        assert fixed.category == "general"    # 空 category 补成 general

