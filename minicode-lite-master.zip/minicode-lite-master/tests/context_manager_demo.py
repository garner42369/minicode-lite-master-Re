"""Day 17 context_manager 演示：Token 估算 + 阈值事件去重。

运行（项目根目录）：
    python tests/context_manager_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.context_manager import (
    ContextStats,
    context_window_for,
    estimate_tokens,
    threshold_events,
)


def main():
    # 1. ContextStats + usage_ratio
    stats = ContextStats(70_000, 100_000, 20_000)
    print(f"usage_ratio: {stats.usage_ratio:.3f}（70000/(100000-20000)=0.875）")

    # 2. estimate_tokens（英文约 4 字符/token，中文约 1 字/token）
    print(f"\n英文 token 估算: {estimate_tokens('hello world ' * 20)}")
    print(f"中文 token 估算: {estimate_tokens('你好世界' * 20)}")

    # 3. 阈值事件（去重，不刷屏）
    print("\n== 阈值事件（50/75/90%，去重不刷屏）==")
    fired = set()
    for tokens in (50_000, 76_000, 91_000, 91_000):  # 最后一个重复，不应再触发
        s = ContextStats(tokens, 100_000, 0)
        events = threshold_events(s, fired)
        for e in events:
            print(f"  {e}")

    # 4. 模型窗口表
    print(f"\ndeepseek-v4-pro 窗口: {context_window_for('deepseek-v4-pro')}")
    print(f"未知模型窗口(默认): {context_window_for('unknown-model')}")


if __name__ == "__main__":
    main()
