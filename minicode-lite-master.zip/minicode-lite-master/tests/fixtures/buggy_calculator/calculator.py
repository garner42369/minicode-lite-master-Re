"""演示用计算器，故意引入一个整数除法缺陷。

`divide` 本应返回真除法结果，却误用了整除运算符 `//`。
"""


def add(a, b):
    return a + b


def divide(a, b):
    # BUG: 应为 a / b，这里错写成了整除 a // b。
    return a // b
