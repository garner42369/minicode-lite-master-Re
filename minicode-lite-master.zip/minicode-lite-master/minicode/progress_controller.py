"""minicode 的进度控制器（Day 27）。判断任务是否停滞。

停滞 = 重复动作（同一工具连续多次）+ 无新证据 + 还有剩余预算。检测到停滞时提示调用方
「该换策略了」，而不是继续空转烧预算。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ProgressSignal:
    recent_tool_calls: tuple[str, ...]   # 最近的动作（工具名，按时间序）
    new_evidence_count: int               # 新证据数（新文件/新结果）
    remaining_steps: int                  # 剩余预算


@dataclass(frozen=True, slots=True)
class ProgressDecision:
    stalled: bool
    reason: str


def detect_stall(signal: ProgressSignal, max_repeats: int = 3) -> ProgressDecision:
    """重复动作 + 无新证据 + 有剩余预算 → 停滞。"""
    if signal.remaining_steps <= 0:
        return ProgressDecision(False, "no budget left")

    recent = signal.recent_tool_calls
    if signal.new_evidence_count > 0:
        return ProgressDecision(False, "new evidence arriving")

    # 最近 max_repeats 次都是同一个工具 → 重复动作
    if len(recent) >= max_repeats and len(set(recent[-max_repeats:])) == 1:
        return ProgressDecision(True, f"repeating {recent[-1]} with no new evidence")
    return ProgressDecision(False, "making progress")
