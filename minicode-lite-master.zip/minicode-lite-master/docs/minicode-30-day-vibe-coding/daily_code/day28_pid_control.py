"""Day 28: 带输出限幅和 anti-windup 的 PID，加一个上下文 actuator。"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class PID:
    kp: float
    ki: float
    kd: float
    output_min: float = -1.0
    output_max: float = 1.0
    integral: float = 0.0
    previous_error: float = 0.0

    def update(self, setpoint: float, measurement: float, dt: float = 1.0) -> float:
        error = setpoint - measurement
        candidate_integral = self.integral + error * dt
        derivative = (error - self.previous_error) / max(dt, 1e-9)
        raw = self.kp * error + self.ki * candidate_integral + self.kd * derivative
        output = min(self.output_max, max(self.output_min, raw))
        if output == raw:  # anti-windup: 只在未饱和时接受积分
            self.integral = candidate_integral
        self.previous_error = error
        return output


def context_action(usage_ratio: float, trend_per_turn: float, control: float) -> str:
    predicted = usage_ratio + trend_per_turn * 3
    if usage_ratio >= .90 or predicted >= 1.0:
        return "full_compact"
    if usage_ratio >= .75 or predicted >= .90:
        return "micro_compact"
    if control < -.4:
        return "reduce_tool_budget"
    return "no_op"


if __name__ == "__main__":
    controller = PID(2.0, .1, .2)
    actions = []
    for usage in [.4, .6, .78, .92]:
        signal = controller.update(.70, usage)
        actions.append(context_action(usage, .04, signal))
    assert actions[-1] == "full_compact" and "micro_compact" in actions
    print(actions)

