"""user_profile：用户画像（Day 21 第 4 步）。

解析全局 USER.md（~/.mini-code/USER.md），提取用户语言、解释深度、代码风格三个
偏好。偏好注入 system prompt，但位置在安全约束、协议之后——「偏好低于系统安全与
当前任务指令」（课件第 6 步）：用户说「多解释」不能越过「别泄露密钥」这类红线。
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass
class UserProfile:
    """用户画像：三个偏好字段。空串 = 未设置。"""

    language: str = ""        # 语言偏好（如「中文」）
    verbosity: str = ""       # 解释深度（如「简洁」「详细」）
    coding_style: str = ""    # 代码风格（如「snake_case」）


def global_user_md_path() -> Path:
    """全局 USER.md 路径（跨项目，与 ~/.mini-code/memory 同级）。"""
    return Path.home() / ".mini-code" / "USER.md"


def parse_user_md(content: str) -> UserProfile:
    """解析 USER.md 文本。格式：`## preferences` 段下的 `key: value` 行。"""
    profile = UserProfile()
    in_preferences = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.lower() == "## preferences":
            in_preferences = True
            continue
        if stripped.startswith("## ") and not stripped.lower().startswith("## preferences"):
            in_preferences = False
            continue
        if in_preferences and ":" in stripped:
            key, _, value = stripped.partition(":")
            key = key.strip().lower()
            value = value.strip()
            if key == "language":
                profile.language = value
            elif key == "verbosity":
                profile.verbosity = value
            elif key == "coding_style":
                profile.coding_style = value
    return profile


def to_prompt_section(profile: UserProfile) -> str:
    """转成 prompt 段；无任何内容返回空串（不注入）。"""
    lines: list[str] = []
    if profile.language:
        lines.append(f"Language: {profile.language}")
    if profile.verbosity:
        lines.append(f"Verbosity: {profile.verbosity}")
    if profile.coding_style:
        lines.append(f"Coding style: {profile.coding_style}")
    if not lines:
        return ""
    return "## User Profile\n" + "\n".join(lines)


def load_user_profile() -> UserProfile:
    """加载全局 USER.md。不存在或读取失败返回空画像（不崩溃，偏好是可选的）。"""
    path = global_user_md_path()
    if not path.exists():
        return UserProfile()
    try:
        return parse_user_md(path.read_text(encoding="utf-8"))
    except OSError:
        return UserProfile()
