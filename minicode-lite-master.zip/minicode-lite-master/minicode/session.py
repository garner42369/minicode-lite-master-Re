"""minicode 的 Session 持久化：可版本化、原子保存的会话数据（Day 15 第 1 步）。

进程结束后，Agent 需要知道之前做过什么、改过哪些文件、验证是否有效。
Session 保存的是「重建运行时所需的数据」，不是 Python 对象快照——模型客户端、
线程、进程、回调都不可安全恢复（课件易错点：不 pickle 运行时对象）。

本文件第 1 步落地核心：SessionData 数据结构 + schema version + workspace
identity + 原子保存/载入。管理操作（list/delete/inspect）在下一步。
"""

from __future__ import annotations

import json
import os
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, field, fields
from enum import Enum
from pathlib import Path
from typing import Any

# schema 版本：Session 文件结构一旦变化就递增；载入时校验，旧版本拒绝（可诊断）
SCHEMA_VERSION = 1


@dataclass(slots=True)
class SessionData:
    """一次会话的完整持久化数据。

    所有字段都必须是「可 JSON 序列化的纯数据」——模型客户端、线程、回调等
    运行时对象一律不在此列。
    """

    session_id: str
    workspace: str                       # workspace identity：resolve 后的规范绝对路径
    created_at: float
    updated_at: float
    messages: list[dict[str, Any]] = field(default_factory=list)          # 继续模型对话
    events: list[dict[str, Any]] = field(default_factory=list)            # 人类检查发生过什么
    checkpoints: list[dict[str, Any]] = field(default_factory=list)       # 预览/回退文件
    task_state: dict[str, Any] = field(default_factory=dict)              # 完成/暂停/失败
    verification_evidence: dict[str, Any] = field(default_factory=dict)   # 验证是否仍有效
    runtime_snapshot: dict[str, Any] = field(default_factory=dict)        # 脱敏环境快照
    cost_usage: dict[str, Any] = field(default_factory=dict)              # token/成本
    schema_version: int = SCHEMA_VERSION

    @classmethod
    def create(cls, workspace: str) -> "SessionData":
        """创建新会话：生成 session_id、规范 workspace、初始化时间戳。"""
        now = time.time()
        return cls(
            session_id=uuid.uuid4().hex,
            workspace=str(Path(workspace).resolve()),
            created_at=now,
            updated_at=now,
        )


def save_session(session: SessionData, directory: Path) -> Path:
    """原子保存 Session 到 directory/<session_id>.json。

    原子写（mkstemp + os.replace）保证：保存中断不会留下「半截 JSON」被当成
    有效会话。返回保存的文件路径。
    """
    directory.mkdir(parents=True, exist_ok=True)
    session.updated_at = time.time()
    target = directory / f"{session.session_id}.json"
    fd, temporary = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(asdict(session), handle, ensure_ascii=False, indent=2)
        os.replace(temporary, target)
    except Exception:
        Path(temporary).unlink(missing_ok=True)
        raise
    return target


def load_session(path: Path) -> SessionData:
    """从 JSON 载入 Session。

    旧 schema、损坏文件都抛出可诊断的 ValueError；JSON 里的多余字段被忽略
    （容忍 schema 演进），缺字段用 dataclass 默认值。
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"corrupt session file: {path}") from exc
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"unsupported session schema: {data.get('schema_version')}")
    known = {f.name for f in fields(SessionData)}
    return SessionData(**{k: v for k, v in data.items() if k in known})


@dataclass(slots=True)
class SessionSummary:
    """一个 session 的摘要（供 list-sessions 展示，不载入完整数据）。"""

    session_id: str
    workspace: str
    created_at: float
    updated_at: float
    message_count: int = 0
    event_count: int = 0
    checkpoint_count: int = 0


def list_sessions(directory: Path) -> list[SessionSummary]:
    """列出 directory 下所有 session 摘要，按 updated_at 降序。

    损坏/旧 schema 的单个文件跳过，不让列表因一个坏文件整体失败。
    """
    summaries: list[SessionSummary] = []
    if not directory.exists():
        return summaries
    for path in directory.glob("*.json"):
        try:
            session = load_session(path)
        except ValueError:
            continue
        summaries.append(
            SessionSummary(
                session_id=session.session_id,
                workspace=session.workspace,
                created_at=session.created_at,
                updated_at=session.updated_at,
                message_count=len(session.messages),
                event_count=len(session.events),
                checkpoint_count=len(session.checkpoints),
            )
        )
    summaries.sort(key=lambda s: s.updated_at, reverse=True)
    return summaries


def delete_session(directory: Path, session_id: str) -> bool:
    """删除指定 session 文件，返回是否删除成功。"""
    try:
        (directory / f"{session_id}.json").unlink(missing_ok=True)
        return True
    except OSError:
        return False


def cleanup_old_sessions(directory: Path, keep: int) -> list[str]:
    """保留最近 keep 个 session，删除更旧的，返回被删除的 session_id 列表。"""
    removed: list[str] = []
    for summary in list_sessions(directory)[keep:]:
        if delete_session(directory, summary.session_id):
            removed.append(summary.session_id)
    return removed


def format_session_inspect(session: SessionData) -> str:
    """只读展示一个 session 的运行时摘要（供 inspect 命令，不修改任何状态）。"""
    lines = [
        f"session_id: {session.session_id}",
        f"workspace: {session.workspace}",
        f"schema_version: {session.schema_version}",
        f"created_at: {session.created_at}",
        f"updated_at: {session.updated_at}",
        f"messages: {len(session.messages)}",
        f"events: {len(session.events)}",
        f"checkpoints: {len(session.checkpoints)}",
    ]
    if session.events:
        lines.append("recent events:")
        for event in session.events[-3:]:
            lines.append(f"  - {event}")
    return "\n".join(lines)


class SideEffectStatus(str, Enum):
    """有副作用步骤的执行状态（Day 16 resume 用）。

    resume 时最危险的是「结果未知」的步骤——例如进程在命令已启动、结果尚未
    保存时崩溃，重放会重复执行副作用。所以 running/unknown 必须标记出来，
    先让用户/运行时核实，不能自动重放。
    """

    PENDING = "pending"      # 待执行（还没执行，无副作用）
    RUNNING = "running"      # 已启动、结果未知
    SUCCEEDED = "succeeded"  # 成功，结果已确认
    FAILED = "failed"        # 失败，结果已确认
    UNKNOWN = "unknown"      # 结果未知（崩溃，无法确认）


def needs_verification(status: SideEffectStatus) -> bool:
    """判断一个副作用步骤是否需要核实（结果未知，不能自动重放）。"""
    return status in {SideEffectStatus.RUNNING, SideEffectStatus.UNKNOWN}


def format_session_replay(session: SessionData) -> str:
    """只读回放：格式化 session 的事件历史，供人类查看「发生过什么」。

    纯只读：不调用模型、不执行工具、不读文件（只读内存中的 events）。
    因此 replay 前后工作区 hash 必然一致，也不会产生新进程。
    """
    if not session.events:
        return "(no events)"
    return "\n".join(
        f"{event.get('type', '?')}: {event.get('summary', '')}"
        for event in session.events
    )


def compute_delta(session: SessionData, base_counts: dict[str, int]) -> dict[str, list]:
    """计算自 base_counts 以来的增量（新增的消息/事件/checkpoint）。

    幂等：相同 base_counts 反复调用返回相同结果；无新增时返回空列表。
    base_counts 形如 {"messages": N, "events": N, "checkpoints": N}。
    """
    return {
        "messages": session.messages[base_counts["messages"]:],
        "events": session.events[base_counts["events"]:],
        "checkpoints": session.checkpoints[base_counts["checkpoints"]:],
    }


class AutosaveManager:
    """自动保存管理器：dirty 标记 + 间隔保存 + 强制保存 + 幂等 delta 追踪。

    dirty：有变化才可能保存；interval：到时间才触发；force：无条件立即保存。
    用 saved_counts 记录上次保存时的条目数，无新增时 force_save 幂等（不写盘）。
    """

    def __init__(self, session: SessionData, directory: Path, interval: float = 30.0) -> None:
        self._session = session
        self._directory = directory
        self._interval = interval
        self._dirty = False
        # 初始化为当前时间（而非 0.0）：否则首次 maybe_save 时 now - 0.0 会
        # 远大于 interval，导致第一次就误触发保存
        self._last_save = time.monotonic()
        self._saved_counts = {"messages": 0, "events": 0, "checkpoints": 0}
        self.saved_path: Path | None = None

    def mark_dirty(self) -> None:
        """标记有未保存的变化。"""
        self._dirty = True

    def maybe_save(self) -> None:
        """如果 dirty 且距上次保存超过 interval，触发保存。"""
        if self._dirty and (time.monotonic() - self._last_save) >= self._interval:
            self.force_save()

    def force_save(self) -> dict[str, list]:
        """强制保存。无新增（delta 为空）时幂等——不写盘，直接返回空 delta。"""
        delta = compute_delta(self._session, self._saved_counts)
        if not any(delta.values()):
            self._dirty = False
            return delta
        # 首版全量写（压平）；「只写增量文件」的 delta 格式留作后续优化
        self.saved_path = save_session(self._session, self._directory)
        self._saved_counts = {
            "messages": len(self._session.messages),
            "events": len(self._session.events),
            "checkpoints": len(self._session.checkpoints),
        }
        self._dirty = False
        self._last_save = time.monotonic()
        return delta
