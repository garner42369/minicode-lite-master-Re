"""Day 11: 类型化权限请求、模式和最小作用域决策。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable, Literal


class Mode(str, Enum):
    PLAN = "plan"
    DEFAULT = "default"
    AUTO = "auto"
    BYPASS = "bypass"


Decision = Literal["allow_once", "allow_turn", "deny_once", "deny_with_feedback"]


@dataclass(frozen=True, slots=True)
class PermissionRequest:
    kind: Literal["path", "command", "edit"]
    scope: str
    summary: str
    risk: Literal["safe", "low", "medium", "high", "dangerous"]


class PermissionManager:
    def __init__(self, workspace: str, mode: Mode = Mode.DEFAULT, prompt: Callable[[PermissionRequest], Decision] | None = None) -> None:
        self.workspace = Path(workspace).resolve()
        self.mode = mode
        self.prompt = prompt
        self.turn_scopes: set[tuple[str, str]] = set()

    def check(self, request: PermissionRequest) -> Decision:
        if self.mode is Mode.BYPASS:
            return "allow_once"
        if self.mode is Mode.PLAN and request.kind != "path":
            return "deny_once"
        if self.mode is Mode.AUTO and request.risk in {"safe", "low"}:
            return "allow_once"
        if (request.kind, request.scope) in self.turn_scopes:
            return "allow_turn"
        if self.prompt is None:
            return "deny_once"
        decision = self.prompt(request)
        if decision == "allow_turn":
            self.turn_scopes.add((request.kind, request.scope))
        return decision


if __name__ == "__main__":
    plan = PermissionManager(".", Mode.PLAN)
    edit = PermissionRequest("edit", "demo.py", "apply diff", "medium")
    assert plan.check(edit) == "deny_once"
    auto = PermissionManager(".", Mode.AUTO)
    read = PermissionRequest("path", str(Path(".").resolve()), "read", "safe")
    assert auto.check(read) == "allow_once"
    print("permissions: OK")

