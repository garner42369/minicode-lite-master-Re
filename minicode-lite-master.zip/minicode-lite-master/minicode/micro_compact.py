"""micro_compact：确定性轻量裁剪，不调用模型（Day 17）。

Layer 1 压缩（课件）：去掉重复 / 低价值细节，不调用模型。它只做确定性裁剪
（去连续重复、去空消息），不做语义摘要——LLM 摘要压缩是 Day 18 的事。

为什么确定性：裁剪规则是纯函数、可预测、可测试，不引入模型语义判断的不可控性。
"""

from __future__ import annotations

from typing import Any


def micro_compact(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """确定性轻量裁剪消息历史。

    规则：
    1. 连续两条完全相同的消息 → 去重；
    2. assistant / assistant_progress 的空 content → 去空（低价值细节）。

    保留消息顺序和所有非重复内容，不改变语义；不调用模型。
    """
    compacted: list[dict[str, Any]] = []
    for msg in messages:
        # 去连续重复
        if compacted and compacted[-1] == msg:
            continue
        # 去空 assistant 内容（进度播报的空消息无价值）
        role = msg.get("role", "")
        content = msg.get("content", "")
        if role in ("assistant", "assistant_progress") and isinstance(content, str) and not content.strip():
            continue
        compacted.append(msg)
    return compacted
