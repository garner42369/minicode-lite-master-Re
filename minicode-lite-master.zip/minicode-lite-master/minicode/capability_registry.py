"""minicode 的能力注册表（Day 25）。

CapabilityRegistry 是「能力目录」——系统有哪些能力、各属什么领域/范围/是否启用，供
Readiness、诊断、ProductSnapshot 查询。它是纯元数据登记表，**不是执行注册表**：
执行在 ToolRegistry，调用统计需接真实调用路径（现在无「诊断哪个能力没用」的场景，
后置，见 DECISIONS D21）。

参考项目 capability_registry.py 的依赖图 / 标签索引 / 搜索 / 装饰器是「大量能力的可
发现性」功能，我们能力只有几个，裁剪掉（裁剪复现，非完整复现）。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Capability:
    """一个能力的自描述元数据。frozen：登记后不可篡改。"""

    name: str
    domain: str  # tool / memory / external / system / context ...
    scope: str   # workspace / external / system ...
    enabled: bool = True
    description: str = ""


class CapabilityRegistry:
    """能力目录：按名字登记，查询启用/全部能力。"""

    def __init__(self) -> None:
        self._capabilities: dict[str, Capability] = {}

    def register(self, capability: Capability) -> None:
        if capability.name in self._capabilities:
            raise ValueError(f"duplicate capability: {capability.name}")
        self._capabilities[capability.name] = capability

    def get(self, name: str) -> Capability | None:
        return self._capabilities.get(name)

    def has(self, name: str) -> bool:
        return name in self._capabilities

    def list_enabled(self) -> list[str]:
        return [name for name, c in self._capabilities.items() if c.enabled]

    def list_all(self) -> list[str]:
        return list(self._capabilities.keys())
