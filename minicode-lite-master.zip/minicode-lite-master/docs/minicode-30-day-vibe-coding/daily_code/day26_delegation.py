"""Day 26: 有依赖的任务图、受限子任务合同和并发槽位。"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable


class TaskState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass(frozen=True, slots=True)
class TaskContract:
    id: str
    goal: str
    agent_type: str
    read_only: bool
    max_steps: int
    dependencies: tuple[str, ...] = ()


@dataclass(slots=True)
class TaskResult:
    summary: str
    inspected: list[str] = field(default_factory=list)
    changed: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)
    verification: str = ""


class TaskGraph:
    def __init__(self, max_slots: int = 2) -> None:
        self.max_slots = max_slots
        self.tasks: dict[str, TaskContract] = {}
        self.states: dict[str, TaskState] = {}

    def add(self, task: TaskContract) -> None:
        self.tasks[task.id], self.states[task.id] = task, TaskState.PENDING

    def ready(self) -> list[TaskContract]:
        running = sum(state is TaskState.RUNNING for state in self.states.values())
        slots = max(0, self.max_slots - running)
        return [task for task in self.tasks.values() if self.states[task.id] is TaskState.PENDING and all(self.states.get(dep) is TaskState.DONE for dep in task.dependencies)][:slots]


def run_subtask(task: TaskContract, worker: Callable[[TaskContract], TaskResult]) -> TaskResult:
    if task.agent_type in {"explore", "plan"} and not task.read_only:
        raise PermissionError(f"{task.agent_type} tasks must be read-only")
    result = worker(task)
    if task.read_only and result.changed:
        raise RuntimeError("read-only subtask reported file changes")
    return result


if __name__ == "__main__":
    graph = TaskGraph(2)
    graph.add(TaskContract("models", "分析模型层", "explore", True, 10))
    graph.add(TaskContract("tools", "分析工具层", "explore", True, 10))
    assert len(graph.ready()) == 2
    result = run_subtask(graph.ready()[0], lambda task: TaskResult(f"done: {task.goal}", ["model.py"]))
    assert not result.changed
    print(result)

