"""verification_controller：风险自适应验证计划。

Day 14 引入。不是所有任务都要测试——只读解释任务（SEARCH）不需要 pytest，
但改了 Python 核心代码至少要求目标测试。验证等级随风险变化：
NONE（无验证）/ TARGETED（目标测试）/ FULL（全量验证）。

课件验收：文档解释任务不被强制要求 pytest；Python 核心代码修改至少要求目标测试。
"""

from __future__ import annotations

from enum import Enum

from minicode.intent_parser import Intent


class VerificationLevel(str, Enum):
    NONE = "none"          # 无验证（只读/未改代码）
    TARGETED = "targeted"  # 目标测试
    FULL = "full"          # 全量验证


def plan_verification(
    intent: Intent,
    changed_files: tuple[str, ...] = (),
) -> VerificationLevel:
    """根据意图与改动范围决定验证等级。

    规则：
    - 无改动，或意图是 SEARCH（只读解释）→ NONE；
    - 改动里没有 Python 源码（只动了测试/文档/配置）→ NONE；
    - 改了单个 Python 源码文件 → TARGETED；
    - 改了多个 Python 源码文件 → FULL（影响面大，需全量）。
    """
    if not changed_files or intent is Intent.SEARCH:
        return VerificationLevel.NONE

    core_files = [f for f in changed_files if f.endswith(".py") and "test" not in f.lower()]
    if not core_files:
        return VerificationLevel.NONE
    if len(core_files) > 1:
        return VerificationLevel.FULL
    return VerificationLevel.TARGETED


def requires_verification(level: VerificationLevel) -> bool:
    """验证等级是否需要验证（供 turn_kernel.decide_final 使用）。"""
    return level is not VerificationLevel.NONE
