"""Day 12 write_file 工具演示：新建/替换 + 审批。

运行（项目根目录）：
    python tests/write_file_demo.py

展示：审批通过时新建文件成功（checkpoint existed=False），审批拒绝时文件不变。
"""

import sys
import tempfile
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.permissions import Mode, PermissionDecision, PermissionManager
from minicode.tooling import ToolContext
from minicode.tools.write_file import WRITE_FILE


def make_context(directory, auto_allow=True):
    """构造带权限层的 ToolContext。auto_allow=False 时模拟用户拒绝。"""

    def prompt(request):
        print(f"  [审批] {request.kind.value}: {request.scope}")
        print(f"  [diff]\n{request.summary}")
        return PermissionDecision("allow_once" if auto_allow else "deny_once")

    permissions = PermissionManager(str(directory), Mode.DEFAULT, prompt=prompt)
    return ToolContext(cwd=str(directory), permissions=permissions)


def main():
    with tempfile.TemporaryDirectory() as directory:
        # 1. 新建文件（审批通过）
        print("== 新建文件（审批通过）==")
        context = make_context(directory, auto_allow=True)
        data = WRITE_FILE.validator({"path": "hello.py", "content": "print('hello')\n"})
        result = WRITE_FILE.run(data, context)
        print(f"  result: ok={result.ok}, {result.output}")
        print(f"  文件: {(Path(directory) / 'hello.py').read_text(encoding='utf-8')!r}")

        # 2. 覆盖文件（审批拒绝，文件不变）
        print("\n== 覆盖文件（审批拒绝）==")
        context_deny = make_context(directory, auto_allow=False)
        data2 = WRITE_FILE.validator({"path": "hello.py", "content": "print('changed')\n"})
        result2 = WRITE_FILE.run(data2, context_deny)
        print(f"  result: ok={result2.ok}, {result2.output}")
        print(f"  文件(应不变): {(Path(directory) / 'hello.py').read_text(encoding='utf-8')!r}")


if __name__ == "__main__":
    main()
