import sys
from pathlib import Path

from ..calculator import divide
from ..formatter import format_result


def test_divide_returns_true_division():
    # 真除法：5 / 2 == 2.5。缺陷实现（//）返回 2，此处应失败。
    assert divide(5, 2) == 2.5


def test_format_result():
    assert format_result("divide", 2.5) == "divide = 2.5"
