"""state.py：进程内可观察状态（State Store）。

Day 15 引入。与持久 Session 严格区分：

- Session 保存「历史」——messages / events / checkpoints，落盘供恢复；
- State Store 保存「当前」——此刻的 task / turn / phase 等运行时状态，内存供
  UI 观察。

进程结束 State Store 就消失；要恢复的是 Session，不是 State Store。因此
State Store 不取代持久 Session，两者职责互补、不可混用。
"""

from __future__ import annotations

from typing import Any


class StateStore:
    """进程内可观察状态的 key-value 容器。

    调用方（agent_loop / UI）用 set/get 读写当前运行状态；snapshot 返回副本
    供 UI 只读观察，避免外部直接改动内部状态。
    """

    def __init__(self) -> None:
        self._values: dict[str, Any] = {}

    def set(self, key: str, value: Any) -> None:
        """写入一条当前状态。"""
        self._values[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """读取一条当前状态。"""
        return self._values.get(key, default)

    def snapshot(self) -> dict[str, Any]:
        """返回全部状态的副本（供 UI 观察，外部改动不影响内部）。"""
        return dict(self._values)

    def clear(self) -> None:
        """清空状态（新的一轮开始时调用）。"""
        self._values.clear()
