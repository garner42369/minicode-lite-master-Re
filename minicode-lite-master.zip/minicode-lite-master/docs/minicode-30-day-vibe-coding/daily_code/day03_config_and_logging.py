"""Day 3: 纯配置合并、校验和敏感字段脱敏。"""

from __future__ import annotations

from dataclasses import dataclass, replace
from urllib.parse import urlparse


@dataclass(frozen=True, slots=True)
class RuntimeConfig:
    model: str = "mock"
    base_url: str = ""
    api_key: str = ""
    tool_profile: str = "core"


def merge_config(base: RuntimeConfig, **overrides: object) -> RuntimeConfig:
    allowed = {name for name in RuntimeConfig.__dataclass_fields__}
    clean = {key: value for key, value in overrides.items() if key in allowed and value not in (None, "")}
    return replace(base, **clean)


def validate_config(config: RuntimeConfig) -> list[str]:
    errors: list[str] = []
    if config.model != "mock" and not config.api_key:
        errors.append("api_key is required for a real model")
    if config.base_url and urlparse(config.base_url).scheme not in {"http", "https"}:
        errors.append("base_url must use http or https")
    return errors


def safe_snapshot(config: RuntimeConfig) -> dict[str, str]:
    masked = "not set" if not config.api_key else f"***{config.api_key[-4:]}"
    return {"model": config.model, "base_url": config.base_url, "api_key": masked, "tool_profile": config.tool_profile}


if __name__ == "__main__":
    cfg = merge_config(RuntimeConfig(), model="demo-model", api_key="secret-1234")
    assert not validate_config(cfg)
    assert "secret" not in str(safe_snapshot(cfg))
    print(safe_snapshot(cfg))

