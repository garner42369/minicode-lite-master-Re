"""minicode 的受控写入：文件变更的审查、checkpoint 与原子写入（Day 12）。

Day 12 引入。这是「第一次允许 Agent 改文件」的基础设施。目标不是「能写」，
而是修改前可审查、修改后可追踪、出问题可恢复。

本文件第 1 步先落地四个原语（纯函数/数据结构）：
- Checkpoint：修改前快照，记录原始内容与哈希，供恢复；
- digest：内容哈希（sha256），用于并发检查；
- unified_diff：生成 unified diff，供审批展示；
- atomic_write：原子写入（临时文件 + os.replace），避免写一半崩溃留下半成品。

审批事务（apply_reviewed_change）在下一步实现。
"""

from __future__ import annotations

import difflib
import hashlib
import os
import tempfile
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True, slots=True)
class Checkpoint:
    """一次文件修改前的快照。

    before 存 bytes 而非 str：bytes 能精确保留原始字节（编码、换行、BOM），
    恢复时逐字节还原，不因 decode/encode 往返丢失信息。
    group_id 是 edit group 标识：同一用户任务的多个文件修改共享，便于整体回滚。
    """

    path: str          # 文件路径
    existed: bool      # 修改前文件是否存在（新建时 False）
    before: bytes      # 原始内容（用于恢复）
    before_hash: str   # 原始内容哈希（并发检查用）
    after_hash: str    # 写入后内容哈希
    group_id: str      # edit group 标识


def digest(data: bytes) -> str:
    """内容哈希：sha256 十六进制。用于「审批窗口内文件是否被改」的并发检查。"""
    return hashlib.sha256(data).hexdigest()


def unified_diff(path: str, before: str, after: str) -> str:
    """生成 unified diff，供审批时展示「将要做什么」。

    lineterm="" 避免 difflib 默认在每行末尾加换行导致多余空行。
    """
    return "\n".join(
        difflib.unified_diff(
            before.splitlines(),
            after.splitlines(),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
            lineterm="",
        )
    )


def atomic_write(path: Path, data: bytes) -> None:
    """原子写入：先写同目录临时文件，再 os.replace 覆盖目标。

    为什么用 mkstemp(dir=path.parent) + os.replace：
    - mkstemp 在目标目录创建临时文件，保证与目标在同一文件系统，os.replace
      才能原子地完成替换（不跨设备拷贝）；
    - os.replace 是原子操作，不会出现「写一半崩溃留下半成品」；
    - 失败时清理临时文件，不留下垃圾。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        os.replace(temp_name, path)
    except Exception:
        Path(temp_name).unlink(missing_ok=True)
        raise


def apply_reviewed_change(
    path: Path,
    transform: Callable[[str], str],
    approve: Callable[[str], bool],
    group_id: str,
) -> Checkpoint | None:
    """执行一次受控文件变更，顺序严格：diff → 审批 → checkpoint → 哈希复查 → 原子写。

    transform：before 文本 → after 文本（由具体工具提供，如单替换/多替换/完整替换）。
               若找不到匹配应抛 ValueError，本函数不捕获，让错误传播给工具层。
    approve：对 diff 文本做审批，返回 False 表示拒绝。
    返回 Checkpoint；若 after 与 before 完全相同（无变化），返回 None 且不写文件。

    为什么审批后要再读文件做哈希复查：
    审批窗口内（用户看 diff 的那段时间），文件可能被外部（用户/其他进程）修改。
    若不复查，就会用旧 before 构造的 after 覆盖掉外部修改，静默丢失他人工作。
    """
    existed = path.exists()
    before_bytes = path.read_bytes() if existed else b""
    before_text = before_bytes.decode("utf-8")

    # 无变化短路：after == before 时不产生 diff、不审批、不写入
    after_text = transform(before_text)
    if after_text == before_text:
        return None

    # 1. 生成 diff
    diff_text = unified_diff(path.name, before_text, after_text)

    # 2. 审批
    if not approve(diff_text):
        raise PermissionError("edit denied")

    # 3. 审批后再读，做乐观并发检查（防审批窗口内被外部修改）
    current = path.read_bytes() if path.exists() else b""
    if digest(current) != digest(before_bytes):
        raise RuntimeError("file changed after review")

    # 4. 原子写入
    after_bytes = after_text.encode("utf-8")
    checkpoint = Checkpoint(
        path=str(path),
        existed=existed,
        before=before_bytes,
        before_hash=digest(before_bytes),
        after_hash=digest(after_bytes),
        group_id=group_id,
    )
    atomic_write(path, after_bytes)
    return checkpoint


def preview_rewind(checkpoints: list[Checkpoint]) -> list[str]:
    """只读预览回退动作：展示每个文件将被「恢复」还是「删除」。"""
    return [
        f"{'restore' if cp.existed else 'delete'} {cp.path} [{cp.group_id}]"
        for cp in checkpoints
    ]


def rewind_group(checkpoints: list[Checkpoint]) -> None:
    """按 edit group 原子回退：先预检全部文件，任一冲突则整个组不写。

    冲突 = 当前文件 hash != checkpoint.after_hash（用户/其他进程后来改过）。
    预检全部通过才恢复，保证不会产生「半回退」状态。
    新建文件（existed=False）的 before 是「不存在」，回退动作是删除该文件。
    """
    # 1. 预检：全部文件的当前 hash 必须等于 after_hash
    conflicts: list[str] = []
    for cp in checkpoints:
        target = Path(cp.path)
        current = target.read_bytes() if target.exists() else b""
        if digest(current) != cp.after_hash:
            conflicts.append(cp.path)
    if conflicts:
        raise RuntimeError("rewind conflicts: " + ", ".join(conflicts))

    # 2. 恢复（预检全部通过才执行，保证原子性；恢复也用原子写）
    for cp in checkpoints:
        target = Path(cp.path)
        if cp.existed:
            atomic_write(target, cp.before)
        else:
            target.unlink(missing_ok=True)


@dataclass(frozen=True, slots=True)
class RewindRecord:
    """一次回退的审计记录。frozen：记录不可被中途篡改。

    只描述「回退动作」（哪些文件 restore/delete），不保存 after 内容——
    因此它支持审计，但不支持「撤销回退」（撤销需要 after 内容，留作后续）。
    """

    timestamp: float
    actions: tuple[tuple[str, str], ...]  # (动作, 路径)：restore / delete


def build_rewind_record(checkpoints: list[Checkpoint]) -> RewindRecord:
    """生成回退记录（审计用），描述将要执行的回退动作。"""
    return RewindRecord(
        timestamp=time.time(),
        actions=tuple(
            ("restore" if cp.existed else "delete", cp.path) for cp in checkpoints
        ),
    )
