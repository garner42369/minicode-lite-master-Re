"""输出格式化辅助函数。"""


def format_result(operation, result):
    return f"{operation} = {result}"
