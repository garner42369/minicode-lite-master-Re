"""验收测试：健壮性（空响应、连续失败、超大输出、超时、二进制）。"""

from minicode.mock_model import ScriptedModel
from minicode.tools import create_core_tool_registry
from minicode.types import AgentStep


class TestRobustness:
    def test_empty_response_retries_then_stops(self):
        # 模型连续返回空内容，应在有限重试后停止（不无限循环）
        model = ScriptedModel([
            AgentStep(type="assistant", kind="final", content=""),
            AgentStep(type="assistant", kind="final", content=""),
            AgentStep(type="assistant", kind="final", content=""),
        ])
        from minicode.agent_loop import run_agent_turn
        history, stop = run_agent_turn(model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], ".", empty_response_retry_limit=2)
        assert stop == "empty_response"

    def test_consecutive_failures_stops(self, tmp_path):
        # 模型连续调同一个不存在的工具，达阈值应停止（不无限踩坑）
        from minicode.agent_loop import run_agent_turn
        from minicode.types import ToolCall

        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "no_such_tool", {})]),
            AgentStep(type="tool_calls", calls=[ToolCall("2", "no_such_tool", {})]),
            AgentStep(type="tool_calls", calls=[ToolCall("3", "no_such_tool", {})]),
        ])
        history, stop = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "做点事"}], str(tmp_path),
            max_consecutive_failures=3,
        )
        assert stop == "max_failures"

    def test_binary_file_read_returns_clear_error(self, tmp_path):
        # 读二进制文件应返回清晰错误，不崩溃
        from minicode.tooling import ToolContext
        from minicode.tools.read_file import READ_FILE

        (tmp_path / "bin.dat").write_bytes(b"\x00\x01\x02\xff\xfe")
        result = READ_FILE.run({"path": "bin.dat"}, ToolContext(cwd=str(tmp_path)))
        assert not result.ok
        assert result.error_code == "binary_file"

    def test_read_nonexistent_file_returns_not_found(self, tmp_path):
        from minicode.tooling import ToolContext
        from minicode.tools.read_file import READ_FILE

        result = READ_FILE.run({"path": "nope.txt"}, ToolContext(cwd=str(tmp_path)))
        assert not result.ok
        assert result.error_code == "not_found"
