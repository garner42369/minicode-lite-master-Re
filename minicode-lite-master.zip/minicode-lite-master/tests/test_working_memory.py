"""Day 17：working_memory 受保护工作记忆的契约测试。"""

from minicode.working_memory import WorkingMemory


class TestWorkingMemory:
    def test_set_and_get(self):
        memory = WorkingMemory()
        memory.set("goal", "修复 divide bug")
        print(f"goal={memory.get('goal')!r}")
        assert memory.get("goal") == "修复 divide bug"
        assert memory.get("missing") is None

    def test_protected_facts_sorted_by_importance(self):
        memory = WorkingMemory()
        memory.set("a", "低", importance=1)
        memory.set("b", "高", importance=10)
        memory.set("c", "中", importance=5)
        facts = memory.protected_facts()
        print(f"facts={facts}")
        assert facts == ["高", "中", "低"]  # 按重要度降序

    def test_evict_expired(self):
        memory = WorkingMemory()
        memory.set("perm", "永久", ttl=float("inf"))
        memory.set("temp", "临时", ttl=0.01)  # 极短 TTL
        import time

        time.sleep(0.02)
        expired = memory.evict_expired()
        print(f"expired={expired}, perm 仍在={memory.get('perm') is not None}")
        assert "temp" in expired
        assert memory.get("temp") is None
        assert memory.get("perm") == "永久"
