"""minicode 的交互式入口（Day 21：CLI 交互循环 + 本地命令路由）。

与 headless.py 共享同一个 RuntimeFactory 装配。入口只做「装配 + 路由」，不做智能
决策——本地管理命令（/memory、/sessions 等）不进模型，用户任务进模型（课件 Day 21
「本地命令路由，明确是否进入模型」）。
"""

from __future__ import annotations

import argparse
from pathlib import Path

from minicode.config import load_runtime_config
from minicode.history import InputHistory
from minicode.logging_config import setup_logging
from minicode.memory import MemoryManager, MemoryScope
from minicode.permissions import Mode, PermissionDecision, PermissionRequest
from minicode.runtime_factory import RuntimeFactory
from minicode.session import list_sessions

_HELP_TEXT = """本地命令：
  /help          显示帮助
  /model         显示当前模型
  /readiness     就绪检查（ready/degraded/blocked）
  /instructions  列出指令层
  /extensions    列出扩展（skills + MCP）
  /memory        列出项目记忆
  /sessions      列出会话
  /exit          退出

其他输入作为用户任务，进入模型。"""


def _local_command(text: str, runtime) -> str | None:
    """本地命令路由。返回处理结果；None 表示「用户任务，进入模型」。

    /readiness、/instructions、/extensions 统一读 runtime.snapshot（启动时快照），
    不重复收集状态（Day 25「Prompt、CLI、Session 共用同一快照」）。
    """
    t = text.strip()
    if t in ("/help", "/?"):
        return _HELP_TEXT
    if t == "/model":
        return f"model: {load_runtime_config().model}"
    if t == "/readiness":
        r = runtime.snapshot.readiness
        lines = [f"readiness: {r.status}"]
        lines.extend(f"  - {reason}" for reason in r.reasons)
        lines.append(f"capabilities: {', '.join(runtime.snapshot.capabilities)}")
        return "\n".join(lines)
    if t == "/instructions":
        layers = runtime.snapshot.instructions
        active = [l for l in layers if l.exists]
        if not active:
            return "instructions: no active layers"
        return "\n".join(f"- {l.name} ({l.scope}) {l.path}" for l in active)
    if t == "/extensions":
        exts = runtime.snapshot.extensions
        if not exts:
            return "extensions: none"
        lines = []
        for e in exts:
            if e["type"] == "skill":
                lines.append(f"- skill: {e['name']} (source={e['source']})")
            else:
                lines.append(f"- mcp: {e['name']} (status={e['status']}, command={e['command']})")
        return "\n".join(lines)
    if t == "/memory":
        entries = MemoryManager(runtime.cwd).list(MemoryScope.PROJECT)
        if not entries:
            return "(no project memory)"
        return "\n".join(f"- {e.content}" for e in entries)
    if t == "/sessions":
        summaries = list_sessions(Path(runtime.cwd) / "minicode_session")
        if not summaries:
            return "(no sessions)"
        return "\n".join(f"- {s.session_id[:8]}  updated={s.updated_at:.0f}" for s in summaries)
    if t.startswith("/"):
        return f"unknown command: {t} (try /help)"
    return None


def _make_cli_prompt():
    """交互式审批 prompt：询问用户是否允许本次有副作用操作。"""

    def prompt(request: PermissionRequest) -> PermissionDecision:
        print(f"[审批] {request.kind.value}: {request.scope} (risk={request.risk.value})")
        ans = input("允许? [y/N/是/否] ").strip().lower()
        if ans in ("y", "yes", "allow", "是", "允许", "好", "ok"):
            return PermissionDecision("allow_once")
        return PermissionDecision("deny_once")

    return prompt


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="minicode-py", description="本地 AI Coding Agent Runtime")
    parser.add_argument("--cwd", default=".", help="工作目录")
    parser.add_argument("--mode", default="auto", choices=[m.value for m in Mode], help="权限模式")
    parser.add_argument("--log-level", default="INFO", help="日志级别（DEBUG/INFO/WARNING/ERROR）")
    args = parser.parse_args(argv)

    setup_logging(level=args.log_level)

    cwd = str(Path(args.cwd).resolve())
    factory = RuntimeFactory(mode=Mode(args.mode), prompt=_make_cli_prompt())
    runtime = factory.create(cwd)
    history = InputHistory()

    print(f"minicode 启动（cwd={cwd}，输入 /help 看本地命令，/exit 退出）")
    try:
        while True:
            try:
                user_input = input("> ")
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if user_input.strip() in ("/exit", "/quit"):
                break
            history.add(user_input)  # 只保存非空、去重后的输入（InputHistory 内部处理）

            result = _local_command(user_input, runtime)
            if result is not None:
                print(result)
                continue

            # 用户任务：进模型
            history_messages, stop = runtime.run(
                user_input,
                on_tool_start=lambda c: print(f"[工具] {c.name}({c.arguments})"),
                on_tool_result=lambda c, r: print(f"[结果] {c.name} ok={r.ok}"),
                on_nudge=lambda n: print(f"[Kernel] {n}"),
            )
            final = history_messages[-1].get("content", "") if history_messages else ""
            print(final)
            print(f"(stop_reason={stop})")
    finally:
        runtime.dispose()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
