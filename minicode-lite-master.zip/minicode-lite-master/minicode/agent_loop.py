"""minicode 的 Agent 主循环：模型—工具—模型闭环。

这是整个 MiniCode 的「心脏」。最小闭环：
在步数预算内循环：调 model.next(history) → 最终文本结束 / 进度继续 / 工具请求执行并回填。

后续的记忆、控制论、路由等能力，都解释为「在这个闭环前后加的策略」。
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from minicode.intent_parser import Intent
from minicode.runtime_profiles import SEARCH_MAX_STEPS
from minicode.scheduler import execute_calls
from minicode.circuit_breaker import CompactionCircuitBreaker
from minicode.context_compactor import ReadDedupManager, ToolResultBudgetManager, compact_messages, reactive_truncate
from minicode.context_manager import DEFAULT_CONTEXT_WINDOW, estimate_tokens
from minicode.control_orchestrator import ControlOrchestrator, Signals
from minicode.hooks import HookEvent, HookManager
from minicode.task_object import TaskObject
from minicode.tooling import ToolContext, ToolRegistry, ToolResult
from minicode.turn_kernel import TurnState, decide_final, stable_task_pack, upsert_project_memory, upsert_stable_task_message
from minicode.types import AgentStep, ChatMessage, ModelAdapter, ToolCall

# 空响应时的唤醒提示：模型返回空内容时，作为 user 消息注入，让它再试一次。
# 用 user 而非 system：空响应没有 tool_result 通道可附，且只有 user 能让模型产生下一个回复。
_NUDGE_AFTER_EMPTY = (
    "你上次的回复为空。这可能发生在工具出错或不确定下一步时。"
    "请选择最可能的下一步动作：调用工具、修改代码，或给出 <final> 结束。"
)

# 写工具：调用成功后要记录「文件版本」，供 Kernel 判断验证证据是否覆盖当前内容。
_WRITE_TOOLS = {"write_file", "edit_file", "patch_file"}

# 上下文压缩：token 使用率达到窗口的 _COMPACT_RATIO 时压缩，保留最近 _COMPACT_KEEP_RECENT 条
# 对话历史（非 system 消息）。记忆（stable task state）是 system 消息，不参与计数。
_COMPACT_KEEP_RECENT = 24   # 压缩后保留的最近消息数
_COMPACT_RATIO = 0.8        # 高水位：使用率 ≥ 80% 才触发压缩

# 预算提示标记：子 Agent 每轮动态注入「剩余轮数」，让模型知道自己还剩几步、
# 接近上限时收敛探索写报告（而不是靠提示词让它自行计数）。
_BUDGET_MARKER = "[Budget]"


def upsert_budget_hint(messages: list[ChatMessage], remaining: int) -> list[ChatMessage]:
    """把剩余预算作为独立 system 消息注入（子 Agent 每轮倒数）。

    remaining 是「含本轮」的剩余模型轮数。upsert（删旧 + 加新）保持消息列表里
    只有一条预算提示、不累积。最后一轮（remaining==0）提示模型别再请求工具。
    """
    if remaining <= 0:
        hint = "This is your final model turn. Do not request more tools. Report your findings now and state any incomplete checks."
    else:
        hint = f"Remaining model turns: {remaining + 1}, including this turn. Finish only essential checks, then produce your final report."
    filtered = [
        m for m in messages
        if not (m.get("role") == "system" and str(m.get("content", "")).startswith(_BUDGET_MARKER))
    ]
    filtered.append({"role": "system", "content": f"{_BUDGET_MARKER}\n{hint}"})
    return filtered


def run_agent_turn(
    model: ModelAdapter,
    tools: ToolRegistry,
    messages: list[ChatMessage],
    cwd: str,
    *,
    max_steps: int = 10,
    empty_response_retry_limit: int = 3,
    max_consecutive_failures: int = 3,
    on_tool_start: Callable[[ToolCall], None] | None = None,
    on_tool_result: Callable[[ToolCall, ToolResult], None] | None = None,
    on_assistant_message: Callable[[AgentStep], None] | None = None,
    on_nudge: Callable[[str], None] | None = None,
    on_compact: Callable[[dict], None] | None = None,
    task: TaskObject | None = None,
    permissions: object | None = None,
    hooks: HookManager | None = None,
    depth: int = 0,
    announce_budget: bool = False,
    orchestrator: ControlOrchestrator | None = None,
) -> tuple[list[ChatMessage], str]:
    """执行一轮 Agent 闭环，返回 (历史消息, 停止原因)。

    停止原因："done"（最终回答）、"max_steps"（预算耗尽）、
    "empty_response"（空响应重试达上限）、"max_failures"（同工具连续失败达阈值）。

    设计约定：UI 只通过 on_tool_start / on_tool_result / on_assistant_message /
    on_compact 可选回调接收事件，核心循环不 import 任何 UI 模块。
    on_compact 在压缩发生时触发，传压缩事件（strategy/tokens/messages_removed），
    供调用方持久化到 Session——原始完整历史由调用方持有，不被压缩覆盖。
    WHY：让 Loop 与具体界面（TUI / Headless / 测试）解耦——同一份核心
    逻辑可被多个消费者复用，也便于离线测试。
    """
    # 复制输入，避免修改调用方的列表。
    # WHY：messages 由调用方传入，若直接 append，调用方会在不知情时看到
    # 自己的列表被污染，且无法用同一份 messages 重复运行多次。
    history: list[ChatMessage] = list(messages)
    context = ToolContext(cwd, permissions=permissions, depth=depth, model=model, tools=tools)
    # 工具结果预算 + 读取去重：写 tool_result 前落盘大结果、去重重复读（turn 级生命周期）
    tool_budget = ToolResultBudgetManager(Path(cwd) / ".mini-code-tool-results")
    read_dedup = ReadDedupManager()
    # 压缩熔断：连续压缩无效时阻断，改用保底激进截断（turn 级生命周期）
    compaction_breaker = CompactionCircuitBreaker()
    # 记忆流水线已从 loop 挪出（Day 23）：MemoryPipeline 作为扩展注册到 hook，
    # loop 只在 AGENT_START / AGENT_STOP 事件点 fire，不再 import MemoryPipeline。
    empty_responses = 0

    def _finish(history: list[ChatMessage], reason: str) -> tuple[list[ChatMessage], str]:
        """任务结束统一出口：fire AGENT_STOP（记忆反馈等扩展挂在此事件），再返回。"""
        if hooks is not None:
            hooks.fire_sync(HookEvent.AGENT_STOP, task_success=(reason == "done"))
        return history, reason
    consecutive_failures = 0
    last_failed_tool: str | None = None

    # SEARCH（只读解释）任务用更小预算：只读不需要深度探索，防无限探索耗尽步数
    if task is not None and task.intent is Intent.SEARCH:
        max_steps = min(max_steps, SEARCH_MAX_STEPS)

    # Kernel 集成：task 传入时启用「显式验证门槛」（改了代码必须验证才能结束）；
    # task 为 None 时行为与 Day 7 完全一致，不破坏既有调用。
    state = TurnState(max_steps=max_steps) if task is not None else None
    requires_verify = task is not None and task.intent is not Intent.SEARCH

    force_compact = False  # Day 29：orchestrator 的 compact 动作标记，下一轮发请求前强制压缩
    for step_idx in range(max_steps):
        if announce_budget:
            history = upsert_budget_hint(history, max_steps - step_idx - 1)
        if state is not None:
            state.step = step_idx
            # 发请求前：token 超阈值则压缩，再注入最新记忆。
            # WHY 顺序必须「先压缩、后注入」：压缩只动对话历史，注入的记忆作为
            # system 消息在压缩时不参与，保证记忆永远是「最新状态」且不混进摘要
            # （详见 docs/memory-context-mixing.md）。
            usage = sum(estimate_tokens(str(m)) for m in history)
            if force_compact or usage > DEFAULT_CONTEXT_WINDOW * _COMPACT_RATIO:
                if compaction_breaker.is_allowed():
                    before_count = len(history)
                    history = compact_messages(history, _COMPACT_KEEP_RECENT)
                    after = sum(estimate_tokens(str(m)) for m in history)
                    if after < usage:
                        compaction_breaker.record_success()
                        if on_compact is not None:
                            on_compact({
                                "type": "compaction",
                                "strategy": "full",
                                "tokens_before": usage,
                                "tokens_after": after,
                                "messages_removed": before_count - len(history),
                            })
                    else:
                        # 压缩无效（压了 usage 没降）——累计失败，达阈值熔断
                        compaction_breaker.record_failure()
                else:
                    # 熔断后：改用保底激进截断，保证有限次结束、不死循环
                    before_count = len(history)
                    history = reactive_truncate(history)
                    if on_compact is not None:
                        on_compact({
                            "type": "compaction",
                            "strategy": "reactive",
                            "messages_removed": before_count - len(history),
                        })
            force_compact = False  # 重置本轮触发标记
            history = upsert_stable_task_message(
                history, stable_task_pack(task, state).to_protected_text()
            )
            # 注入项目记忆（Day 23 起经 AGENT_START hook）：记忆流水线是注册到
            # hook 的扩展，loop 只 fire 事件；注入文本经 inject_box 可变容器传回。
            context_ratio = usage / DEFAULT_CONTEXT_WINDOW
            inject_box: dict[str, str] = {}
            if hooks is not None:
                hooks.fire_sync(
                    HookEvent.AGENT_START,
                    task=task,
                    context_ratio=context_ratio,
                    inject_box=inject_box,
                )
            project_text = inject_box.get("project_text", "")
            if project_text:
                history = upsert_project_memory(history, project_text)
        step = model.next(history)

        if step.type == "assistant":
            # 空响应：内容为空的 assistant 既不是有效最终回答，也不该当作 done。
            # WHY：真实模型可能因网络抖动/不确定而返回空，若直接结束会丢失任务；
            # 有限重试避免死循环（达上限即停）。
            if not step.content.strip():
                empty_responses += 1
                if empty_responses >= empty_response_retry_limit:
                    return _finish(history, "empty_response")
                history.append({"role": "user", "content": _NUDGE_AFTER_EMPTY})
                continue

            if on_assistant_message is not None:
                on_assistant_message(step)
            # 区分进度与最终：进度（progress）只播报、继续循环；最终（final）才结束。
            # WHY：若不区分，模型在进度播报后 Loop 会错误地提前结束。
            role = "assistant_progress" if step.kind == "progress" else "assistant"
            assistant_msg: ChatMessage = {"role": role, "content": step.content}
            # 思考链透传：最终回答的 reasoning 也随历史保存，供压缩/重放时完整回传
            if step.reasoning:
                assistant_msg["reasoning"] = step.reasoning
            history.append(assistant_msg)
            if step.kind != "progress":
                # Kernel 决策：验证门槛未满足时拦截 final，注入 nudge 让模型继续
                if state is not None:
                    decision = decide_final(state, requires_verify)
                    if not decision.terminal:
                        # 拦截 final：把 nudge 注入历史，并通知观测方（如 UI/demo）
                        if on_nudge is not None:
                            on_nudge(f"{decision.reason}: {decision.nudge}")
                        history.append({"role": "user", "content": decision.nudge})
                        continue
                return _finish(history, "done")
            continue

        # 工具请求：走调度器（并发/串行分组 + 原顺序回填）
        for call in step.calls:
            if hooks is not None:
                hooks.fire_sync(HookEvent.PRE_TOOL_USE, tool_name=call.name, tool_input=call.arguments)
            if on_tool_start is not None:
                on_tool_start(call)

        scheduled = execute_calls(step.calls, tools, context)

        for call, result in scheduled.observations:
            if hooks is not None:
                hooks.fire_sync(
                    HookEvent.POST_TOOL_USE,
                    tool_name=call.name,
                    tool_output=result.output,
                    is_error=not result.ok,
                )
            if on_tool_result is not None:
                on_tool_result(call, result)

            # Kernel 跟踪：写工具成功记录文件版本；test_runner 成功记录验证
            if state is not None:
                if call.name in _WRITE_TOOLS and result.ok:
                    version = result.metadata.get("after_hash", "")
                    state.record_change(version)
                elif call.name == "test_runner" and result.ok:
                    state.record_verification(state.changed_version, passed=True)

            # 追踪「同一工具连续失败」，达阈值即停，防止模型反复踩同一个坑。
            if not result.ok:
                if call.name == last_failed_tool:
                    consecutive_failures += 1
                else:
                    consecutive_failures = 1
                    last_failed_tool = call.name
            else:
                consecutive_failures = 0
                last_failed_tool = None

            # 一次工具调用写两条历史。
            # WHY：assistant_tool_call 表示「模型要求做了什么」，tool_result 表示
            # 「环境实际发生了什么」。只有结果没有请求，Provider 无法维持协议；
            # 只有请求没有结果，下一轮模型不知道动作是否成功。
            history.append({
                "role": "assistant_tool_call",
                "tool_call_id": call.id,
                "tool_name": call.name,
                "input": call.arguments,
                # 思考链回传必需：DeepSeek V4 带工具调用的 assistant 消息若缺
                # reasoning_content 会返回 400。同一步多个调用共享同一段 reasoning。
                "reasoning": step.reasoning,
            })
            # 工具结果预算 + 读取去重：大结果落盘 artifact、重复读返回 stub
            output = result.output
            if not isinstance(output, str):
                output = "" if output is None else str(output)
            if call.name == "read_file":
                path = str((call.arguments or {}).get("path", ""))
                output, _ = read_dedup.process(path, output)
                # read_file 已按 offset/limit 分页、模型可控读取量，不再经 tool_budget
                # 外置（否则 8000 字符结果被压成前后各 1000，读 artifact 又外置，死循环）
                budget_meta: dict = {}
            else:
                output, budget_meta = tool_budget.process(output)
            tool_result_msg = {
                "role": "tool_result",
                "tool_call_id": call.id,
                "tool_name": call.name,
                "content": output,
                "is_error": not result.ok,
            }
            if budget_meta.get("artifact"):
                tool_result_msg["artifact"] = budget_meta["artifact"]
            history.append(tool_result_msg)

        # Day 29：工具执行后，控制编排器检查信号决定动作
        if orchestrator is not None:
            total = len(scheduled.observations)
            failed = sum(1 for _, r in scheduled.observations if not r.ok)
            signals = Signals(
                context_ratio=sum(estimate_tokens(str(m)) for m in history) / DEFAULT_CONTEXT_WINDOW,
                tool_error_rate=failed / total if total else 0.0,
                repeated_failures=consecutive_failures,
            )
            for action in orchestrator.after_tool(signals):
                if action.name == "compact":
                    force_compact = True

        if consecutive_failures >= max_consecutive_failures:
            return _finish(history, "max_failures")

    return _finish(history, "max_steps")
