"""history.py：用户输入历史，服务于上/下键浏览与快速复用。

Day 15 引入。与 Session 严格区分：Session 保存完整运行状态（messages/events/
checkpoints/...），history 只保存「用户输入」这一层，服务于 TUI 的上/下键
浏览和快速复用。它不能代替 Session。
"""

from __future__ import annotations


class InputHistory:
    """用户输入历史（进程内）。

    上/下键导航用 cursor 记录当前浏览位置：上键从最新往旧翻，下键从旧往新翻，
    越过末尾返回 None（表示回到「当前未提交的输入」）。
    """

    def __init__(self, max_entries: int = 1000) -> None:
        self._entries: list[str] = []
        self._max_entries = max_entries
        self._cursor: int | None = None  # None = 未在历史导航中

    def add(self, text: str) -> None:
        """追加一条输入。空串或与上一条相同则忽略（去重），并重置导航位置。"""
        text = text.strip()
        if not text:
            return
        if self._entries and self._entries[-1] == text:
            return
        self._entries.append(text)
        if len(self._entries) > self._max_entries:
            self._entries.pop(0)
        self._cursor = None

    def previous(self) -> str | None:
        """上键：返回更早的一条历史；没有历史返回 None。"""
        if not self._entries:
            return None
        if self._cursor is None:
            self._cursor = len(self._entries) - 1
        elif self._cursor > 0:
            self._cursor -= 1
        return self._entries[self._cursor]

    def next(self) -> str | None:
        """下键：返回更新的一条历史；越过末尾返回 None。"""
        if self._cursor is None or not self._entries:
            return None
        self._cursor += 1
        if self._cursor >= len(self._entries):
            self._cursor = None
            return None
        return self._entries[self._cursor]

    def entries(self) -> list[str]:
        """返回全部历史（副本）。"""
        return list(self._entries)
