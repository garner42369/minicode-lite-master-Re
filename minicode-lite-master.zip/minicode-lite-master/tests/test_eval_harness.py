"""Day 30：评估 harness 的契约测试。"""

from minicode.eval_harness import Harness, Scenario, Status


def _make_fixture(tmp_path):
    fixture = tmp_path / "source"
    fixture.mkdir()
    (fixture / "calc.py").write_text("return a // b\n", encoding="utf-8")
    return fixture


class TestHarness:
    def test_pass(self, tmp_path):
        fixture = _make_fixture(tmp_path)
        scenario = Scenario(
            "fix divide",
            fixture,
            lambda root: (root / "calc.py").write_text("return a / b\n", encoding="utf-8"),
            lambda root: "a / b" in (root / "calc.py").read_text(encoding="utf-8"),
        )
        row = Harness().evaluate(scenario)
        assert row.status is Status.PASS
        print(f"\nPASS: {row}")

    def test_fail(self, tmp_path):
        fixture = _make_fixture(tmp_path)
        scenario = Scenario(
            "noop",
            fixture,
            lambda root: None,  # 不修改
            lambda root: "a / b" in (root / "calc.py").read_text(encoding="utf-8"),
        )
        row = Harness().evaluate(scenario)
        assert row.status is Status.FAIL
        print(f"\nFAIL: {row}")

    def test_blocked(self, tmp_path):
        fixture = _make_fixture(tmp_path)
        scenario = Scenario(
            "blocked",
            fixture,
            lambda root: (_ for _ in ()).throw(PermissionError("path escapes workspace")),
            lambda root: True,
        )
        row = Harness().evaluate(scenario)
        assert row.status is Status.BLOCKED
        print(f"\nBLOCKED: {row}")

    def test_summary(self, tmp_path):
        fixture = _make_fixture(tmp_path)
        harness = Harness()
        harness.evaluate(Scenario("pass", fixture, lambda r: (r / "calc.py").write_text("a / b\n", encoding="utf-8"), lambda r: "a / b" in (r / "calc.py").read_text()))
        harness.evaluate(Scenario("fail", fixture, lambda r: None, lambda r: False))
        summary = harness.summary()
        assert summary["pass"] == 1
        assert summary["fail"] == 1
        print(f"\n汇总: {summary}")
