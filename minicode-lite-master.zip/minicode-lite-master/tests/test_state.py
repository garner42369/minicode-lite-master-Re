"""Day 15：state State Store 的契约测试。"""

from minicode.state import StateStore


class TestStateStore:
    def test_set_and_get(self):
        store = StateStore()
        store.set("phase", "explore")
        store.set("step", 3)
        print(f"phase={store.get('phase')}, step={store.get('step')}")
        assert store.get("phase") == "explore"
        assert store.get("step") == 3

    def test_get_missing_key_returns_default(self):
        store = StateStore()
        print(f"missing={store.get('missing')!r}, with_default={store.get('missing', 'fallback')!r}")
        assert store.get("missing") is None
        assert store.get("missing", "fallback") == "fallback"

    def test_snapshot_returns_copy_not_reference(self):
        # 核心契约：snapshot 返回副本，外部改动不污染内部状态
        store = StateStore()
        store.set("a", 1)
        snap = store.snapshot()
        snap["a"] = 999  # 改副本
        print(f"内部 a={store.get('a')}, 副本 a={snap['a']}")
        assert store.get("a") == 1

    def test_clear_removes_all(self):
        store = StateStore()
        store.set("a", 1)
        store.set("b", 2)
        store.clear()
        print(f"clear 后 snapshot={store.snapshot()}")
        assert store.snapshot() == {}
