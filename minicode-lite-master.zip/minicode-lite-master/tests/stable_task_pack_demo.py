"""Day 18 Stable Task Pack 演示：目标/约束/验证状态打包 + 记忆注入 + 压缩保留。

核心：stable_task_pack 产出结构化快照（每轮重建），to_protected_text 渲染后通过
upsert_stable_task_message 作为独立 system 消息注入；压缩时 system 消息原样保留，
记忆不进摘要。

运行（项目根目录）：
    python tests/stable_task_pack_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.task_object import TaskObject
from minicode.intent_parser import Intent
from minicode.turn_kernel import (
    TurnState, stable_task_pack, protect_stable_task_pack,
    upsert_stable_task_message, STABLE_TASK_STATE_MARKER,
)
from minicode.working_memory import WorkingMemory
from minicode.context_compactor import compact_messages


def show(state, label):
    print(f"\n== {label} ==")
    pack = stable_task_pack(task, state)
    print(pack.to_protected_text())


def main():
    global task
    task = TaskObject(
        goal="修复 divide 的整除 bug",
        intent=Intent.DEBUG,
        constraints=("不要改 formatter.py", "不要改测试文件"),
    )

    # 四种验证状态：未修改 / 修改后未验证 / 修改后验证通过 / 修改后验证失败
    show(TurnState(), "未修改（无验证状态行）")

    s2 = TurnState()
    s2.record_change("ver-abc")
    show(s2, "已修改、未验证")

    s3 = TurnState()
    s3.record_change("ver-abc")
    s3.record_verification("ver-abc", passed=True)
    show(s3, "已修改、验证通过")

    s4 = TurnState()
    s4.record_change("ver-abc")
    s4.record_verification("ver-abc", passed=False)
    show(s4, "已修改、验证失败")

    # protect_stable_task_pack 用固定 key 写进工作记忆（覆盖不残留）
    print("\n== protect_stable_task_pack 写进工作记忆 ==")
    memory = WorkingMemory()
    protect_stable_task_pack(memory, task, s4)
    print("工作记忆 render():")
    print(memory.render())

    # 记忆注入 + 压缩：记忆作为 system 消息保留，摘要不含记忆
    print("\n== 记忆注入 + 压缩 ==")
    messages = [
        {"role": "user", "content": "修复 divide 的整除 bug"},
        {"role": "assistant_tool_call", "tool_call_id": "1", "tool_name": "read_file", "input": {"path": "calculator.py"}},
        {"role": "tool_result", "tool_call_id": "1", "tool_name": "read_file", "content": "def divide(a, b): return a // b"},
        {"role": "assistant_tool_call", "tool_call_id": "2", "tool_name": "read_file", "input": {"path": "formatter.py"}},
        {"role": "tool_result", "tool_call_id": "2", "tool_name": "read_file", "content": "PermissionError: 无权限", "is_error": True},
        {"role": "user", "content": "把 // 改成 /"},
        {"role": "assistant_tool_call", "tool_call_id": "3", "tool_name": "edit_file", "input": {"path": "calculator.py"}},
        {"role": "tool_result", "tool_call_id": "3", "tool_name": "edit_file", "content": "edited"},
        {"role": "assistant_tool_call", "tool_call_id": "4", "tool_name": "run_command", "input": {"argv": ["python", "-c", "print(5//2)"]}},
        {"role": "tool_result", "tool_call_id": "4", "tool_name": "run_command", "content": "2"},
        {"role": "assistant_tool_call", "tool_call_id": "5", "tool_name": "run_command", "input": {"argv": ["pytest", "-q"]}},
        {"role": "tool_result", "tool_call_id": "5", "tool_name": "run_command", "content": "1 failed", "is_error": True},
        {"role": "assistant", "content": "测试失败，继续修"},
    ]
    # 记忆注入（每轮发请求前做，这里是演示）
    messages = upsert_stable_task_message(messages, stable_task_pack(task, s4).to_protected_text())
    compacted = compact_messages(messages, keep_recent=2)
    for m in compacted:
        role = m["role"]
        detail = m.get("content", "") or m.get("input", {})
        print(f"  {role}: {str(detail)!r}")

    # 验证：记忆 system 消息保留，摘要不含记忆
    has_memory = any(
        m.get("role") == "system"
        and str(m.get("content", "")).startswith(STABLE_TASK_STATE_MARKER)
        for m in compacted
    )
    print(f"\n  记忆 system 消息保留: {has_memory}")


if __name__ == "__main__":
    main()
