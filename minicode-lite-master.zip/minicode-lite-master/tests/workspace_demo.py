"""Day 11 工作区路径边界演示：is_within_workspace / resolve_workspace_path。

运行（项目根目录）：
    python tests/workspace_demo.py

展示 Windows 路径边界的判定：工作区内、../、绝对外部、大小写、盘符、UNC。
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path：命令行 `python tests/xxx.py` 时 sys.path[0] 是 tests/
# 而非项目根，不加会找不到 minicode 包（IDE 会自动加，命令行不会）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.tooling import ToolContext
from minicode.workspace import is_within_workspace, resolve_workspace_path

# 项目根目录：脚本在 tests/ 下，向上两级
PROJECT_ROOT = Path(__file__).resolve().parents[1]


def main():
    root = PROJECT_ROOT.resolve()
    print(f"工作区 root = {root}\n")

    cases = [
        ("工作区内(相对)", str(root / "README.md")),
        ("工作区内(绝对)", str(root / "minicode" / "config.py")),
        ("../ 越界", str(root / ".." / "outside.txt")),
        ("同盘越界", str(root.parent / "other" / "file.txt")),
        ("大小写不敏感", str(root / "readme.md").lower()),
        ("盘符越界(C:)", "C:/Windows/system32/notepad.exe"),
        ("UNC 越界", "//server/share/file.txt"),
    ]

    print("== is_within_workspace 判定 ==")
    for label, raw in cases:
        target = Path(raw).resolve()
        inside = is_within_workspace(root, target)
        print(f"  {label:22} -> {'在工作区内' if inside else '越界(拒绝)'}")

    print("\n== resolve_workspace_path 实际解析 ==")
    context = ToolContext(cwd=str(root))
    for label, raw in cases:
        try:
            resolved = resolve_workspace_path(context, raw)
            print(f"  {label:22} -> 允许: {resolved}")
        except PermissionError as exc:
            print(f"  {label:22} -> 拒绝: {exc}")


if __name__ == "__main__":
    main()
