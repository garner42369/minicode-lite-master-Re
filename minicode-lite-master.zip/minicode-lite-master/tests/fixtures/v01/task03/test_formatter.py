import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from formatter import format_result


def test_format_result():
    assert format_result("divide", 2.5) == "divide = 2.5"
