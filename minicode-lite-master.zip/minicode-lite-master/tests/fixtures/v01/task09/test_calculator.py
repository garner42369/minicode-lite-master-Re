import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import add, version


def test_add():
    assert add(2, 3) == 5


def test_version():
    assert version() == "1.0.0"
