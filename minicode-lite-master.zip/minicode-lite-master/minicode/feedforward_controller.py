"""minicode 的前馈控制器（Day 28）。

前馈 = 任务开始前，根据「已知的任务特征」（意图）预先设定执行参数，不等运行出错再调。
只留真正影响执行的 3 项（token_budget / max_turns / 并发），不堆「每个意图一个完整 dict」
的配置堆砌（参考项目 feedforward 每意图 15+ 字段，多数不直接参与执行）。

token_budget 单位是 token，量级是「万（w）」——上下文窗口默认 12.8w、DeepSeek V4 100w，
所以预算取几万量级，不是几千。
"""

from __future__ import annotations

from dataclasses import dataclass

from minicode.intent_parser import Intent


@dataclass(frozen=True, slots=True)
class PreemptiveConfig:
    token_budget: int = 40_000        # 默认 4w token
    max_turns: int = 20
    max_concurrent_tools: int = 4


# 意图 → 关键执行参数（token 预算按「万」量级）。SEARCH 只读可高并发、少步数；
# REFACTOR 写操作要串行、多预算。
_INTENT_PARAMS: dict[Intent, PreemptiveConfig] = {
    Intent.SEARCH: PreemptiveConfig(token_budget=30_000, max_turns=15, max_concurrent_tools=6),    # 3w
    Intent.DEBUG: PreemptiveConfig(token_budget=50_000, max_turns=30, max_concurrent_tools=4),     # 5w
    Intent.CODE: PreemptiveConfig(token_budget=60_000, max_turns=40, max_concurrent_tools=3),      # 6w
    Intent.REFACTOR: PreemptiveConfig(token_budget=80_000, max_turns=50, max_concurrent_tools=2),  # 8w
}


def preconfigure(intent: Intent) -> PreemptiveConfig:
    """按意图预配置关键执行参数。未知意图退回默认。"""
    return _INTENT_PARAMS.get(intent, PreemptiveConfig())
