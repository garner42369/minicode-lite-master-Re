"""Day 5: 工具注册、验证、异常归一化和输出预算。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from day02_protocols import ToolResult


Validator = Callable[[dict[str, Any]], dict[str, Any]]
Runner = Callable[[dict[str, Any], "ToolContext"], ToolResult]


@dataclass(slots=True)
class ToolContext:
    cwd: str
    permissions: Any | None = None


@dataclass(slots=True)
class ToolDefinition:
    name: str
    validator: Validator
    run: Runner
    read_only: bool = False
    concurrency_safe: bool = False


class ToolRegistry:
    def __init__(self, tools: list[ToolDefinition], output_limit: int = 2_000) -> None:
        self._tools = {tool.name: tool for tool in tools}
        self.output_limit = output_limit

    def find(self, name: str) -> ToolDefinition | None:
        return self._tools.get(name)

    def execute(self, name: str, raw: dict[str, Any], context: ToolContext) -> ToolResult:
        tool = self.find(name)
        if tool is None:
            return ToolResult(False, f"Unknown tool: {name}", "unknown_tool")
        try:
            parsed = tool.validator(raw)
            result = tool.run(parsed, context)
        except (TypeError, ValueError, KeyError) as exc:
            return ToolResult(False, str(exc), "invalid_input")
        except Exception as exc:  # runtime safety boundary
            return ToolResult(False, f"{type(exc).__name__}: {exc}", "tool_crash")
        if len(result.output) > self.output_limit:
            omitted = len(result.output) - self.output_limit
            result.output = result.output[: self.output_limit] + f"\n...[{omitted} chars omitted]"
            result.metadata["truncated"] = True
        return result


def require_text(data: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(data.get("text"), str):
        raise ValueError("text is required")
    return {"text": data["text"]}


ECHO = ToolDefinition("echo", require_text, lambda data, _: ToolResult(True, data["text"]), True, True)


if __name__ == "__main__":
    registry = ToolRegistry([ECHO], output_limit=10)
    ctx = ToolContext(".")
    assert registry.execute("echo", {"text": "hello"}, ctx).output == "hello"
    assert registry.execute("missing", {}, ctx).error_code == "unknown_tool"
    assert registry.execute("echo", {"text": "x" * 50}, ctx).metadata["truncated"]
    print("tool registry: OK")

