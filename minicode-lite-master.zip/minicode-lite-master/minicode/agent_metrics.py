"""minicode 的指标采集（Day 27）。只记录事实：次数、耗时、状态。

cost_tracker 记 Token/费用，这里补「调用次数、耗时、成功率」——供路由反馈（成功率高的
模型继续用）和停滞判断（重复动作）用。关键：只记录、不决策，决策由控制器做。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class AgentMetrics:
    """一轮任务运行的指标计数器。"""

    model_calls: int = 0
    tool_calls: int = 0
    tool_failures: int = 0
    total_model_ms: float = 0.0
    total_tool_ms: float = 0.0

    def record_model_call(self, duration_ms: float) -> None:
        self.model_calls += 1
        self.total_model_ms += duration_ms

    def record_tool_result(self, ok: bool, duration_ms: float = 0.0) -> None:
        self.tool_calls += 1
        self.total_tool_ms += duration_ms
        if not ok:
            self.tool_failures += 1

    @property
    def tool_success_rate(self) -> float:
        """工具成功率；无工具调用时返回 1.0（没有失败证据）。"""
        return (self.tool_calls - self.tool_failures) / self.tool_calls if self.tool_calls else 1.0

    @property
    def avg_model_ms(self) -> float:
        return self.total_model_ms / self.model_calls if self.model_calls else 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "model_calls": self.model_calls,
            "tool_calls": self.tool_calls,
            "tool_failures": self.tool_failures,
            "tool_success_rate": round(self.tool_success_rate, 3),
            "total_model_ms": round(self.total_model_ms, 1),
            "avg_model_ms": round(self.avg_model_ms, 1),
            "total_tool_ms": round(self.total_tool_ms, 1),
        }
