"""Day 17：context_compactor（工具结果预算 + 读取去重）的契约测试。"""

import tempfile
from pathlib import Path

from minicode.context_compactor import ReadDedupManager, ToolResultBudgetManager, reactive_truncate


class TestToolResultBudgetManager:
    def test_small_output_unchanged(self):
        budget = ToolResultBudgetManager(Path("/tmp"), limit=100)
        text, meta = budget.process("short")
        print(f"small: {text!r}, meta={meta}")
        assert text == "short"
        assert meta == {}

    def test_large_output_persisted_and_summarized(self):
        with tempfile.TemporaryDirectory() as directory:
            budget = ToolResultBudgetManager(Path(directory), limit=20)
            big = "x" * 1000
            text, meta = budget.process(big)
            print(f"summary_len={len(text)}, meta={meta}")
            assert len(text) < 1000  # 摘要比原文短
            assert meta["truncated"] is True
            assert meta["original_size"] == 1000
            assert Path(meta["artifact"]).exists()  # 完整内容落盘可查看


class TestReadDedupManager:
    def test_duplicate_read_returns_stub(self):
        dedup = ReadDedupManager()
        first, dup1 = dedup.process("a.py", "hello")
        second, dup2 = dedup.process("a.py", "hello")
        print(f"first={first!r}({dup1}), second={second!r}({dup2})")
        assert dup1 is False
        assert dup2 is True
        assert "duplicate" in second

    def test_changed_content_invalidates_dedup(self):
        # 核心契约：文件变化后再次读，拿到新内容，不被旧 dedup 拦截
        dedup = ReadDedupManager()
        dedup.process("a.py", "old")
        text, is_dup = dedup.process("a.py", "new")
        print(f"changed={text!r}({is_dup})")
        assert is_dup is False
        assert text == "new"


class TestReactiveTruncate:
    def test_keeps_system_marker_and_recent(self):
        # 核心契约：保留 system 消息 + 插入标记 + 保留最近 keep_ratio 部分
        messages = [{"role": "system", "content": "sys"}] + [
            {"role": "user", "content": f"u{i}"} for i in range(10)
        ]
        truncated = reactive_truncate(messages, keep_ratio=0.4)
        print(f"截断后 {len(truncated)} 条: {[m['role'] for m in truncated]}")
        assert truncated[0]["role"] == "system"              # system 保留在最前
        assert truncated[0]["content"] == "sys"              # 原 system 内容不变
        assert "aggressively truncated" in truncated[1]["content"]  # 标记消息
        assert len([m for m in truncated if m["role"] == "user"]) == 4  # 10*0.4=4

    def test_no_truncation_when_small(self):
        # 边界契约：消息少时不截断，原样返回
        messages = [{"role": "system", "content": "sys"}] + [
            {"role": "user", "content": "u"} for _ in range(3)
        ]
        result = reactive_truncate(messages, keep_ratio=0.4)
        assert len(result) == len(messages)
        print(f"消息少时不截断，原样返回 {len(result)} 条")
