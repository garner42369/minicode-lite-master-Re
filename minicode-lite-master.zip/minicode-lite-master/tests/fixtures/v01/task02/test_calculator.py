import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import multiply


def test_multiply():
    assert multiply(3, 4) == 12
