"""Day 14 集成验收：提前 final 被拦截 → 运行测试 → 完成。

运行（项目根目录）：
    python tests/day14_integration_demo.py

用 ScriptedModel 编排两个剧本：
1. DEBUG 任务：模型 edit_file 后直接 final，被 Kernel 拦截、注入 nudge，
   模型再跑 test_runner，最终通过；
2. SEARCH 任务：只读解释，无需验证，final 直接通过。
"""

import shutil
import sys
import tempfile
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.agent_loop import run_agent_turn
from minicode.intent_parser import Intent
from minicode.mock_model import ScriptedModel
from minicode.permissions import Mode, PermissionDecision, PermissionManager
from minicode.task_object import build_task_object
from minicode.tools import create_full_tool_registry
from minicode.types import AgentStep, ToolCall

PROJECT_ROOT = Path(__file__).resolve().parents[1]
FIXTURE = PROJECT_ROOT / "tests" / "fixtures" / "buggy_calculator"


def main():
    with tempfile.TemporaryDirectory() as temp_dir:
        calc_dir = Path(temp_dir) / "buggy_calculator"
        shutil.copytree(FIXTURE, calc_dir)

        def prompt(request):
            return PermissionDecision("allow_once")

        permissions = PermissionManager(str(temp_dir), Mode.AUTO, prompt=prompt)
        tools = create_full_tool_registry()

        # 剧本 1：DEBUG 任务，提前 final 被拦截
        print("== 剧本 1：DEBUG 任务，提前 final 被拦截 ==")
        task = build_task_object("修复 divide 的整除 bug", Intent.DEBUG)
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "edit_file", {
                "path": "buggy_calculator/calculator.py",
                "old_string": "return a // b",
                "new_string": "return a / b",
            })]),
            AgentStep(type="assistant", kind="final", content="<final> 已修复"),
            AgentStep(type="tool_calls", calls=[ToolCall("2", "test_runner", {"path": "buggy_calculator/tests"})]),
            AgentStep(type="assistant", kind="final", content="<final> 已修复，测试通过"),
        ])
        history, stop = run_agent_turn(
            model, tools, [{"role": "user", "content": "修复 divide 的 bug"}], str(temp_dir),
            task=task, permissions=permissions,
            on_tool_start=lambda c: print(f"  [工具] {c.name}"),
            on_assistant_message=lambda s: print(f"  [模型] final: {s.content[:40]!r}"),
            on_nudge=lambda n: print(f"  [Kernel拦截] {n}"),
        )
        print(f"  stop_reason={stop}")

        # 剧本 2：SEARCH 任务，无需验证
        print("\n== 剧本 2：SEARCH 任务，无需验证 ==")
        task2 = build_task_object("解释这个项目是做什么的", Intent.SEARCH)
        model2 = ScriptedModel([
            AgentStep(type="assistant", kind="final", content="<final> 这是一个本地 Agent Runtime"),
        ])
        history2, stop2 = run_agent_turn(
            model2, tools, [{"role": "user", "content": "解释项目"}], str(temp_dir),
            task=task2, permissions=permissions,
            on_assistant_message=lambda s: print(f"  [模型] final: {s.content[:40]!r}"),
        )
        print(f"  stop_reason={stop2}")


if __name__ == "__main__":
    main()
