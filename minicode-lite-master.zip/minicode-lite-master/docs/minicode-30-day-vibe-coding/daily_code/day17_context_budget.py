"""Day 17: 估算上下文、持久化大工具输出并去重读取。"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class ContextStats:
    estimated_tokens: int
    context_window: int
    reserved_output: int

    @property
    def usage_ratio(self) -> float:
        return self.estimated_tokens / max(1, self.context_window - self.reserved_output)


def estimate_tokens(text: str) -> int:
    ascii_chars = sum(ord(char) < 128 for char in text)
    cjk_chars = len(text) - ascii_chars
    return max(1, ascii_chars // 4 + cjk_chars)


class ToolResultBudget:
    def __init__(self, artifact_dir: Path, limit: int = 2_000) -> None:
        self.artifact_dir, self.limit = artifact_dir, limit
        self._reads: dict[str, str] = {}

    def process(self, tool_name: str, key: str, output: str) -> str:
        content_hash = hashlib.sha256(output.encode()).hexdigest()
        if tool_name == "read_file" and self._reads.get(key) == content_hash:
            return f"[unchanged duplicate read: {key}, hash={content_hash[:8]}]"
        if tool_name == "read_file":
            self._reads[key] = content_hash
        if len(output) <= self.limit:
            return output
        self.artifact_dir.mkdir(parents=True, exist_ok=True)
        artifact = self.artifact_dir / f"{content_hash}.txt"
        artifact.write_text(output, encoding="utf-8")
        half = self.limit // 2
        return output[:half] + f"\n...[full output: {artifact}]...\n" + output[-half:]


if __name__ == "__main__":
    import tempfile

    stats = ContextStats(70_000, 100_000, 20_000)
    assert stats.usage_ratio == 0.875
    with tempfile.TemporaryDirectory() as directory:
        budget = ToolResultBudget(Path(directory), 20)
        budget.process("read_file", "a.py", "x" * 100)
        assert "duplicate" in budget.process("read_file", "a.py", "x" * 100)
    print("context budget: OK")

