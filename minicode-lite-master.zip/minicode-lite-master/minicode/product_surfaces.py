"""minicode 的产品快照与 Readiness（Day 25）。

ProductSnapshot 是「系统当前配置与运行状态」的可序列化快照，供 Prompt、CLI、Session
共用。关键约束：快照不含密钥、进程对象、callback（可序列化）。

Readiness 三档（课件 daily_code，裁剪参考项目的 model fallback 感知四档）：
- ready：模型配置就绪，无扩展失败；
- degraded：模型就绪，但有扩展失败（单个扩展失败只降级，不误杀核心能力）；
- blocked：模型配置缺失（真实模型缺 base_url/api_key），核心任务无法执行。

裁剪说明（裁剪复现，非完整复现）：不做 extension.json（扩展 = skills + MCP）、不做
model fallback（Day 27 路由职责）、不做 background_tasks（Day 26 占位）。
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Literal

from minicode.capability_registry import CapabilityRegistry
from minicode.config import RuntimeConfig, load_runtime_config


@dataclass(frozen=True, slots=True)
class Readiness:
    status: Literal["ready", "degraded", "blocked"]
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class InstructionLayer:
    """一层指令文件的来源与预览（不含全文，避免快照膨胀）。"""

    name: str
    scope: str  # project / global
    path: str
    exists: bool
    preview: str = ""


@dataclass(frozen=True, slots=True)
class ProductSnapshot:
    """产品快照：五类状态 + 后台占位。全部可序列化，不含密钥/进程/callback。"""

    instructions: tuple[InstructionLayer, ...]
    extensions: tuple[dict[str, Any], ...]
    hooks: dict[str, Any]
    capabilities: tuple[str, ...]  # 来自 CapabilityRegistry 的启用能力
    readiness: Readiness
    delegation: str = "not wired (Day 26)"

    def to_dict(self) -> dict[str, Any]:
        return {
            "instructions": [asdict(layer) for layer in self.instructions],
            "extensions": list(self.extensions),
            "hooks": self.hooks,
            "capabilities": list(self.capabilities),
            "readiness": asdict(self.readiness),
            "delegation": self.delegation,
        }


def _preview(path: Path, limit: int = 100) -> str:
    """读文件前 limit 个字符（空白归一化），供快照预览。"""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return ""
    normalized = " ".join(text.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + "..."


def collect_instruction_layers(cwd: str | Path) -> tuple[InstructionLayer, ...]:
    """收集指令层：project CLAUDE.md、global CLAUDE.md、global USER.md。"""
    cwd_path = Path(cwd)
    home = Path.home()
    candidates = [
        ("project-claude", "project", cwd_path / "CLAUDE.md"),
        ("global-claude", "global", home / ".claude" / "CLAUDE.md"),
        ("global-user", "global", home / ".mini-code" / "USER.md"),
    ]
    return tuple(
        InstructionLayer(name, scope, str(path), path.is_file(), _preview(path))
        for name, scope, path in candidates
    )


def _provider_ready(config: RuntimeConfig) -> bool:
    """模型配置就绪：mock 离线可用；真实模型需 base_url + api_key（build_adapter 的判定）。"""
    if config.model == "mock":
        return True
    return bool(config.base_url and config.api_key)


def build_readiness(provider_ready: bool, broken_extensions: list[str]) -> Readiness:
    """三档判定：provider 缺失 → blocked；扩展失败 → degraded；否则 ready。"""
    reasons: list[str] = []
    if not provider_ready:
        reasons.append("provider unavailable (real model missing base_url or api_key)")
    reasons.extend(f"extension failed: {name}" for name in broken_extensions)
    if not provider_ready:
        status = "blocked"
    elif broken_extensions:
        status = "degraded"
    else:
        status = "ready"
    return Readiness(status, tuple(reasons))


def _collect_extensions(skills: list, mcp_servers: list) -> tuple[dict[str, Any], ...]:
    """扩展 = skills + MCP servers 的配置/启用状态（不引入 extension.json）。"""
    entries: list[dict[str, Any]] = []
    for skill in skills:
        entries.append({"type": "skill", "name": skill.name, "source": skill.source, "enabled": True})
    for server in mcp_servers:
        entries.append({
            "type": "mcp",
            "name": server.get("name", ""),
            "status": server.get("status", "unknown"),
            "command": server.get("command", ""),
        })
    return tuple(entries)


def build_product_snapshot(
    cwd: str | Path,
    registry: CapabilityRegistry,
    *,
    skills: list | None = None,
    mcp_servers: list | None = None,
    hooks_stats: dict[str, Any] | None = None,
) -> ProductSnapshot:
    """汇总当前状态为产品快照。capabilities 直接取自 registry（保证与 Prompt 一致）。"""
    config = load_runtime_config()
    mcp_servers = mcp_servers or []
    broken = [s["name"] for s in mcp_servers if s.get("status") == "error"]
    return ProductSnapshot(
        instructions=collect_instruction_layers(cwd),
        extensions=_collect_extensions(skills or [], mcp_servers),
        hooks=hooks_stats or {},
        capabilities=tuple(registry.list_enabled()),
        readiness=build_readiness(_provider_ready(config), broken),
    )
