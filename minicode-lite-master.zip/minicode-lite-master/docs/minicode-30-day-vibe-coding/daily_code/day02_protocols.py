"""Day 2: Model、Loop 和 Tool 共同使用的最小协议。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol, TypedDict


class ChatMessage(TypedDict, total=False):
    role: Literal["system", "user", "assistant", "assistant_progress", "assistant_tool_call", "tool_result"]
    content: str
    tool_call_id: str
    tool_name: str
    input: dict[str, Any]
    is_error: bool


@dataclass(frozen=True, slots=True)
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass(slots=True)
class AgentStep:
    type: Literal["assistant", "tool_calls"]
    content: str = ""
    kind: Literal["final", "progress"] | None = None
    calls: list[ToolCall] = field(default_factory=list)


@dataclass(slots=True)
class ToolResult:
    ok: bool
    output: str
    error_code: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


class ModelAdapter(Protocol):
    def next(
        self,
        messages: list[ChatMessage],
        on_stream_chunk: Callable[[str], None] | None = None,
    ) -> AgentStep: ...


if __name__ == "__main__":
    call = ToolCall("call-1", "read_file", {"path": "README.md"})
    step = AgentStep(type="tool_calls", calls=[call])
    assert step.calls[0].id == "call-1"
    print(step)

