"""Day 6: 工作区路径边界、分页读取和轻量文本搜索。"""

from __future__ import annotations

import re
from pathlib import Path

from day02_protocols import ToolResult
from day05_tool_registry import ToolContext, ToolDefinition, ToolRegistry


def resolve_workspace_path(context: ToolContext, raw_path: str) -> Path:
    root = Path(context.cwd).resolve()
    candidate = Path(raw_path)
    target = (candidate if candidate.is_absolute() else root / candidate).resolve()
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise PermissionError(f"path escapes workspace: {raw_path}") from exc
    return target


def validate_path(data: dict) -> dict:
    path = data.get("path", ".")
    if not isinstance(path, str):
        raise ValueError("path must be a string")
    return {"path": path, "offset": int(data.get("offset", 0)), "limit": min(int(data.get("limit", 8_000)), 20_000)}


def list_files(data: dict, context: ToolContext) -> ToolResult:
    target = resolve_workspace_path(context, data["path"])
    if not target.is_dir():
        return ToolResult(False, f"not a directory: {data['path']}", "not_directory")
    rows = [f"{'dir ' if p.is_dir() else 'file'} {p.name}" for p in sorted(target.iterdir())]
    return ToolResult(True, "\n".join(rows[:200]) or "(empty)")


def read_file(data: dict, context: ToolContext) -> ToolResult:
    target = resolve_workspace_path(context, data["path"])
    if not target.is_file():
        return ToolResult(False, f"file not found: {data['path']}", "not_found")
    try:
        content = target.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return ToolResult(False, "binary or non-UTF-8 file", "binary_file")
    start, end = data["offset"], min(len(content), data["offset"] + data["limit"])
    header = f"OFFSET={start} END={end} TOTAL={len(content)} TRUNCATED={end < len(content)}\n"
    return ToolResult(True, header + content[start:end])


def grep_text(root: Path, pattern: str) -> list[str]:
    regex = re.compile(pattern, re.IGNORECASE)
    rows: list[str] = []
    for path in root.rglob("*.py"):
        if any(part.startswith(".") or part == "__pycache__" for part in path.parts):
            continue
        try:
            for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
                if regex.search(line):
                    rows.append(f"{path.relative_to(root)}:{number}:{line}")
                    if len(rows) >= 200:
                        return rows
        except (OSError, UnicodeDecodeError):
            continue
    return rows


LIST_FILES = ToolDefinition("list_files", validate_path, list_files, True, True)
READ_FILE = ToolDefinition("read_file", validate_path, read_file, True, True)


if __name__ == "__main__":
    registry = ToolRegistry([LIST_FILES, READ_FILE])
    context = ToolContext(str(Path(__file__).parent))
    print(registry.execute("list_files", {"path": "."}, context).output.splitlines()[:3])
    assert not registry.execute("read_file", {"path": "../README.md"}, context).ok

