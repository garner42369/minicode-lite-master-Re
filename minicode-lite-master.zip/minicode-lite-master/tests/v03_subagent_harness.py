"""第三次集成测试 harness：委派子 Agent（task 工具），真实模型跑。

验证 Day 26 的「子 Agent 委派」端到端：父 Agent 调 task 工具并发委派多个 explore
子 Agent，子 Agent 各自递归跑 agent loop，返回报告，父 Agent 汇总。

用法：

    python tests/v03_subagent_harness.py "任务指令" --cwd <目录>

不传任务时用默认的「委派两个 explore 子 Agent 探索代码库」提示词。
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.config import load_dotenv
from minicode.permissions import Mode, PermissionDecision, RiskLevel
from minicode.runtime_factory import RuntimeFactory
from minicode.task_object import build_task_object

_DEFAULT_TASK = (
    "请使用 task 工具并发委派两个 explore 类型的子 Agent 探索这个代码库："
    "第一个子 Agent 探索 minicode/agent_loop.py 的结构和职责，"
    "第二个子 Agent 探索 minicode/mcp.py 的结构和职责。"
    "等两个子 Agent 都返回后，汇总它们的报告，用一段话总结这个项目的核心架构。"
)


def run_task(task_text: str, cwd: str):
    def prompt(request):
        if request.risk is RiskLevel.DANGEROUS:
            print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> deny")
            return PermissionDecision("deny_once")
        print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> allow")
        return PermissionDecision("allow_once")

    factory = RuntimeFactory(mode=Mode.AUTO, prompt=prompt)
    runtime = factory.create(cwd)
    task = build_task_object(task_text, model=runtime.adapter)

    history, stop = runtime.run(
        task_text,
        task=task,
        on_tool_start=lambda c: print(f"    [工具] {c.name}({c.arguments})"),
        on_tool_result=lambda c, r: print(f"    [工具结果] {c.name} ok={r.ok}  {r.output[:800]!r}"),
        on_nudge=lambda n: print(f"    [Kernel拦截] {n}"),
    )
    return history, stop, runtime.cost_tracker.totals()


def main():
    # 显式加载项目根的 .env，不依赖 cwd（否则从别的目录跑会退回 mock 模型）
    load_dotenv(str(Path(__file__).resolve().parents[1] / ".env"))

    parser = argparse.ArgumentParser(description="第三次集成测试：委派子 Agent")
    parser.add_argument("task", nargs="?", default=_DEFAULT_TASK, help="任务指令")
    parser.add_argument("--cwd", default=str(Path(__file__).resolve().parents[1]), help="工作目录（默认项目根）")
    args = parser.parse_args()

    history, stop, totals = run_task(args.task, args.cwd)
    print(f"\n=== 结果 ===")
    print(f"  stop_reason: {stop}")
    if stop != "done":
        raise SystemExit(f"测试失败：{stop}")
    print(f"  最终回答: {history[-1]['content'][:2000]}")
    print(f"  成本: 调用 {totals.calls} 次, 输入 {totals.input_tokens}, 输出 {totals.output_tokens}, ${totals.cost_usd:.6f}")


if __name__ == "__main__":
    main()
