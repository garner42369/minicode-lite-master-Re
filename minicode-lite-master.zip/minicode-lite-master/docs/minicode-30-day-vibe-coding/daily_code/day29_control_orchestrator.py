"""Day 29: 可关闭的控制扩展、自愈动作白名单和简单消融。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol


@dataclass(frozen=True, slots=True)
class Signals:
    context_ratio: float
    tool_error_rate: float
    repeated_failures: int


@dataclass(frozen=True, slots=True)
class ControlAction:
    name: str
    reason: str


class RuntimeControlExtension(Protocol):
    def after_tool(self, signals: Signals) -> list[ControlAction]: ...


@dataclass(slots=True)
class ControlOrchestrator:
    enabled: bool = True
    max_healings: int = 2
    healing_count: int = 0
    history: list[ControlAction] = field(default_factory=list)

    def after_tool(self, signals: Signals) -> list[ControlAction]:
        if not self.enabled:
            return []
        actions: list[ControlAction] = []
        if signals.context_ratio >= .90:
            actions.append(ControlAction("compact", "context pressure >= 90%"))
        if signals.tool_error_rate >= .5:
            actions.append(ControlAction("reduce_concurrency", "tool error rate >= 50%"))
        if signals.repeated_failures >= 2 and self.healing_count < self.max_healings:
            actions.append(ControlAction("retry_idempotent_request", "bounded recovery"))
            self.healing_count += 1
        self.history.extend(actions)
        return actions


@dataclass(frozen=True, slots=True)
class AblationResult:
    condition: str
    success: bool
    steps: int
    cost: float


def compare(baseline: AblationResult, full: AblationResult) -> dict[str, float | bool]:
    return {"success_gain": full.success and not baseline.success, "step_delta": full.steps - baseline.steps, "cost_delta": full.cost - baseline.cost}


if __name__ == "__main__":
    orchestrator = ControlOrchestrator()
    actions = orchestrator.after_tool(Signals(.93, .6, 2))
    assert {action.name for action in actions} == {"compact", "reduce_concurrency", "retry_idempotent_request"}
    print(compare(AblationResult("baseline", False, 8, .2), AblationResult("full", True, 7, .25)))

