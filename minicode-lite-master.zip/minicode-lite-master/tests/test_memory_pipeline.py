"""Day 20：记忆流水线（MemoryPipeline）的契约测试。"""

import time

from minicode.memory import MemoryManager, MemoryScope
from minicode.memory_pipeline import MemoryPipeline, decide_injection


class TestDecideInjection:
    def test_three_modes(self):
        # 核心契约：上下文压力 → off/summary/full 三档
        assert decide_injection(0.95).mode == "off"
        assert decide_injection(0.80).mode == "summary"
        assert decide_injection(0.50).mode == "full"
        print(f"\noff(>=0.9) / summary(>=0.75) / full: 三档正确")


class TestMemoryPipeline:
    def test_inject_off_when_high_pressure(self, tmp_path):
        pipeline = MemoryPipeline(MemoryManager(tmp_path))
        assert pipeline.inject("测试", 0.95) == ""
        print(f"\n高压(>=0.9)不注入: OK")

    def test_inject_returns_relevant(self, tmp_path):
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing", tags=["pytest"])
        pipeline = MemoryPipeline(mgr)
        text = pipeline.inject("测试", 0.5)
        assert "pytest" in text
        print(f"\n注入文本:\n{text}")

    def test_rerank_failure_falls_back(self, tmp_path):
        # 核心契约：reranker 失败自动回退 BM25 基础排序，不中断注入
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing")

        def bad_reranker(query, entries):
            raise RuntimeError("rerank failed")

        pipeline = MemoryPipeline(mgr, reranker=bad_reranker)
        text = pipeline.inject("测试", 0.5)
        assert "pytest" in text
        print(f"\nrerank 失败 fallback: 仍能注入")

    def test_cooldown_skips_repeat(self, tmp_path):
        # 核心契约：相同任务冷却期内不重复注入
        mgr = MemoryManager(tmp_path)
        mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing")
        pipeline = MemoryPipeline(mgr, cooldown_seconds=60)
        first = pipeline.inject("测试", 0.5)
        second = pipeline.inject("测试", 0.5)  # 相同任务，冷却期内
        assert first != ""
        assert second == ""
        print(f"\ncooldown: 相同任务冷却期不重复注入")

    def test_write_verified_fact(self, tmp_path):
        # 核心契约：未验证不写，验证才写
        mgr = MemoryManager(tmp_path)
        pipeline = MemoryPipeline(mgr)
        try:
            pipeline.write_verified_fact("未验证的经验", verified=False)
            assert False, "should reject unverified"
        except ValueError:
            pass
        pipeline.write_verified_fact("已验证的经验", verified=True)
        assert len(mgr.list(MemoryScope.PROJECT)) == 1
        print(f"\nverified 才写: 未验证拒绝、验证写入")

    def test_feedback_updates_confidence(self, tmp_path):
        # 核心契约：成功正强化、失败衰减（confidence 乘进 BM25 评分）
        mgr = MemoryManager(tmp_path)
        entry = mgr.add(MemoryScope.PROJECT, "测试命令是 pytest -q", category="testing")
        pipeline = MemoryPipeline(mgr)
        pipeline.inject("测试", 0.5)
        pipeline.feedback(task_success=False)
        assert entry.confidence == 0.9  # 失败衰减
        pipeline.feedback(task_success=True)
        assert entry.confidence == 1.0  # 成功提升
        print(f"\nfeedback 闭环: 失败衰减到 {0.9}、成功提升回 1.0")

    def test_maintain_expires(self, tmp_path):
        # 核心契约：过期的记忆失效
        mgr = MemoryManager(tmp_path)
        entry = mgr.add(MemoryScope.PROJECT, "临时记忆", category="general")
        entry.expires_at = time.time() - 1  # 已过期
        pipeline = MemoryPipeline(mgr)
        expired = pipeline.maintain()
        assert expired == 1
        assert entry.valid is False
        print(f"\nmaintain 失效过期记忆: {expired} 条")
