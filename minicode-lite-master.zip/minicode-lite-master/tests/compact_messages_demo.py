"""Day 18 compact_messages 演示：压缩对话历史（四字段摘要）+ system 消息保留。

核心：记忆作为独立 system 消息注入（upsert_stable_task_message），压缩时 system
消息原样保留、不参与摘要——「记忆注入」和「压缩摘要」两条线分开。

运行（项目根目录）：
    python tests/compact_messages_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.context_compactor import compact_messages
from minicode.turn_kernel import STABLE_TASK_STATE_MARKER, upsert_stable_task_message


def main():
    # 构造历史：system 提示 + user → 工具对 → ...（无记忆）
    messages = [
        {"role": "system", "content": "你是一个编程助手"},
        {"role": "user", "content": "修复 divide 的整除 bug"},
        {"role": "assistant_tool_call", "tool_call_id": "1", "tool_name": "list_files", "input": {"path": "."}},
        {"role": "tool_result", "tool_call_id": "1", "tool_name": "list_files", "content": "calculator.py, formatter.py"},
        {"role": "assistant_tool_call", "tool_call_id": "2", "tool_name": "read_file", "input": {"path": "calculator.py"}},
        {"role": "tool_result", "tool_call_id": "2", "tool_name": "read_file", "content": "def divide(a, b): return a // b"},
        {"role": "user", "content": "把 // 改成 /"},
        {"role": "assistant_tool_call", "tool_call_id": "3", "tool_name": "edit_file", "input": {"path": "calculator.py"}},
        {"role": "tool_result", "tool_call_id": "3", "tool_name": "edit_file", "content": "edited"},
        {"role": "assistant", "content": "已修复"},
    ]

    # 记忆注入：作为独立 system 消息（带标记），不参与压缩摘要
    stable_text = "Goal: 修复 divide 的整除 bug\nConstraint: 不要改 formatter.py"
    messages = upsert_stable_task_message(messages, stable_text)

    print(f"原始 {len(messages)} 条（含 1 条记忆 system 消息）")
    compacted = compact_messages(messages, keep_recent=4)
    print(f"压缩后 {len(compacted)} 条\n")

    print("== 压缩后的消息 ==")
    for m in compacted:
        role = m["role"]
        content = m.get("content", "")
        if m.get("source_range"):
            content = f"{content}  [source_range={m['source_range']}]"
        print(f"  {role}: {content[:100]!r}")

    # 验证：记忆 system 消息保留；摘要里不含记忆内容
    print("\n== 两条线分开的验证 ==")
    has_memory = any(
        m.get("role") == "system"
        and str(m.get("content", "")).startswith(STABLE_TASK_STATE_MARKER)
        for m in compacted
    )
    summary = next((m for m in compacted if m.get("source_range")), None)
    summary_text = summary["content"] if summary else ""
    print(f"  记忆 system 消息保留: {has_memory}")
    print(f"  摘要不含记忆内容(Goal/Constraint): {'Goal' not in summary_text and 'Constraint' not in summary_text}")


if __name__ == "__main__":
    main()
