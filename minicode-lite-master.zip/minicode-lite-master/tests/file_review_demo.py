"""Day 12 受控写入原语演示：digest / unified_diff / atomic_write / Checkpoint。

运行（项目根目录）：
    python tests/file_review_demo.py
"""

import sys
import tempfile
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.file_review import Checkpoint, atomic_write, digest, unified_diff


def main():
    # digest：内容哈希
    data = b"def divide(a, b): return a // b\n"
    print(f"digest({data!r}) = {digest(data)[:16]}...\n")

    # unified_diff：展示 diff
    before = "def divide(a, b): return a // b\n"
    after = "def divide(a, b): return a / b\n"
    print("== unified diff ==")
    print(unified_diff("calculator.py", before, after))
    print()

    # atomic_write + Checkpoint：写入临时文件
    with tempfile.TemporaryDirectory() as directory:
        target = Path(directory) / "calculator.py"
        atomic_write(target, b"def divide(a, b): return a / b\n")
        print(f"atomic_write 后文件内容: {target.read_text(encoding='utf-8')!r}")
        checkpoint = Checkpoint(
            path=str(target),
            existed=True,
            before=b"old",
            before_hash="h1",
            after_hash="h2",
            group_id="g1",
        )
        print(f"Checkpoint: {checkpoint}")


if __name__ == "__main__":
    main()
