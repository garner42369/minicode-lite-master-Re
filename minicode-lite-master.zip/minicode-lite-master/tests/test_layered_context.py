"""Day 18：分层上下文（LayeredContext）的契约测试。"""

from minicode.layered_context import ContextBudget, ContextLayer, LayeredContext


class TestLayeredContext:
    def test_layers_assemble_in_order(self):
        # 核心契约：分层存放，组装时按 SYSTEM → PROJECT → SESSION → SCRATCHPAD 顺序
        ctx = LayeredContext()
        ctx.add(ContextLayer.SYSTEM, "你是编程助手", priority=100, source="system_prompt")
        ctx.add(ContextLayer.SESSION, "目标: 修复 divide", priority=50, source="memory")
        text = ctx.get_all_text()
        print(f"\n{text}")
        assert text.index("system") < text.index("session")  # SYSTEM 在 SESSION 前

    def test_trim_keeps_high_priority(self):
        # 核心契约：超预算时 priority 高的保留，低的淘汰
        budget = ContextBudget(total_limit=30, session_ratio=1.0)  # session 上限 30 token
        ctx = LayeredContext(budget)
        ctx.add(ContextLayer.SESSION, "A" * 100, priority=10)  # 25 token，高 priority
        ctx.add(ContextLayer.SESSION, "B" * 100, priority=0)   # 25 token，低 priority
        session_text = ctx.get_text(ContextLayer.SESSION)
        print(f"\n裁剪后 SESSION: {session_text[:50]!r}（A 保留 / B 淘汰）")
        assert "A" in session_text
        assert "B" not in session_text
        assert ctx.layer_tokens(ContextLayer.SESSION) <= 30  # 裁剪后不超预算

    def test_within_budget_keeps_all(self):
        # 边界契约：不超预算时全部保留
        ctx = LayeredContext()
        ctx.add(ContextLayer.SESSION, "短内容", priority=0)
        ctx.add(ContextLayer.SESSION, "另一条", priority=0)
        text = ctx.get_text(ContextLayer.SESSION)
        print(f"\n不超预算时保留全部: {text!r}")
        assert "短内容" in text
        assert "另一条" in text
