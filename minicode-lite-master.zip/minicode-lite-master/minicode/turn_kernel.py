"""minicode 的 Turn Kernel：显式阶段、预算、验证证据与终止判断。

Day 14 引入。核心思想：Loop 负责「执行」，Kernel 负责「决策」——什么时候
能结束、什么时候需要继续、什么时候验证不足，都由这里显式建模，而不是靠
模型口头说「完成」。

阶段状态机：Explore → Execute → Verify → Done（另有 Widen/Blocked 分支）。
验证证据绑定文件版本（edit group 哈希），模型口头声明不能替代命令结果。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Phase(str, Enum):
    """一轮任务所处的阶段。"""

    EXPLORE = "explore"   # 收集证据：读文件、搜索、理解现状
    EXECUTE = "execute"   # 做出修改
    VERIFY = "verify"     # 运行验证（测试/检查）


@dataclass(slots=True)
class TurnState:
    """一轮 Agent turn 的显式状态。

    changed_version / verified_version 都是「文件版本」标识（edit group 哈希），
    用于判断「验证证据是否覆盖当前文件内容」——验证后若再改文件，版本变了，
    证据立即失效（evidence_ready 变 False）。
    """

    max_steps: int = 8
    step: int = 0
    changed_version: str = ""              # 最近修改的文件版本
    verified_version: str = ""             # 最近验证通过的文件版本
    last_verification_failed: bool = False  # 最近一次验证是否失败
    tool_observations: int = 0             # 工具观察次数（用于判断是否有足够证据）
    phase: Phase = Phase.EXPLORE

    def record_change(self, version: str) -> None:
        """记录一次修改：设置 changed_version，清除 verified（证据失效），进入 EXECUTE。

        为什么清除 verified：验证结论是针对「被验证的那个文件内容」的；一旦文件
        又改了，旧验证证据不再覆盖当前版本，必须重新验证。
        """
        self.changed_version = version
        self.verified_version = ""
        self.last_verification_failed = False
        self.phase = Phase.EXECUTE

    def record_verification(self, version: str, passed: bool) -> None:
        """记录一次验证：只有 passed 才设置 verified_version；失败则清空旧证据。"""
        self.tool_observations += 1
        if passed:
            self.verified_version = version
            self.last_verification_failed = False
        else:
            self.verified_version = ""  # 验证失败，旧证据失效，避免 evidence_ready 误判
            self.last_verification_failed = True
        self.phase = Phase.VERIFY

    def evidence_ready(self) -> bool:
        """验证证据是否覆盖当前文件版本（有修改，且修改版本已被验证通过）。"""
        return bool(self.changed_version) and self.changed_version == self.verified_version


@dataclass(frozen=True, slots=True)
class Decision:
    """Kernel 的一次决策。terminal=True 表示本轮可以结束。

    reason 覆盖课件验收的停止原因：done / max_steps / verification_missing /
    verification_failed（await_user 在权限层集成时补充）。
    """

    terminal: bool
    reason: str
    nudge: str = ""  # 给模型的纠正信号（如「先运行验证再结束」）


def decide_final(state: TurnState, requires_verification: bool) -> Decision:
    """根据状态判断本轮能否结束。

    顺序：
    1. 预算耗尽 → max_steps；
    2. 需要验证：验证失败 → verification_failed；证据不足 → verification_missing；
    3. 否则 → done。

    requires_verification 由验证策略（verification_controller）决定，而非写死——
    只读解释任务可以不需要验证就结束。
    """
    if state.step >= state.max_steps:
        return Decision(True, "max_steps")
    if requires_verification:
        if state.last_verification_failed:
            return Decision(False, "verification_failed", "验证失败，修复后重新运行验证。")
        if not state.evidence_ready():
            return Decision(False, "verification_missing", "运行与当前文件版本相关的验证后再结束。")
    return Decision(True, "done")


@dataclass(frozen=True, slots=True)
class StableTaskPack:
    """当前任务状态的稳定快照（每轮重建，供注入上下文）。

    「保护记忆」的权威清单——这些字段不参与压缩摘要，而是作为独立 system 消息
    注入（upsert_stable_task_message），压缩时 system 消息原样保留，记忆因此永不
    丢失（详见 docs/memory-context-mixing.md）。
    """

    goal: str = ""
    constraints: tuple[str, ...] = ()
    verification: str = ""  # 验证状态文本，空 = 尚未修改

    def to_protected_text(self) -> str:
        lines: list[str] = []
        if self.goal:
            lines.append(f"Goal: {self.goal}")
        lines += [f"Constraint: {c}" for c in self.constraints]
        if self.verification:
            lines.append(f"Verification: {self.verification}")
        return "\n".join(lines)


def stable_task_pack(task, state: TurnState) -> StableTaskPack:
    """把任务目标、约束、验证状态打包成稳定快照。

    每轮重建（不累积）——验证状态这类「当前」事实每次从 state 重新计算，而不是
    累积进存储。重要度在写工作记忆时体现（见 protect_stable_task_pack）。
    """
    verification = ""
    if state.changed_version:
        if state.last_verification_failed:
            verification = "已修改,验证失败"
        elif state.verified_version == state.changed_version:
            verification = "已修改,验证通过"
        else:
            verification = "已修改,未验证"
    return StableTaskPack(
        goal=task.goal,
        constraints=getattr(task, "constraints", ()),
        verification=verification,
    )


def protect_stable_task_pack(memory, task, state: TurnState) -> None:
    """把稳定快照按重要度写进工作记忆（受保护层），任务开始时调用。

    用固定 key（而非 content 作 key）：验证状态内容会随进度变化，固定 key 保证
    覆盖旧值、不残留「已修改,未验证」和「已修改,验证通过」两条矛盾状态。

    memory 是 WorkingMemory 实例（有 set(key, content, importance) 方法）。
    """
    pack = stable_task_pack(task, state)
    memory.set("goal", f"目标: {pack.goal}", importance=10)
    for c in pack.constraints:
        memory.set(f"constraint:{c}", f"约束: {c}", importance=8)
    if pack.verification:
        memory.set("verification", f"验证状态: {pack.verification}", importance=7)


STABLE_TASK_STATE_MARKER = "[Stable task state]"


def upsert_stable_task_message(messages: list[dict], stable_text: str) -> list[dict]:
    """把记忆（Stable task state）作为独立 system 消息注入消息列表。

    「upsert」：先删掉已有的 stable task 消息（role=system 且 content 以
    STABLE_TASK_STATE_MARKER 开头），再 append 一条新的。保证消息列表里
    永远只有一条记忆消息，每轮覆盖更新、不累积。

    这是「记忆注入」和「压缩摘要」分开的关键：记忆是独立的 system 消息，
    compact_messages 压缩时 system 消息原样保留，记忆因此永不进摘要
    （详见 docs/memory-context-mixing.md）。
    """
    filtered = [
        m for m in messages
        if not (
            m.get("role") == "system"
            and str(m.get("content", "")).startswith(STABLE_TASK_STATE_MARKER)
        )
    ]
    filtered.append({"role": "system", "content": f"{STABLE_TASK_STATE_MARKER}\n{stable_text}"})
    return filtered


PROJECT_MEMORY_MARKER = "[Project memory]"


def upsert_project_memory(messages: list[dict], memory_text: str) -> list[dict]:
    """把项目记忆作为独立 system 消息注入消息列表（与稳定任务状态对称）。

    项目记忆是「跨会话知识」（Day 19/20），稳定任务状态是「当前任务状态」（Day 18）
    ——两条独立的 system 消息，各自 upsert、互不覆盖。压缩时 system 消息原样保留。
    """
    filtered = [
        m for m in messages
        if not (
            m.get("role") == "system"
            and str(m.get("content", "")).startswith(PROJECT_MEMORY_MARKER)
        )
    ]
    filtered.append({"role": "system", "content": f"{PROJECT_MEMORY_MARKER}\n{memory_text}"})
    return filtered
