"""Day 25: 可序列化 Product Snapshot 与 Capability Registry。"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Callable, Literal


@dataclass(frozen=True, slots=True)
class Capability:
    name: str
    domain: str
    scope: str
    enabled: bool = True


class CapabilityRegistry:
    def __init__(self) -> None:
        self.metadata: dict[str, Capability] = {}
        self.handlers: dict[str, Callable[..., Any]] = {}

    def register(self, capability: Capability, handler: Callable[..., Any]) -> None:
        if capability.name in self.metadata:
            raise ValueError(f"duplicate capability: {capability.name}")
        self.metadata[capability.name] = capability
        self.handlers[capability.name] = handler


@dataclass(frozen=True, slots=True)
class Readiness:
    status: Literal["ready", "degraded", "blocked"]
    reasons: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ProductSnapshot:
    instructions: tuple[str, ...]
    extensions: tuple[str, ...]
    hooks: tuple[str, ...]
    capabilities: tuple[str, ...]
    readiness: Readiness

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def build_snapshot(registry: CapabilityRegistry, provider_ready: bool, broken_extensions: list[str]) -> ProductSnapshot:
    reasons = tuple([*([] if provider_ready else ["provider unavailable"]), *(f"extension failed: {x}" for x in broken_extensions)])
    status = "blocked" if not provider_ready else "degraded" if broken_extensions else "ready"
    return ProductSnapshot((), tuple(broken_extensions), (), tuple(name for name, meta in registry.metadata.items() if meta.enabled), Readiness(status, reasons))


if __name__ == "__main__":
    registry = CapabilityRegistry()
    registry.register(Capability("read_file", "tool", "workspace"), lambda: None)
    snapshot = build_snapshot(registry, True, ["demo-mcp"])
    assert snapshot.readiness.status == "degraded" and "read_file" in snapshot.capabilities
    print(snapshot.to_dict())

