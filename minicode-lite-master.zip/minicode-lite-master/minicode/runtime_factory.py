"""runtime_factory：CLI 与 Headless 共享的运行时装配（Day 21）。

核心能力（Day 7-20）已经存在，入口层只做「装配」——把 config → adapter → 工具 →
权限串起来，返回一个 Runtime。CLI 和 Headless 复用同一个装配，不复制 Agent 逻辑
（课件 Day 21「入口只装配依赖，不复制 Agent 逻辑」）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from minicode.agent_loop import run_agent_turn
from minicode.capability_registry import Capability, CapabilityRegistry
from minicode.config import load_runtime_config
from minicode.cost_tracker import CostTracker
from minicode.hooks import HookManager
from minicode.mcp import create_mcp_backed_tools, load_mcp_servers
from minicode.memory import MemoryManager
from minicode.memory_pipeline import MemoryPipeline
from minicode.model_registry import build_adapter
from minicode.permissions import Mode, PermissionDecision, PermissionManager, PermissionRequest
from minicode.prompt import build_prompt
from minicode.product_surfaces import ProductSnapshot, build_product_snapshot
from minicode.skills import discover_skills
from minicode.task_object import TaskObject, build_task_object
from minicode.tooling import ToolRegistry, ToolResult
from minicode.tools import create_full_tool_registry
from minicode.types import AgentStep, ChatMessage, ModelAdapter, ToolCall


@dataclass
class Runtime:
    """装配好的运行时：cwd + model + 工具 + 权限 + 成本追踪。

    只持有「依赖」，不掺「如何判断完成、如何执行工具」的业务逻辑（那些在 Loop 里）。
    """

    cwd: str
    adapter: ModelAdapter
    tools: ToolRegistry
    permissions: PermissionManager
    cost_tracker: CostTracker
    skills: list  # 发现的 skill 摘要（Day 23），供 build_prompt 注入
    hooks: HookManager  # hook 管理器（含 memory hook），供 run_agent_turn 触发
    mcp_servers: list  # MCP server 摘要（Day 24），供 build_prompt 注入
    registry: CapabilityRegistry  # 能力目录（Day 25），供诊断/快照查询
    snapshot: ProductSnapshot  # 产品快照（Day 25），供 CLI 只读命令读

    def run(
        self,
        prompt: str,
        *,
        task: TaskObject | None = None,
        on_tool_start: Callable[[ToolCall], None] | None = None,
        on_tool_result: Callable[[ToolCall, ToolResult], None] | None = None,
        on_assistant_message: Callable[[AgentStep], None] | None = None,
        on_nudge: Callable[[str], None] | None = None,
        on_compact: Callable[[dict], None] | None = None,
    ) -> tuple[list[ChatMessage], str]:
        """跑一轮任务，返回 (history, stop_reason)。

        task 可显式传入（调用方已知意图），否则用 LLM 意图分类（build_task_object 内部）。
        """
        resolved_task = task if task is not None else build_task_object(prompt, model=self.adapter)
        messages: list[ChatMessage] = [
            {"role": "system", "content": build_prompt(self.cwd, skills=self.skills, mcp_servers=self.mcp_servers)},
            {"role": "user", "content": prompt},
        ]
        return run_agent_turn(
            self.adapter,
            self.tools,
            messages,
            self.cwd,
            task=resolved_task,
            permissions=self.permissions,
            on_tool_start=on_tool_start,
            on_tool_result=on_tool_result,
            on_assistant_message=on_assistant_message,
            on_nudge=on_nudge,
            on_compact=on_compact,
            hooks=self.hooks,
        )

    def dispose(self) -> None:
        """释放资源。课件验收：无论成功失败都要调用 tools.dispose()。"""
        self.tools.dispose()


class RuntimeFactory:
    """装配工厂：根据 mode + prompt 创建 Runtime，两个入口复用。"""

    def __init__(
        self,
        mode: Mode = Mode.AUTO,
        prompt: Callable[[PermissionRequest], PermissionDecision] | None = None,
    ) -> None:
        self.mode = mode
        self.prompt = prompt

    def create(self, cwd: str) -> Runtime:
        config = load_runtime_config()
        tools = create_full_tool_registry()

        # Day 24：MCP 工具需在 build_adapter 之前注册（真实模型的 API 工具清单含 MCP）。
        mcp_result = create_mcp_backed_tools(cwd=cwd, mcp_servers=load_mcp_servers(cwd))
        for tool in mcp_result["tools"]:
            tools.register(tool)
        tools.add_disposer(mcp_result["dispose"])

        tracker = CostTracker()
        adapter = build_adapter(config, tools=tools.list(), cost_tracker=tracker)
        permissions = PermissionManager(cwd, self.mode, prompt=self.prompt)

        # Day 23：Skill 发现 + Hook 装配。MemoryPipeline 作为扩展注册到 hook，
        # loop 只 fire AGENT_START / AGENT_STOP，不 import MemoryPipeline。
        skills = discover_skills(cwd)
        hooks = HookManager()
        MemoryPipeline(MemoryManager(cwd)).register_hooks(hooks)

        # Day 25：能力目录 + 产品快照。capabilities 直接取自 registry，保证
        # Prompt 展示的启用能力与 Registry 一致（课件验收）。
        registry = CapabilityRegistry()
        registry.register(Capability("tools", "tool", "workspace", True, "builtin tool registry"))
        registry.register(Capability("memory", "memory", "workspace", True, "project memory pipeline"))
        registry.register(Capability("mcp", "external", "external", bool(mcp_result["tools"]), "MCP-backed tools"))
        registry.register(Capability("skills", "tool", "workspace", bool(skills), "skill loading"))
        registry.register(Capability("hooks", "system", "system", True, "hook event system"))
        registry.register(Capability("compaction", "context", "workspace", True, "context compaction"))
        snapshot = build_product_snapshot(
            cwd,
            registry,
            skills=skills,
            mcp_servers=mcp_result["servers"],
            hooks_stats=hooks.get_stats(),
        )

        return Runtime(str(cwd), adapter, tools, permissions, tracker, skills, hooks, mcp_result["servers"], registry, snapshot)
