"""Day 8：工具调度器与有限恢复的契约测试。

覆盖两类契约：
1. execute_calls —— 并发/串行分组、原顺序回填、异常隔离、指标记录；
2. run_agent_turn —— 空响应有限重试、同工具连续失败停止。
"""

import time
from pathlib import Path
from time import perf_counter

from minicode.agent_loop import run_agent_turn
from minicode.mock_model import ScriptedModel
from minicode.scheduler import execute_calls
from minicode.tooling import (
    ToolCapability,
    ToolContext,
    ToolDefinition,
    ToolMetadata,
    ToolRegistry,
    ToolResult,
)
from minicode.tools import create_core_tool_registry
from minicode.types import AgentStep, ToolCall


def _make_tool(name, *, delay=0.0, concurrency_safe=False, boom=False, events=None):
    """构造一个可控的测试工具：可设延迟、是否并发安全、是否崩溃、是否记录事件。"""

    def _validate(raw):
        return raw

    def _run(parsed, ctx):
        if events is not None:
            events.append(f"{name}:start")
        if delay:
            time.sleep(delay)
        if boom:
            raise RuntimeError("boom")
        if events is not None:
            events.append(f"{name}:end")
        return ToolResult(ok=True, output=name)

    capabilities = {ToolCapability.READ_ONLY}
    if concurrency_safe:
        capabilities.add(ToolCapability.CONCURRENCY_SAFE)
    return ToolDefinition(
        validator=_validate,
        run=_run,
        metadata=ToolMetadata(name=name, description="test tool", capabilities=capabilities),
    )


class TestToolScheduler:
    def test_concurrent_readonly_tools_finish_in_parallel(self):
        # 两个只读慢工具并发执行，总耗时接近一个而非两倍
        registry = ToolRegistry([
            _make_tool("slow_a", delay=0.2, concurrency_safe=True),
            _make_tool("slow_b", delay=0.2, concurrency_safe=True),
        ])
        calls = [ToolCall("1", "slow_a", {}), ToolCall("2", "slow_b", {})]
        started = perf_counter()
        result = execute_calls(calls, registry, ToolContext("."))
        elapsed = perf_counter() - started
        print(f"\n并发执行两个 0.2s 工具，总耗时 {elapsed:.3f}s（串行需 ~0.4s）")
        assert elapsed < 0.3
        assert all(r.ok for _, r in result.observations)

    def test_serial_tools_do_not_overlap(self):
        # 非并发安全的工具必须串行：前一个完全结束后下一个才开始
        events: list[str] = []
        registry = ToolRegistry([
            _make_tool("w1", delay=0.03, events=events),
            _make_tool("w2", delay=0.03, events=events),
        ])
        execute_calls(
            [ToolCall("1", "w1", {}), ToolCall("2", "w2", {})],
            registry,
            ToolContext("."),
        )
        print(f"\n串行执行事件序列：{events}")
        assert events == ["w1:start", "w1:end", "w2:start", "w2:end"]

    def test_observations_preserve_call_order(self):
        # 并发完成顺序不同（fast 先完成），回填仍按模型原始顺序（slow 在前）
        registry = ToolRegistry([
            _make_tool("fast", delay=0.0, concurrency_safe=True),
            _make_tool("slow", delay=0.15, concurrency_safe=True),
        ])
        result = execute_calls(
            [ToolCall("1", "slow", {}), ToolCall("2", "fast", {})],
            registry,
            ToolContext("."),
        )
        names = [call.name for call, _ in result.observations]
        print(f"\n回填顺序：{names}（期望 ['slow', 'fast']，尽管 fast 先完成）")
        assert names == ["slow", "fast"]

    def test_one_crash_does_not_lose_others(self):
        # 一个工具崩溃不丢失其他调用结果（异常被 Registry 防火墙归一化）
        registry = ToolRegistry([
            _make_tool("boom", boom=True, concurrency_safe=True),
            _make_tool("ok", concurrency_safe=True),
        ])
        result = execute_calls(
            [ToolCall("1", "boom", {}), ToolCall("2", "ok", {})],
            registry,
            ToolContext("."),
        )
        assert len(result.observations) == 2
        assert result.observations[0][1].ok is False
        assert result.observations[0][1].error_code == "tool_crash"
        assert result.observations[1][1].ok is True

    def test_metrics_record_error_code(self):
        # 失败工具的指标带 error_code；成功工具 error_code 为 None
        registry = ToolRegistry([_make_tool("ok", concurrency_safe=True)])
        result = execute_calls(
            [ToolCall("1", "ok", {}), ToolCall("2", "nope", {})],
            registry,
            ToolContext("."),
        )
        metrics = {m.name: m for m in result.metrics}
        print(f"\n指标：{[ (m.name, m.ok, m.error_code) for m in result.metrics ]}")
        assert metrics["ok"].ok is True
        assert metrics["ok"].error_code is None
        assert metrics["nope"].ok is False
        assert metrics["nope"].error_code == "unknown_tool"

    def test_failed_tool_carries_recovery_hint(self):
        # 失败结果的 metadata 附有恢复建议（系统注记，非用户消息）
        result = execute_calls(
            [ToolCall("1", "nope", {})], ToolRegistry([]), ToolContext(".")
        )
        obs = result.observations[0][1]
        assert obs.ok is False
        assert obs.metadata.get("recovery_hint")
        print(f"\n恢复建议：{obs.metadata['recovery_hint']}")


class TestAgentRecovery:
    def test_empty_response_retries_then_succeeds(self):
        # 空响应 → 注入 nudge（user 消息）→ 重试后正常结束
        model = ScriptedModel([
            AgentStep(type="assistant", kind="final", content=""),
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], "."
        )
        assert stop_reason == "done"
        nudge = [m for m in history if m.get("role") == "user" and "回复为空" in m.get("content", "")]
        assert nudge, "空响应后应注入 user 角色的唤醒提示"
        assert history[-1]["content"] == "完成"
        print("\n=== 空响应重试历史 ===")
        for m in history:
            print(m)

    def test_empty_response_stops_at_limit(self):
        # 空响应达上限后明确停止，不死循环
        model = ScriptedModel([
            AgentStep(type="assistant", kind="final", content=""),
            AgentStep(type="assistant", kind="final", content=""),
            AgentStep(type="assistant", kind="final", content=""),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], ".",
            empty_response_retry_limit=3,
        )
        assert stop_reason == "empty_response"

    def test_consecutive_failures_stop(self, tmp_path: Path):
        # 同一工具连续失败达阈值即停，模型反复踩同一个坑不会死循环
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "no_such_tool", {})]),
            AgentStep(type="tool_calls", calls=[ToolCall("2", "no_such_tool", {})]),
            AgentStep(type="tool_calls", calls=[ToolCall("3", "no_such_tool", {})]),
            AgentStep(type="assistant", kind="final", content="不该走到这里"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], str(tmp_path),
            max_consecutive_failures=3,
        )
        assert stop_reason == "max_failures"
        assert len(model.received_messages) == 3  # 第 3 次失败后停止，不再请求第 4 步
