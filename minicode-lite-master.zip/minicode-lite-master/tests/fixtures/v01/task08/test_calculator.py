import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import add, power


def test_add():
    assert add(2, 3) == 5


def test_power():
    assert power(2, 3) == 8
