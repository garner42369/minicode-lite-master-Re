"""Day 13 git + diff_viewer 演示：只读工作区证据。

运行（项目根目录）：
    python tests/git_diff_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.tooling import ToolContext
from minicode.tools.diff_viewer import DIFF_VIEWER
from minicode.tools.git import GIT


def main():
    context = ToolContext(cwd=".")

    # 1. git status（只读）
    print("== git status ==")
    result = GIT.run(GIT.validator({"subcommand": "status"}), context)
    print(f"  ok={result.ok}")
    print(result.output[:300])

    # 2. git commit（非只读，应拒绝）
    print("\n== git commit（应拒绝）==")
    result2 = GIT.run(GIT.validator({"subcommand": "commit"}), context)
    print(f"  ok={result2.ok}  {result2.output}")

    # 3. diff_viewer（纯 diff 展示）
    print("\n== diff_viewer ==")
    result3 = DIFF_VIEWER.run(
        DIFF_VIEWER.validator({"path": "demo.py", "before": "a = 1\nb = 2\n", "after": "a = 10\nb = 2\n"}),
        context,
    )
    print(result3.output)


if __name__ == "__main__":
    main()
