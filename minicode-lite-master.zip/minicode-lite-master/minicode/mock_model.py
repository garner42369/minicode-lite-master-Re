"""minicode 的离线模型替身：ScriptedModel（剧本式）与 MockModelAdapter（命令式）。

两种 Mock 各有用途：
- ScriptedModel：测试传入步骤队列，模型每次 next() 取下一步，精确编排复杂序列；
- MockModelAdapter：解析 /ls、/read、/cmd 等快捷命令，用于手工 Demo。

Mock 的目标不是「模拟模型的聪明」，而是「确定地控制状态迁移」。
"""

from __future__ import annotations

import time
from copy import deepcopy

from minicode.types import AgentStep, ChatMessage, ToolCall


class ScriptedModel:
    """按预设步骤队列返回的确定性模型替身。

    每次 next() 记录收到的消息快照，便于测试断言「第 N 次调用看到了什么历史」。
    步骤耗尽时抛 RuntimeError，而不是悄悄重复最后一步。
    """

    def __init__(self, steps: list[AgentStep]) -> None:
        self._steps = iter(steps)
        self.received_messages: list[list[ChatMessage]] = []

    def next(self, messages: list[ChatMessage], on_stream_chunk=None, store=None) -> AgentStep:
        # 深拷贝快照：外部后续改动 messages 不会影响已记录的历史
        self.received_messages.append(deepcopy(messages))
        try:
            step = next(self._steps)
        except StopIteration as exc:
            raise RuntimeError("ScriptedModel steps exhausted") from exc
        # 流式回调：该步有文本则回放，模拟真实模型的分块输出
        if on_stream_chunk and step.content:
            on_stream_chunk(step.content)
        return step


def _last_user_message(messages: list[ChatMessage]) -> str:
    for message in reversed(messages):
        if message.get("role") == "user":
            return message.get("content", "")
    return ""


def _last_tool_result(messages: list[ChatMessage]) -> ChatMessage | None:
    for message in reversed(messages):
        if message.get("role") == "tool_result":
            return message
    return None


class MockModelAdapter:
    """命令式 Mock：解析 /ls、/read、/cmd 等快捷命令，生成工具调用或总结。

    用于手工 Demo——没有真实 API key 也能体验「输入 → 工具调用 → 结果回填」。
    """

    def next(self, messages: list[ChatMessage], on_stream_chunk=None, store=None) -> AgentStep:
        # 有工具结果回填时，生成总结回复
        tool_result = _last_tool_result(messages)
        if tool_result is not None:
            tool_name = tool_result.get("tool_name", "")
            content = tool_result.get("content", "")
            return AgentStep(type="assistant", kind="final", content=f"[{tool_name}] 结果：\n{content}")

        user_text = _last_user_message(messages).strip()
        tool_id = f"mock-{int(time.time() * 1000)}"

        if user_text == "/tools":
            return AgentStep(
                type="assistant",
                kind="final",
                content="Available tools: list_files, read_file, grep_files, run_command",
            )

        if user_text.startswith("/ls"):
            directory = user_text[len("/ls"):].strip()
            arguments = {"path": directory} if directory else {}
            return AgentStep(type="tool_calls", calls=[ToolCall(id=tool_id, name="list_files", arguments=arguments)])

        if user_text.startswith("/read "):
            path = user_text[len("/read "):].strip()
            return AgentStep(type="tool_calls", calls=[ToolCall(id=tool_id, name="read_file", arguments={"path": path})])

        if user_text.startswith("/cmd "):
            command = user_text[len("/cmd "):].strip()
            return AgentStep(type="tool_calls", calls=[ToolCall(id=tool_id, name="run_command", arguments={"command": command})])

        return AgentStep(
            type="assistant",
            kind="final",
            content="This is a minimal MiniCode shell.\nTry: /tools /ls /read README.md /cmd pwd",
        )
