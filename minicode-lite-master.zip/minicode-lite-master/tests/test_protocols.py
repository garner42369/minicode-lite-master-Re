"""Day 2：协议构造、序列化与工具调用 ID 配对的离线测试。"""

from dataclasses import asdict

from minicode.tooling import (
    ToolCapability,
    ToolContext,
    ToolDefinition,
    ToolMetadata,
    ToolResult,
)
from minicode.types import AgentStep, ChatMessage, ModelAdapter, RuntimeEvent, ToolCall


def test_chat_message_roles():
    msg: ChatMessage = {"role": "user", "content": "修复 divide 的失败测试"}
    assert msg["role"] == "user"
    assert msg["content"].startswith("修复")


def test_tool_call_has_stable_id():
    # 核心约束：工具调用必须有稳定 ID，才能把结果配对回对应调用
    call = ToolCall(id="call-1", name="read_file", arguments={"path": "README.md"})
    assert call.id == "call-1"
    assert (call.id, call.name) == ("call-1", "read_file")


def test_agent_step_distinguishes_progress_from_final():
    # 核心约束：进度与最终回答必须可区分
    progress = AgentStep(type="assistant", content="正在读取文件…", kind="progress")
    final = AgentStep(type="assistant", content="完成", kind="final")
    assert progress.kind != final.kind
    assert final.kind == "final"


def test_agent_step_can_request_tools():
    call = ToolCall(id="call-2", name="grep_files", arguments={"pattern": "divide"})
    step = AgentStep(type="tool_calls", calls=[call])
    assert step.type == "tool_calls"
    assert step.calls[0].id == "call-2"


class _HelloAdapter:
    """最简假 Adapter：无视输入，永远返回一句 final 文本，用于验证协议贯通。"""

    def next(self, messages, on_stream_chunk=None, store=None):
        return AgentStep(type="assistant", content="hello", kind="final")


def test_model_adapter_protocol_roundtrip():
    # Day 2 的 Demo：假 Adapter 走一遍「消息 → 模型 → AgentStep」
    adapter: ModelAdapter = _HelloAdapter()
    messages: list[ChatMessage] = [{"role": "user", "content": "hi"}]
    step = adapter.next(messages)
    assert step.type == "assistant"
    assert step.content == "hello"
    assert step.kind == "final"


def test_tool_result_uniform_receipt():
    ok = ToolResult(ok=True, output="2 passed")
    bad = ToolResult(ok=False, output="Unknown tool", error_code="unknown_tool")
    assert ok.ok and bad.ok is False
    assert bad.error_code == "unknown_tool"


def test_tool_metadata_capabilities():
    meta = ToolMetadata(
        name="read_file",
        description="读取文件",
        capabilities={ToolCapability.READ_ONLY, ToolCapability.CONCURRENCY_SAFE},
    )
    assert meta.is_read_only is True
    assert meta.is_destructive is False
    assert meta.is_concurrency_safe is True


def test_tool_definition_runs_and_returns_result():
    def _noop_validator(raw):
        return raw

    def _echo_run(args, ctx: ToolContext):
        return ToolResult(ok=True, output=str(args))

    tool = ToolDefinition(
        validator=_noop_validator,
        run=_echo_run,
        metadata=ToolMetadata(
            name="echo",
            description="回显输入",
            input_schema={"type": "object"},
        ),
    )
    ctx = ToolContext(cwd=".")
    result = tool.run(tool.validator({"x": 1}), ctx)
    assert result.ok is True
    assert result.output == "{'x': 1}"


def test_runtime_event_serializable():
    # RuntimeEvent 是 frozen dataclass，可安全序列化（asdict）供 UI/评估消费
    ev = RuntimeEvent(category="stop", message="done", stop_reason="done")
    data = asdict(ev)
    assert data["category"] == "stop"
    assert data["stop_reason"] == "done"
