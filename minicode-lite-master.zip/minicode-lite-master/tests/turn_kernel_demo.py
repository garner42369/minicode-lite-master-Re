"""Day 14 Turn Kernel 演示：验证证据与终止判断。

运行（项目根目录）：
    python tests/turn_kernel_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.turn_kernel import TurnState, decide_final


def main():
    # 1. 修改后直接 final（应被拦截）
    print("== 1. 修改后直接 final ==")
    s1 = TurnState()
    s1.record_change("hash-v1")
    d1 = decide_final(s1, requires_verification=True)
    print(f"  terminal={d1.terminal} reason={d1.reason} nudge={d1.nudge!r}")

    # 2. 验证通过 → done
    print("\n== 2. 验证通过 → done ==")
    s1.record_verification("hash-v1", passed=True)
    d2 = decide_final(s1, requires_verification=True)
    print(f"  terminal={d2.terminal} reason={d2.reason}")

    # 3. 验证后再修改 → 证据失效
    print("\n== 3. 验证后再修改 → 证据失效 ==")
    s1.record_change("hash-v2")
    d3 = decide_final(s1, requires_verification=True)
    print(f"  evidence_ready={s1.evidence_ready()} terminal={d3.terminal} reason={d3.reason}")

    # 4. 验证失败 → verification_failed
    print("\n== 4. 验证失败 ==")
    s2 = TurnState()
    s2.record_change("hash-v1")
    s2.record_verification("hash-v1", passed=False)
    d4 = decide_final(s2, requires_verification=True)
    print(f"  terminal={d4.terminal} reason={d4.reason}")

    # 5. 只读任务（无需验证）→ done
    print("\n== 5. 只读任务（无需验证）==")
    s3 = TurnState()
    d5 = decide_final(s3, requires_verification=False)
    print(f"  terminal={d5.terminal} reason={d5.reason}")


if __name__ == "__main__":
    main()
