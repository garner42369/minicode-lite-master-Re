"""Day 12 受控写入事务演示：apply_reviewed_change 的 diff → 审批 → 写入。

运行（项目根目录）：
    python tests/reviewed_change_demo.py

展示三种行为：审批通过（写入 + checkpoint）、审批拒绝（文件不变）、
无变化短路（返回 None 不写入）。
"""

import sys
import tempfile
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.file_review import apply_reviewed_change


def single_replace(old, new):
    """构造一个「单替换」transform：旧文本恰好出现一次才替换，否则报错。"""

    def transform(text):
        count = text.count(old)
        if count != 1:
            raise ValueError(f"expected one match, found {count}")
        return text.replace(old, new, 1)

    return transform


def main():
    with tempfile.TemporaryDirectory() as directory:
        target = Path(directory) / "calculator.py"
        target.write_text("def divide(a, b): return a // b\n", encoding="utf-8")

        # 1. 审批通过
        print("== 审批通过 ==")
        checkpoint = apply_reviewed_change(
            target,
            single_replace("a // b", "a / b"),
            lambda diff: print(f"  [审批 diff]\n{diff}") or True,
            "group-1",
        )
        print(f"  文件内容: {target.read_text(encoding='utf-8')!r}")
        print(f"  checkpoint: existed={checkpoint.existed}, before={checkpoint.before!r}")

        # 2. 审批拒绝
        print("\n== 审批拒绝（文件不变）==")
        try:
            apply_reviewed_change(
                target,
                single_replace("a / b", "a * b"),
                lambda diff: False,
                "group-2",
            )
        except PermissionError as exc:
            print(f"  拒绝: {exc}")
        print(f"  文件内容(应不变): {target.read_text(encoding='utf-8')!r}")

        # 3. 无变化短路
        print("\n== 无变化短路 ==")
        result = apply_reviewed_change(
            target,
            lambda text: text,  # 原样返回，无变化
            lambda diff: True,
            "group-3",
        )
        print(f"  返回: {result}（None 表示无变化，未写入）")


if __name__ == "__main__":
    main()
