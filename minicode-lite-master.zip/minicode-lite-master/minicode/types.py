"""minicode 的共享协议：消息、工具调用、模型步骤、运行事件与模型适配器。

这是系统所有层（模型、工具、Loop、UI）的「共同语言」。定义在此处的三条约束：

1. Provider 的原始 JSON 不离开 Adapter —— Adapter 负责把外部格式翻译成本协议；
2. 一次工具调用必须有稳定 ID，用于把工具结果配对回对应的调用；
3. 进度（progress）与最终回答（final）必须可区分，否则 Loop 会在进度播报后错误结束。
"""
#类型注解很多！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
# s: str = " ",相当于 s = ""，只是类型注解更明确
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Protocol, TypedDict


class ChatMessage(TypedDict, total=False):
    """一条对话消息。total=False 表示字段可缺省（不同角色用不同字段子集）。"""

    role: Literal[
        "system",
        "user",
        "assistant",
        "assistant_progress",
        "assistant_tool_call",
        "tool_result",
    ]
    content: str
    tool_call_id: str  # 工具结果消息用它配对回对应的 tool call
    tool_name: str
    input: dict[str, Any]
    is_error: bool
    # Provider thinking 模式的思考链（DeepSeek V4 的 reasoning_content）。
    # 带工具调用的 assistant 消息回传时必须带上它，否则 Provider 返回 400。
    reasoning: str


@dataclass(frozen=True, slots=True)
class ToolCall:
    """模型发起的一次工具调用。id 必须稳定，用于与 ToolResult 配对。"""

    id: str
    name: str
    arguments: dict[str, Any]


@dataclass(slots=True)
class AgentStep:
    """模型的一步产出：要么是文本（assistant），要么是工具请求（tool_calls）。"""

    type: Literal["assistant", "tool_calls"]
    content: str = ""
    # kind 区分进度播报与最终回答，Loop 据此判断是否真正结束
    kind: Literal["final", "progress"] | None = None
    # calls：模型这一步请求调用的工具列表（type == "tool_calls" 时非空）。
    # 用 field(default_factory=list) 而非 = []：dataclass 若用 = [] 会让所有
    # 实例共享同一个可变列表作为默认值，这是 Python 的经典陷阱。
    calls: list[ToolCall] = field(default_factory=list)
    # Provider 特有的思考链（thinking block）。课程要求 Provider 的 thinking
    # 只能存在于 Adapter 或明确的诊断字段中，不能污染核心协议语义；这里就是
    # 那个「诊断字段」。Loop 把它透传回历史，供下一轮回传给 Provider。
    reasoning: str = ""


# 运行事件类别，供 UI / 评估消费
RuntimeEventCategory = Literal[
    "phase",
    "compaction",
    "guard",
    "widening",
    "recovery",
    "stop",
]


@dataclass(frozen=True, slots=True)
class RuntimeEvent:
    """运行时向 UI 发出的结构化事件，用于可观测性。frozen 保证事件不可被中途篡改。"""

    category: RuntimeEventCategory  # 事件类别：阶段 / 压缩 / 守卫 / 扩大 / 恢复 / 停止
    message: str                    # 人类可读的事件描述
    step: int | None = None         # 触发事件时处于第几步；None 表示与步骤无关
    profile: str = ""               # 当前运行画像，如 single / single-deep
    phase: str = ""                 # 当前阶段，如 explore / execute / verify
    stop_reason: str = ""           # 停止原因，如 done / max_steps / await_user
    widening_reason: str = ""       # 触发 widening 的原因；空串表示未 widening
    evidence_summary: str = ""      # 验证证据摘要，供评估报告使用


class ModelAdapter(Protocol):
    """模型适配器协议。上层 Loop 只依赖 next()，不关心背后是哪个 Provider。

    所有 Provider（Anthropic / OpenAI-compatible / Mock）都实现同一个 next()，
    把各自的原始 JSON 翻译成统一的 AgentStep 返回。
    """
    # 这就是一个接口，定义了 Provider 必须实现的方法

    def next(
        self,
        messages: list[ChatMessage],                            # 当前完整对话历史
        on_stream_chunk: Callable[[str], None] | None = None,   # 可选流式回调：每收到一段增量文本就调用一次
        store: Any | None = None,                               # 可选会话存储引用，供 Provider 持久化 usage 等
    ) -> AgentStep: ...
    '''
    等价于 def next(...)-> AgentStep: 
        ...
    要让 Provider 实现这个协议，必须实现 next() 方法。
    '''
