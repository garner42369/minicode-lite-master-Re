import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import divide


def test_divide():
    assert divide(5, 2) == 2
