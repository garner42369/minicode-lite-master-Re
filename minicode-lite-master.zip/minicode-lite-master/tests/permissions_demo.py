"""Day 11 权限系统演示：PermissionManager.check() 各模式行为。

运行（项目根目录）：
    python tests/permissions_demo.py

展示四种模式（plan/default/auto/bypass）对同一批请求的不同裁决，以及
allow_turn 的本轮记忆、deny_with_feedback 的反馈携带。
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path：命令行 `python tests/xxx.py` 时 sys.path[0] 是 tests/
# 而非项目根，不加会找不到 minicode 包
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.permissions import (
    Mode,
    PermissionDecision,
    PermissionKind,
    PermissionManager,
    PermissionRequest,
    RiskLevel,
)


def show(label, request, manager):
    decision = manager.check(request)
    feedback = f"  ({decision.feedback})" if decision.feedback else ""
    print(f"{label:34} -> {decision.verdict}{feedback}")


def main():
    read_req = PermissionRequest(PermissionKind.PATH, "README.md", "读文件", RiskLevel.SAFE)
    write_req = PermissionRequest(PermissionKind.PATH, "README.md", "写文件", RiskLevel.MEDIUM)
    edit_req = PermissionRequest(PermissionKind.EDIT, "demo.py", "apply diff", RiskLevel.MEDIUM)
    cmd_req = PermissionRequest(PermissionKind.COMMAND, "rm -rf /tmp/x", "删目录", RiskLevel.DANGEROUS)

    print("== plan 模式（只读）==")
    plan = PermissionManager(".", Mode.PLAN)
    show("  读文件(safe path)", read_req, plan)
    show("  写文件(medium path)", write_req, plan)
    show("  编辑(edit)", edit_req, plan)
    show("  命令(command)", cmd_req, plan)

    print("\n== auto 模式（安全自动过）==")
    auto = PermissionManager(".", Mode.AUTO)
    show("  读文件(safe)", read_req, auto)
    show("  写文件(medium)", write_req, auto)

    print("\n== default 模式 + 无 prompt（默认拒绝）==")
    no_prompt = PermissionManager(".", Mode.DEFAULT)
    show("  写文件", write_req, no_prompt)

    print("\n== default 模式 + prompt（allow_turn 记忆）==")
    def ask_turn(request):
        print(f"    [询问用户] {request.kind.value}:{request.scope} (risk={request.risk.value})")
        return PermissionDecision("allow_turn")

    with_prompt = PermissionManager(".", Mode.DEFAULT, prompt=ask_turn)
    show("  第一次写文件", write_req, with_prompt)
    show("  第二次写文件(本轮已授权)", write_req, with_prompt)

    print("\n== deny_with_feedback（反馈进上下文）==")
    def deny_ask(request):
        return PermissionDecision("deny_with_feedback", "这个文件受保护，请改用其他方式")

    deny_mgr = PermissionManager(".", Mode.DEFAULT, prompt=deny_ask)
    show("  写受保护文件", write_req, deny_mgr)

    print("\n== bypass（跳过审批）==")
    bypass = PermissionManager(".", Mode.BYPASS)
    show("  危险命令", cmd_req, bypass)


if __name__ == "__main__":
    main()
