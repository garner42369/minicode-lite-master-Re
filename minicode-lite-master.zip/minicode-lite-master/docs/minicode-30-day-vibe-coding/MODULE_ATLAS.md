# MiniCode Python 130 模块地图

本索引对应当前规范包 `minicode/`：81 个顶层 Python 文件、30 个 `tools/` 文件、19 个 `tui/` 文件。`__init__.py` 也计入文件数。

标记说明：

- **C 核心**：最小 Coding Agent 闭环所需；
- **P 产品**：日常可用、恢复、交互或扩展能力；
- **A 高级**：自适应、控制论、研究或评估增强；
- **U 工具**：可按需启用的通用工具封装。

“接入点”说明该模块主要被谁消费或把结果交给谁。复现时优先保证调用方向，不要求文件名或内部类逐字一致。

## 一、协议、入口与运行时装配（16）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `__init__.py` | C | 包标识；避免承载运行时副作用 | Python import system | 2 |
| `types.py` | C | 消息、模型步骤、工具调用、诊断和运行事件的共享协议 | Adapter、Loop、TUI | 2 |
| `config.py` | C | 合并用户/项目/环境配置，构造有效运行设置并诊断 | main、headless、registry | 3 |
| `logging_config.py` | P | 文本/结构化日志、轮转、API/工具/权限/会话事件 | 所有运行时组件 | 3 |
| `main.py` | C | 交互 CLI 装配、会话管理参数、TTY/非 TTY 入口选择 | 整个 Runtime | 21 |
| `headless.py` | P | 一次性非交互运行、CI 权限语义、trace 输出 | 共享 Agent Runtime | 21 |
| `install.py` | P | 安装启动器、PATH 和初始配置引导 | 用户环境 | 3/21 |
| `manage_cli.py` | P | 模型、MCP、Skill 等管理命令分发 | main/TTY | 21/23/24 |
| `cli_commands.py` | P | `/session`、`/memory`、`/readiness` 等本地命令 | main、TUI、产品面 | 21/25 |
| `local_tool_shortcuts.py` | P | `/ls`、`/read`、`/grep`、`/cmd` 快捷命令解析 | main、input handler | 21 |
| `history.py` | P | 用户输入历史的读取、缓存和保存 | CLI/TUI 输入 | 15/21 |
| `state.py` | P | 进程内 AppState Store、订阅、费用/忙碌/上下文状态 | TUI、Adapter、Loop | 15/21 |
| `user_profile.py` | P | USER.md 偏好解析、序列化和命令 | Prompt、CLI | 21 |
| `product_surfaces.py` | P | 指令、扩展、Hook、委派和 readiness 的可序列化快照 | Prompt、Session、CLI | 25 |
| `capability_registry.py` | P | 自描述能力注册、scope、执行统计与发现 | Loop、Orchestrator、诊断 | 25 |
| `workspace.py` | C | 规范化工具路径并统一执行路径/权限边界 | 所有文件类工具 | 6 |

## 二、Agent 核心、任务与策略（20）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `agent_loop.py` | C | 模型—工具循环和各子系统总集成点 | entry、Kernel、Adapter、Tools | 7–14 |
| `turn_kernel.py` | C | 单轮预算、阶段、widening、停止和验证决策 | Agent Loop | 14 |
| `mock_model.py` | C | 离线命令式 Mock；复现时配合 ScriptedModel | Loop 测试、Demo | 4 |
| `intent_parser.py` | P | 将自然语言任务映射为 intent/action 信号 | Task Builder、Feedforward | 14 |
| `task_object.py` | P | 稳定任务目标、约束、预期输出和状态 | Turn Prelude、Pipeline | 14 |
| `task_tracker.py` | P | 轻量待办、进度条和持久化 | CLI/TUI、Session | 14/26 |
| `task_graph.py` | P | 有依赖的任务图、任务槽、进度和 worktree 隔离 | Pipeline、子 Agent | 26 |
| `pipeline_engine.py` | P | plan/execute/verify 多步骤流水线 | Task Object、验证控制 | 26 |
| `agent_intelligence.py` | P | 工具错误分类、恢复 nudge、并发调度 | Agent Loop、Metrics | 8 |
| `agent_metrics.py` | A | 单轮与工具历史成功率、耗时和错误指标 | Scheduler、控制层 | 8/27 |
| `progress_controller.py` | A | 根据证据、错误和预算判断推进/停滞 | Kernel、Orchestrator | 27 |
| `verification_controller.py` | A | 按变更风险选择 none/targeted/full 验证 | Pipeline、Turn Kernel | 14/27 |
| `domain_classifier.py` | P | 为记忆/任务标注领域，辅助过滤与路由 | Memory、Router | 19/27 |
| `agent_router.py` | A | 任务复杂度画像与模型层级建议 | Smart Router | 27 |
| `model_switcher.py` | A | 运行时模型切换和有界 fallback | Smart Router、Loop | 10/27 |
| `smart_router.py` | A | 组合任务路由、模型切换与结果反馈 | Loop/Orchestrator | 27 |
| `decision_audit.py` | A | 记录自动决策的候选、理由、结果 | Pipeline、控制层 | 27 |
| `agent_reflection.py` | A | 任务后反思并生成候选经验 | Memory Pipeline | 20/29 |
| `runtime_profiles.py` | P | `single`/`single-deep` 的步数、重试与 widening 策略 | Loop、评估 | 14 |
| `background_tasks.py` | P | 后台进程登记、槽位、状态刷新和完成回调 | run_command、产品面 | 13/26 |

## 三、工具框架与安全（6）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `tooling.py` | C | ToolDefinition/Result/Context/Registry、验证、异常防火墙、输出预算 | Loop、所有工具 | 5 |
| `permissions.py` | C | 路径、命令和编辑审批及授权生命周期 | workspace、文件/命令工具 | 11 |
| `auto_mode.py` | P | default/auto/plan/bypass 和风险分类 | PermissionManager | 11 |
| `file_review.py` | C | unified diff、编辑审批、Checkpoint、写入共用流程 | 写工具 | 12 |
| `api_retry.py` | P | Provider 错误分类、退避、Retry-After 和有限异步重试 | 模型 Adapter | 10 |
| `circuit_breaker.py` | P | 压缩连续失败熔断与自动复位 | Context Compactor | 18 |

## 四、模型、Prompt 与成本（10）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `model_registry.py` | C | Provider 识别、模型元数据、配置和 Adapter 工厂 | entry、router、switcher | 10 |
| `anthropic_adapter.py` | C/P | Anthropic 消息、Tool Use、流式和 usage 转换 | Agent Loop | 10 |
| `openai_adapter.py` | C/P | OpenAI-compatible 消息、Tool Call、流式和 usage 转换 | Agent Loop | 10 |
| `prompt_pipeline.py` | C | 静态/动态 Prompt section、TTL/mtime 缓存 | prompt.py | 9 |
| `prompt.py` | C | 构造角色、治理、权限、Skills、MCP、Memory 和产品快照 | entry、Adapter | 9 |
| `cost_tracker.py` | P/A | 模型 usage 与费用计算、累计统计 | Adapter、TUI | 10/27 |
| `cost_control.py` | A | 成本速率传感器、预算 PID 与预算执行器 | Orchestrator、Compactor | 28 |
| `feedforward_controller.py` | A | 根据任务意图预先配置步数、模型和风险 | Turn Prelude | 28 |
| `feedback_controller.py` | A | 根据运行状态产生并发、压缩和策略控制信号 | Orchestrator | 28 |
| `predictive_controller.py` | A | 指数平滑/移动平均趋势预测和预防动作 | Orchestrator | 28 |

## 五、上下文与记忆（15）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `context_manager.py` | C | 模型窗口、Token 估算、ContextStats 和基础压缩 | Agent Loop | 17 |
| `context_compactor.py` | C/P | 工具预算、读取去重、自动/响应压缩和结构化结果 | Loop、Context Manager | 17–18 |
| `micro_compact.py` | P | 确定性的轻量消息/工具结果裁剪 | 压缩前置层 | 17–18 |
| `layered_context.py` | P | 系统、任务、工作记忆、近期对话、检索记忆分层预算 | Turn Prelude | 18 |
| `working_memory.py` | C/P | 带 TTL/重要度的当前任务受保护事实和连续性标记 | Compactor、Kernel | 18 |
| `memory.py` | C/P | user/project/local 长期记忆、BM25/TF-IDF、管理与持久化 | Prompt、Pipeline | 19 |
| `memory_pipeline.py` | P | 统一记忆 read/inject/write/feedback/maintain 生命周期 | Agent Loop/Orchestrator | 20 |
| `memory_injector.py` | P/A | 基于相关性和上下文压力决定注入模式与预算 | Pipeline、Loop | 20 |
| `memory_reranker.py` | A | 用模型策展初筛记忆，带缓存和 fallback | Memory Pipeline | 20 |
| `memory_curator_agent.py` | A | 后台合并、衰减、冲突与记忆维护报告 | Memory Pipeline | 20 |
| `vector_memory.py` | A | 稀疏/可选向量检索及与 BM25 结果融合 | Memory Pipeline | 20 |
| `timeline_memory.py` | A | 时间线事件、最新状态、日期/数值推理 | 可选 Timeline 插件 | 20 |
| `context_cybernetics.py` | A | 上下文压力 PID、预测守卫、阈值和策略选择 | Orchestrator/Compactor | 28 |
| `state_observer.py` | A | Kalman 风格状态估计和置信度 | Orchestrator | 28 |
| `adaptive_pid_tuner.py` | A | Ziegler-Nichols、Relay、Gradient 与自适应 PID 整定 | 控制器离线/运行调参 | 28 |

## 六、会话、扩展与产品生命周期（7）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `session.py` | C/P | Session 全量/Delta、Checkpoint、Inspect/Replay/Resume/Rewind | entry、TUI、写工具 | 15–16 |
| `skills.py` | P | SKILL.md 发现、按需加载、托管安装/删除 | Prompt、load_skill | 23 |
| `hooks.py` | P | 生命周期 Hook 注册、同步/异步触发、启停和统计 | Loop、Session | 23 |
| `mcp.py` | P | stdio MCP 工具/资源/Prompt、懒启动、请求关联和关闭 | Tool Registry | 24 |
| `release_readiness.py` | A/P | Provider/Runtime 发布检查的分类和报告 | CLI、benchmark | 25/30 |
| `runtime_profile_eval.py` | A | 运行画像场景评估和报告 | benchmarks | 30 |
| `paper_a_task_completion_eval.py` | A | 任务完成条件、汇总表和论文型评估产物 | evaluation harness | 30 |

## 七、控制论与自愈增强层（8）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `cybernetic_orchestrator.py` | A | 控制器构建、接线、生命周期和统一外观 | Agent Runtime Extension | 29 |
| `cybernetic_supervisor.py` | A | 聚合控制快照、风险和全局报告 | Orchestrator、产品面 | 29 |
| `cybernetic_ablation.py` | A | 固定条件下对比控制模块组合的收益与代价 | benchmarks | 29–30 |
| `stability_monitor.py` | A | 健康度、趋势、振荡和异常记录 | Orchestrator/Supervisor | 29 |
| `self_healing_engine.py` | A | 受限故障检测、恢复策略和统计 | Orchestrator | 29 |
| `decoupling_controller.py` | A | 分析多变量耦合并生成解耦控制命令 | Orchestrator | 28 |
| `progress_controller.py` | A | 任务进度和停滞控制信号 | Loop/Orchestrator | 27 |
| `verification_controller.py` | A | 风险自适应验证信号和计划 | Pipeline/Orchestrator | 14/27 |

> `progress_controller.py` 与 `verification_controller.py` 已在 Agent 策略表中出现，这里再次显示它们在控制层的第二角色；文件总数统计只计一次。

## 八、内置工具（30）

### 8.1 注册与核心 Coding Tools（20）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `tools/__init__.py` | C | 组装 core/full 工具画像、Skills 与 MCP 工具，返回 Registry | entry | 5/24 |
| `tools/ask_user.py` | C/P | 结构化提问并让本轮进入 await_user | Turn Kernel、TUI | 8/11 |
| `tools/list_files.py` | C | 单层目录查看 | Workspace/Registry | 6 |
| `tools/read_file.py` | C | 带 offset/limit/截断头的 UTF-8 文本读取 | Workspace/Context | 6/17 |
| `tools/grep_files.py` | C | 正则、glob、上下文行、目录/二进制跳过 | Workspace/Registry | 6 |
| `tools/file_tree.py` | P | 可视层级、大小、时间和状态树 | Workspace/TUI | 6 |
| `tools/write_file.py` | C | 新建或完整写入，走 reviewed change | File Review | 12 |
| `tools/edit_file.py` | C | 精确替换、匹配歧义与 fuzzy 选项 | File Review | 12 |
| `tools/patch_file.py` | C | 同文件多次精确替换 | File Review | 12 |
| `tools/modify_file.py` | P | write_file 的兼容包装；新实现不应复制逻辑 | Registry | 12 |
| `tools/run_command.py` | C | 受控命令、shell 模式、超时、输出截断与后台启动 | Permission/Background | 13 |
| `tools/test_runner.py` | P | 测试发现、pytest/unittest 运行与摘要 | run_command/验证控制 | 13 |
| `tools/git.py` | P | status/diff/log/commit/review 操作 | Permission、Agent | 13 |
| `tools/diff_viewer.py` | P | 读取和格式化工作区差异 | TUI/Agent | 13 |
| `tools/todo_write.py` | P | 模型维护多步骤待办和进度 | Task Tracker/Session | 14 |
| `tools/task.py` | P | 创建受限子 Agent 并返回结构化结果 | Agent Loop/Task Graph | 26 |
| `tools/load_skill.py` | P | 按需读取已发现 Skill 全文 | Skills/Prompt | 23 |
| `tools/code_nav.py` | P | AST 符号、引用与结构导航 | Workspace/Agent | 6 |
| `tools/code_review.py` | P | 启发式代码审查与问题摘要 | Workspace/Agent | 6/30 |
| `tools/batch_ops.py` | P | 批量复制、移动、删除并复用路径边界 | Permission/Workspace | 12 |

### 8.2 网络与通用 Utility Tools（10）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `tools/web_fetch.py` | P | URL 安全检查、获取网页并提取文本 | Registry/Permission | 24/25 |
| `tools/web_search.py` | P | 搜索请求与结果解析 | Registry/Permission | 24/25 |
| `tools/http_utils.py` | U | 通用 HTTP 请求包装 | full tool profile | 25 |
| `tools/json_utils.py` | U | JSON 格式化与解析 | full tool profile | 25 |
| `tools/regex_utils.py` | U | 正则测试与替换 | full tool profile | 25 |
| `tools/encoding_utils.py` | U | Base64 与 URL 编解码 | full tool profile | 25 |
| `tools/crypto_utils.py` | U | 时间戳、hash、HMAC 等确定性辅助 | full tool profile | 25 |
| `tools/archive_utils.py` | U | gzip/tar/zip 创建与安全解压 | full tool profile/Workspace | 25 |
| `tools/csv_utils.py` | U | CSV 解析与创建 | full tool profile | 25 |
| `tools/text_utils.py` | U | UUID、排序、去重、拼接、行数、随机串 | full tool profile | 25 |

通用 Utility Tools 不应默认全部暴露给模型。工具数量越多，Prompt 越大、选错概率越高。参考项目通过 `toolProfile=full` 懒加载它们，这是复现时应保留的产品策略。

## 九、TUI（19）

| 模块 | 层级 | 作用 | 主要接入点 | 课程日 |
| --- | --- | --- | --- | --- |
| `tui/__init__.py` | P | 导出稳定 TUI 公共接口 | tty_app/测试 | 22 |
| `tty_app.py` | P | TTY 顶层生命周期、状态、输入线程和渲染调度 | main、所有 TUI 子层 | 22 |
| `tui/types.py` | P | TranscriptEntry 与对象复用 | transcript、tool lifecycle | 22 |
| `tui/state.py` | P | TtyAppArgs、ScreenState、PendingApproval | event/renderer/session | 22 |
| `tui/input_parser.py` | P | 字节流到 Key/Text/Wheel 事件，处理转义与粘贴 | event_flow | 22 |
| `tui/event_flow.py` | P | normal/approval/feedback 模式事件路由 | input_handler/state | 22 |
| `tui/input_handler.py` | P | 提交任务、本地命令、运行 Agent 并接收事件 | agent_loop、CLI、Session | 22 |
| `tui/input.py` | P | 输入提示框文本渲染 | renderer | 22 |
| `tui/navigation.py` | P | Transcript 滚动、历史与 slash 匹配 | event_flow/renderer | 22 |
| `tui/transcript.py` | P | 条目渲染、可见窗口、布局缓存、滚动条和纯文本导出 | renderer/session | 22 |
| `tui/renderer.py` | P | 整屏布局、header/footer 缓存和 render hash | runtime_control | 22 |
| `tui/chrome.py` | P | 面板、横幅、状态栏、Diff 与审批渲染原语 | renderer | 22 |
| `tui/markdown.py` | P | 终端 Markdown 与代码高亮 | transcript | 22 |
| `tui/theme.py` | P | 主题色和样式集中定义 | chrome/markdown | 22 |
| `tui/screen.py` | P | 光标、清屏、alternate screen 和终端能力 | runtime_control | 22 |
| `tui/runtime_control.py` | P | 节流渲染、进入/退出 TTY、窗口变化信号 | tty_app/renderer | 22 |
| `tui/session_flow.py` | P | 加载/创建/刷新/完成 TTY Session 和权限 prompt | tty_app/session | 22 |
| `tui/tool_lifecycle.py` | P | 工具条目 running→success/error、折叠与悬空清理 | input_handler/transcript | 22 |
| `tui/tool_helpers.py` | P | 工具输入/结果摘要、编辑进度、Transcript 保存 | input_handler/lifecycle | 22 |
| `tui/ui_hints.py` | P | 根据状态显示简短上下文帮助 | renderer | 22 |

> 顶层 `tty_app.py` 不在 `tui/` 子目录的 19 个文件计数中；表中为理解完整交互链路一并列出。`tui/` 子目录自身包含 `__init__.py` 加 18 个实现文件。

## 十、评估与仓库外围（不计入 130 个包模块）

| 路径 | 作用 | 课程日 |
| --- | --- | --- |
| `tests/` | 单元、集成、E2E、压力、属性和架构隔离测试 | 每天 / 30 |
| `benchmarks/runtime_profile_eval.py` | 运行画像评估入口 | 30 |
| `benchmarks/release_readiness.py` | 发布准备 runner | 30 |
| `benchmarks/performance_benchmark.py` | 性能基准 | 22/30 |
| `benchmarks/multi_round_stress_test.py` | 多轮稳定性 | 30 |
| `benchmarks/cluster_stress_test.py` | 集群/并发压力 | 30 |
| `.github/workflows/ci.yml` | 跨平台 compile、lint、type、test、packaging | 30 |
| `Dockerfile`、`docker-compose.yml` | 可选隔离和部署 | 30 |
| `.env.example` | 无真实密钥的配置模板 | 3 |
| `pyproject.toml` | 构建、入口、依赖和测试配置 | 2/3/30 |

## 十一、最小保留集与完整集

如果先做 15 文件版本，保留：

```text
types.py, config.py, tooling.py, workspace.py,
mock_model.py, agent_loop.py, turn_kernel.py,
permissions.py, file_review.py, model_registry.py,
prompt.py, session.py,
tools/__init__.py, tools/read_file.py, tools/run_command.py
```

这不是完整产品，但能承载最小 Agent 闭环。其余模块按“安全修改 → 恢复 → 上下文 → 记忆 → UI → 扩展 → 自适应 → 评估”的顺序附着。完整复现时，不要因为某模块标为 A/U 就跳过；应实现其职责、关闭开关和整合测试，而不是把它塞进核心路径。

