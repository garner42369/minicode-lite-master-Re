"""Day 18: 保护任务事实，按完整 Tool Call/Result 对压缩旧历史。"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class WorkingMemoryEntry:
    content: str
    importance: int
    expires_at: float

    @property
    def alive(self) -> bool:
        return time.time() < self.expires_at


@dataclass(slots=True)
class WorkingMemory:
    entries: list[WorkingMemoryEntry] = field(default_factory=list)

    def protect(self, content: str, importance: int = 5, ttl: float = 3600) -> None:
        self.entries.append(WorkingMemoryEntry(content, importance, time.time() + ttl))

    def render(self, limit: int = 5) -> str:
        active = sorted((e for e in self.entries if e.alive), key=lambda e: e.importance, reverse=True)
        return "\n".join(f"- {e.content}" for e in active[:limit])


def compact_messages(messages: list[dict[str, Any]], keep_recent: int, protected: WorkingMemory) -> list[dict[str, Any]]:
    if len(messages) <= keep_recent:
        return list(messages)
    cut = len(messages) - keep_recent
    # 不在 tool_result 前切开，避免留下没有请求的结果。
    while cut > 0 and messages[cut].get("role") == "tool_result":
        cut -= 1
    removed, recent = messages[:cut], messages[cut:]
    files = sorted({str(m.get("input", {}).get("path")) for m in removed if m.get("input", {}).get("path")})
    summary = {
        "role": "system",
        "content": "COMPACTED\nProtected:\n" + protected.render() + "\nFiles: " + ", ".join(files),
        "source_range": [0, max(0, cut - 1)],
    }
    return [summary, *recent]


if __name__ == "__main__":
    memory = WorkingMemory()
    memory.protect("目标：修复 divide", 10)
    messages = [{"role": "user", "content": str(i)} for i in range(8)]
    compacted = compact_messages(messages, 3, memory)
    assert "修复 divide" in compacted[0]["content"] and len(compacted) == 4
    print(compacted[0])

