import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import add, divide, subtract


def test_add():
    assert add(2, 3) == 5


def test_divide():
    assert divide(6, 3) == 2.0


def test_subtract():
    assert subtract(5, 3) == 2
