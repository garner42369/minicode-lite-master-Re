"""Day 28：PID 控制器的契约测试。"""

import pytest

from minicode.pid_controller import PID


class TestPID:
    def test_proportional_response(self):
        pid = PID(kp=1.0, ki=0.0, kd=0.0)
        out = pid.update(setpoint=0.7, measurement=0.5)
        assert out == pytest.approx(0.2)  # kp * (0.7 - 0.5) = 0.2
        print(f"\nP 响应: {out}")

    def test_output_clamped(self):
        pid = PID(kp=10.0, ki=0.0, kd=0.0, output_min=-1.0, output_max=1.0)
        out = pid.update(setpoint=0.7, measurement=0.0)  # kp*0.7=7 → clamp 到 1.0
        assert out == 1.0
        print(f"\n输出限幅: {out}")

    def test_anti_windup_freezes_integral(self):
        # 持续大误差导致输出饱和，积分应冻结（条件积分 anti-windup）
        pid = PID(kp=1.0, ki=1.0, kd=0.0, output_min=-1.0, output_max=1.0)
        for _ in range(10):
            pid.update(setpoint=1.0, measurement=0.0)  # 误差 1.0，输出一直饱和
        assert pid.integral == 0.0
        print(f"\nanti-windup 积分冻结: {pid.integral}")

    def test_reset(self):
        pid = PID(kp=1.0, ki=1.0, kd=1.0)
        pid.update(setpoint=0.7, measurement=0.5)
        pid.reset()
        assert pid.integral == 0.0 and pid.previous_error == 0.0
        print("\nreset 清零")

    def test_deterministic(self):
        p1 = PID(1.0, 0.1, 0.2)
        p2 = PID(1.0, 0.1, 0.2)
        outs1 = [p1.update(0.7, v) for v in [0.4, 0.6, 0.8]]
        outs2 = [p2.update(0.7, v) for v in [0.4, 0.6, 0.8]]
        assert outs1 == outs2
        print(f"\n确定性: {outs1}")
