import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from calculator import divide


def test_divide_normal():
    assert divide(6, 3) == 2.0


def test_divide_by_zero():
    assert divide(1, 0) is None
