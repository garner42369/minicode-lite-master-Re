# MiniCode Python 30 天测试导航

测试的作用不是告诉你“源码应该怎样写”，而是告诉你“外部行为必须怎样稳定”。复现时先阅读测试名和断言所表达的契约，再用自己的结构实现。

## 每日对照表

| Day | 参考测试 | 重点观察 | 建议复现命令 |
| --- | --- | --- | --- |
| 1 | 自建 fixture 测试 | 缺陷是否确定性复现 | `pytest fixtures/buggy_calculator -q` |
| 2 | `test_mock_model.py`、`test_agent_loop.py` 前几个协议测试 | AgentStep、Tool Call ID、消息角色 | `pytest tests/test_mock_model.py -q` |
| 3 | `test_config.py`、`test_logging_hardening.py`、`test_packaging.py` | 优先级、脱敏、入口可安装 | `pytest tests/test_config.py tests/test_packaging.py -q` |
| 4 | `test_mock_model.py` | 离线确定性和步骤耗尽 | `pytest tests/test_mock_model.py -q` |
| 5 | `test_tools.py`、`test_agent_loop.py::test_tool_registry_dispose_calls_disposer` | Registry 异常防火墙和清理 | `pytest tests/test_tools.py -q` |
| 6 | `test_tools.py`、`test_property_based.py` | 路径边界、读取/搜索、大输入性质 | `pytest tests/test_tools.py -q` |
| 7 | `test_agent_loop.py` | 模型—工具—模型闭环和回调 | `pytest tests/test_agent_loop.py -q` |
| 8 | `test_agent_intelligence.py`、`test_agent_stress.py` | 错误分类、并发、指标和稳定停止 | `pytest tests/test_agent_intelligence.py -q` |
| 9 | `test_prompt.py`、`test_product_surfaces.py` | 静态/动态 Prompt 与畸形输入 | `pytest tests/test_prompt.py -q` |
| 10 | `test_anthropic_adapter.py`、`test_openai_adapter.py`、`test_model_switching.py` | Provider 格式、usage、fallback | `pytest tests/test_anthropic_adapter.py tests/test_openai_adapter.py -q` |
| 11 | `test_permissions.py`、`test_auto_mode` 相关用例位于 `test_new_features.py` | allow/deny scope 与危险命令 | `pytest tests/test_permissions.py -q` |
| 12 | `test_tools.py`、`test_session.py` 的 checkpoint 用例 | 拒绝不落盘、写前快照、精确替换 | `pytest tests/test_tools.py -q` |
| 13 | `test_run_command_encoding.py`、`test_background_tasks.py`、`test_tools.py` | 编码、超时、后台进程、退出码 | `pytest tests/test_run_command_encoding.py tests/test_background_tasks.py -q` |
| 14 | `test_turn_kernel.py`、`test_verification_controller.py`、`test_agent_flow.py` | 阶段、widen、验证门槛 | `pytest tests/test_turn_kernel.py tests/test_verification_controller.py -q` |
| 15 | `test_session.py` | 全量/Delta、元数据、autosave | `pytest tests/test_session.py -q` |
| 16 | `test_session.py`、`test_cli_commands.py` | replay/inspect/rewind 行为 | `pytest tests/test_session.py tests/test_cli_commands.py -q` |
| 17 | `test_context_compactor.py`、`test_micro_compact.py` | Token、输出预算、读取去重 | `pytest tests/test_context_compactor.py tests/test_micro_compact.py -q` |
| 18 | `test_context_compactor.py`、`test_context_cybernetics.py`、`test_compaction_robustness.py` | 压缩保真、失败恢复、熔断 | `pytest tests/test_context_compactor.py tests/test_compaction_robustness.py -q` |
| 19 | `test_memory_e2e.py`、`test_memory_integration.py`、`test_domain_memory.py` | scope、搜索、跨会话和领域隔离 | `pytest tests/test_memory_e2e.py tests/test_domain_memory.py -q` |
| 20 | `test_memory_reranker.py`、`test_memory_curator.py`、`test_timeline_memory.py` | 高级记忆 fallback 与专用推理 | `pytest tests/test_memory_reranker.py tests/test_memory_curator.py -q` |
| 21 | `test_main.py`、`test_headless.py`、`test_cli_commands.py` | 入口共享 Runtime、无交互语义 | `pytest tests/test_main.py tests/test_headless.py -q` |
| 22 | `test_tui.py`、`test_tty_app.py`、`test_transcript_layout.py` | 输入字节、布局、工具生命周期、缓存 | `pytest tests/test_tui.py tests/test_transcript_layout.py -q` |
| 23 | `test_skills.py`、`test_hooks.py` | 发现优先级、按需加载、Hook 隔离 | `pytest tests/test_skills.py tests/test_hooks.py -q` |
| 24 | `test_mcp.py`、`fixtures/fake_mcp_server.py` | stdio 生命周期、工具/资源/Prompt | `pytest tests/test_mcp.py -q` |
| 25 | `test_product_surfaces.py`、`test_release_readiness.py` | 快照一致性与 degraded/blocked | `pytest tests/test_product_surfaces.py tests/test_release_readiness.py -q` |
| 26 | `test_background_tasks.py`、`test_tools.py` 的 task 用例、`test_cybernetics_concurrency.py` | 槽位、取消、只读子任务、冲突 | `pytest tests/test_background_tasks.py tests/test_cybernetics_concurrency.py -q` |
| 27 | `test_agent_intelligence.py`、`test_model_selection_controller.py`、`test_cost_control.py`、`test_progress_controller.py` | 信号、可解释决策、费用与验证 | `pytest tests/test_model_selection_controller.py tests/test_progress_controller.py -q` |
| 28 | `test_advanced_cybernetics.py`、`test_context_cybernetics.py`、`test_feedback_controller.py` | PID、预测、观测、限幅、稳定性 | `pytest tests/test_advanced_cybernetics.py -q` |
| 29 | `test_cybernetic_orchestrator.py`、`test_cybernetic_ablation.py`、`test_architecture_isolation.py` | 可选集成、自愈、消融和核心隔离 | `pytest tests/test_architecture_isolation.py tests/test_cybernetic_ablation.py -q` |
| 30 | `test_release_integration.py`、`test_packaging.py`、`test_runtime_profile_eval.py`、压力测试 | 干净安装、固定任务、报告和发布 | `pytest tests/test_packaging.py tests/test_release_integration.py -q` |

## 测试阅读法

每次只回答四件事：

1. 测试构造了什么前置状态？
2. 触发了哪个公共接口？
3. 它断言的是返回值、状态变化还是副作用没有发生？
4. 这个行为属于模块自身，还是跨模块整合？

例如“权限拒绝”至少要同时断言：返回为拒绝、文件不变、Runner 未调用、拒绝事件已记录。只断言错误文本包含 `denied` 并不能证明安全。

## 测试分层建议

```text
unit        纯函数、数据类、单模块状态机
integration 临时目录中的多个模块协作，无真实网络
e2e         从入口到工作区结果的完整任务
provider    真实外部模型，可跳过
property    路径、解析、状态转换的广泛输入性质
benchmark   算法规模和可选墙钟报告
```

当前参考仓库执行 `pytest --collect-only -q` 时可以发现 1164 个测试，同时因本地缺少 `hypothesis` 在 `test_property_based.py` 收集报错。复现项目应先修正依赖声明，再把“全量测试通过”作为发布证据；不能把“收集到了很多测试”当作通过。
