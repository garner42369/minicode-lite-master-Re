"""Day 24：MCP 客户端的契约测试。

用本地 fake MCP server（零依赖、无网络）覆盖：双协议（newline-json / content-length /
auto-detect）、工具发现与调用、资源与 Prompt、超时、进程退出、dispose 清理、
命名前缀隔离、项目级默认不信任。
"""

import json
from pathlib import Path

import pytest

from minicode.mcp import StdioMcpClient, create_mcp_backed_tools, load_mcp_servers

FAKE_SERVER = Path(__file__).resolve().parent / "fixtures" / "fake_mcp_server.py"


def _config(protocol: str | None = None, extra_args: list[str] | None = None) -> dict:
    cfg: dict = {
        "command": "python",
        "args": [str(FAKE_SERVER)] + (extra_args or []),
        "enabled": True,
    }
    if protocol:
        cfg["protocol"] = protocol
    return cfg


class TestStdioClient:
    def test_list_tools_and_call_echo(self, tmp_path):
        client = StdioMcpClient("fake", _config(protocol="newline-json"), str(tmp_path))
        try:
            tools = client.list_tools()
            assert [t["name"] for t in tools] == ["echo"]
            result = client.call_tool("echo", {"text": "hi"})
            assert result.ok
            assert "echo: hi" in result.output
            print(f"\ntools={[t['name'] for t in tools]}, echo={result.output!r}")
        finally:
            client.close()

    def test_content_length_protocol(self, tmp_path):
        client = StdioMcpClient("fake", _config(protocol="content-length"), str(tmp_path))
        try:
            assert [t["name"] for t in client.list_tools()] == ["echo"]
            result = client.call_tool("echo", {"text": "cl"})
            assert "echo: cl" in result.output
            print(f"\ncontent-length echo={result.output!r}")
        finally:
            client.close()

    def test_auto_detect_protocol(self, tmp_path):
        client = StdioMcpClient("fake", _config(), str(tmp_path))
        try:
            assert [t["name"] for t in client.list_tools()] == ["echo"]
            print(f"\nauto-detect 最终协议: {client.protocol}")
        finally:
            client.close()

    def test_resources_and_prompts(self, tmp_path):
        client = StdioMcpClient("fake", _config(protocol="newline-json"), str(tmp_path))
        try:
            resources = client.list_resources()
            assert resources[0]["uri"] == "file:///demo/readme"
            r = client.read_resource("file:///demo/readme")
            assert r.ok and "demo resource content" in r.output
            prompts = client.list_prompts()
            assert prompts[0]["name"] == "greet"
            p = client.get_prompt("greet", {"who": "minicode"})
            assert "hello minicode" in p.output
            print(f"\nresource={r.output!r}, prompt={p.output!r}")
        finally:
            client.close()

    def test_timeout_does_not_hang(self, tmp_path):
        # server 每个请求前 sleep 5s，客户端 initialize 超时(3s) → 明确失败而非永久挂起
        client = StdioMcpClient("fake", _config(protocol="newline-json", extra_args=["--delay", "5"]), str(tmp_path))
        try:
            with pytest.raises(RuntimeError) as exc:
                client.list_tools()
            assert "timed out" in str(exc.value)
            print(f"\n超时错误: {exc.value}")
        finally:
            client.close()

    def test_server_exit_fails_fast(self, tmp_path):
        # server 处理 1 个请求后退出；后续请求应快速失败，不永久挂起
        client = StdioMcpClient("fake", _config(protocol="newline-json", extra_args=["--exit-after", "1"]), str(tmp_path))
        try:
            with pytest.raises(RuntimeError):
                client.list_tools()
            print("\nserver 退出后请求快速失败（不永久挂起）")
        finally:
            client.close()

    def test_close_releases_process(self, tmp_path):
        client = StdioMcpClient("fake", _config(protocol="newline-json"), str(tmp_path))
        client.list_tools()  # 触发 spawn
        assert client.is_started
        client.close()
        assert client.process is None
        assert client.is_started is False
        print("\ndispose 后进程被清理")


class TestCreateBackedTools:
    def test_prefix_isolation_and_wrapping(self, tmp_path):
        result = create_mcp_backed_tools(cwd=str(tmp_path), mcp_servers={"demo": _config(protocol="newline-json")})
        try:
            names = [t.metadata.name for t in result["tools"]]
            assert "mcp__demo__echo" in names
            echo_tool = next(t for t in result["tools"] if t.metadata.name == "mcp__demo__echo")
            r = echo_tool.run({"text": "hi"}, None)
            assert r.ok and "echo: hi" in r.output
            assert result["servers"][0]["status"] == "connected"
            assert result["servers"][0]["toolCount"] == 1
            print(f"\nMCP 工具名: {names}")
            print(f"server 摘要: {result['servers']}")
        finally:
            result["dispose"]()

    def test_resource_and_prompt_gateway_tools(self, tmp_path):
        result = create_mcp_backed_tools(cwd=str(tmp_path), mcp_servers={"demo": _config(protocol="newline-json")})
        try:
            names = {t.metadata.name for t in result["tools"]}
            assert "list_mcp_resources" in names
            assert "read_mcp_resource" in names
            assert "list_mcp_prompts" in names
            assert "get_mcp_prompt" in names
            read = next(t for t in result["tools"] if t.metadata.name == "read_mcp_resource")
            r = read.run({"server": "demo", "uri": "file:///demo/readme"}, None)
            assert r.ok and "demo resource content" in r.output
            print(f"\n网关工具: {sorted(names)}")
        finally:
            result["dispose"]()


class TestLoadMcpServers:
    def test_default_not_trusted(self, tmp_path):
        (tmp_path / ".mcp.json").write_text(
            json.dumps({"mcpServers": {"demo": {"command": "python", "args": ["x.py"]}}}),
            encoding="utf-8",
        )
        servers = load_mcp_servers(tmp_path)
        assert servers["demo"]["enabled"] is False  # 项目级默认不信任
        print(f"\n默认不信任: {servers}")

    def test_explicit_enabled(self, tmp_path):
        (tmp_path / ".mcp.json").write_text(
            json.dumps({"mcpServers": {"demo": {"command": "python", "args": ["x.py"], "enabled": True}}}),
            encoding="utf-8",
        )
        servers = load_mcp_servers(tmp_path)
        assert servers["demo"]["enabled"] is True
        print(f"\n显式启用: {servers}")

    def test_missing_file_returns_empty(self, tmp_path):
        assert load_mcp_servers(tmp_path) == {}
        print("\n无 .mcp.json 返回空")
