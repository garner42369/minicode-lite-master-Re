"""minicode 的控制 Orchestrator（Day 29）。

把 Day 27/28 的控制器统一到一个「可关闭」的入口，agent_loop 在工具执行后调 after_tool。
简单规则 + 有界自愈 + 历史审计。裁剪参考项目 cybernetic_orchestrator 的 15 控制器
orchestration——我们只接「上下文压力 / 工具错误率 / 重复失败」三个信号，动作也只有三个。
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class Signals:
    context_ratio: float       # 上下文占用比 0-1
    tool_error_rate: float     # 工具错误率 0-1
    repeated_failures: int     # 同一工具连续失败次数


@dataclass(frozen=True, slots=True)
class ControlAction:
    name: str    # compact / reduce_concurrency / retry_idempotent_request
    reason: str


@dataclass(slots=True)
class ControlOrchestrator:
    """可关闭的控制编排器：简单规则 + 有界自愈 + 历史审计。"""

    enabled: bool = True
    max_healings: int = 2
    healing_count: int = 0
    history: list[ControlAction] = field(default_factory=list)

    def after_tool(self, signals: Signals) -> list[ControlAction]:
        """工具执行后根据信号决定动作。关闭时返回空（零副作用）。"""
        if not self.enabled:
            return []
        actions: list[ControlAction] = []
        if signals.context_ratio >= 0.90:
            actions.append(ControlAction("compact", "context pressure >= 90%"))
        if signals.tool_error_rate >= 0.5:
            actions.append(ControlAction("reduce_concurrency", "tool error rate >= 50%"))
        if signals.repeated_failures >= 2 and self.healing_count < self.max_healings:
            # 有界自愈：同一故障不无上限重复 healing（课件「动作白名单、次数和冷却」）
            actions.append(ControlAction("retry_idempotent_request", "bounded recovery"))
            self.healing_count += 1
        self.history.extend(actions)
        return actions

    def reset(self) -> None:
        self.healing_count = 0
        self.history.clear()
