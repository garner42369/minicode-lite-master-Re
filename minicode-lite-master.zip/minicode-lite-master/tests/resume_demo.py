"""Day 16 resume 副作用状态演示：结果未知的步骤需核实，不能自动重放。

运行（项目根目录）：
    python tests/resume_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.session import SideEffectStatus, needs_verification


def main():
    print("== 副作用步骤状态判断（resume 用）==")
    for status in SideEffectStatus:
        verify = needs_verification(status)
        print(f"  {status.value:10} -> 需要核实: {verify}")


if __name__ == "__main__":
    main()
