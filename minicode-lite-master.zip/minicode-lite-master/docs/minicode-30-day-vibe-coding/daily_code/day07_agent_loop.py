"""Day 7: 最小模型—工具—模型闭环。"""

from __future__ import annotations

from pathlib import Path

from day02_protocols import ChatMessage
from day04_scripted_model import ScriptedModel, demo_model
from day05_tool_registry import ToolContext, ToolRegistry
from day06_readonly_tools import LIST_FILES, READ_FILE


def run_agent_turn(
    model: ScriptedModel,
    tools: ToolRegistry,
    messages: list[ChatMessage],
    cwd: str,
    max_steps: int = 10,
) -> list[ChatMessage]:
    history = list(messages)
    context = ToolContext(cwd)
    for _ in range(max_steps):
        step = model.next(history)
        if step.type == "assistant":
            role = "assistant_progress" if step.kind == "progress" else "assistant"
            history.append({"role": role, "content": step.content})
            if step.kind != "progress":
                return history
            continue
        for call in step.calls:
            result = tools.execute(call.name, call.arguments, context)
            history.append({
                "role": "assistant_tool_call",
                "tool_call_id": call.id,
                "tool_name": call.name,
                "input": call.arguments,
            })
            history.append({
                "role": "tool_result",
                "tool_call_id": call.id,
                "tool_name": call.name,
                "content": result.output,
                "is_error": not result.ok,
            })
    history.append({"role": "assistant", "content": "Stopped: max_steps"})
    return history


if __name__ == "__main__":
    root = str(Path(__file__).parents[1])
    result = run_agent_turn(
        demo_model(),
        ToolRegistry([LIST_FILES, READ_FILE]),
        [{"role": "user", "content": "解释课件目录"}],
        root,
    )
    print(result[-1]["content"])
    assert result[-1]["role"] == "assistant"

