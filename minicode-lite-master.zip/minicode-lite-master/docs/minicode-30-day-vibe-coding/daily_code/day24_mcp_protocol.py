"""Day 24: 最小 JSON-RPC 编解码、请求关联和 MCP Tool 包装。

生产实现还需 stdio 进程、reader 线程、超时、消息大小和 close 生命周期。
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from day02_protocols import ToolResult


@dataclass(slots=True)
class JsonRpcSession:
    next_id: int = 1
    pending: dict[int, str] = field(default_factory=dict)

    def request(self, method: str, params: dict[str, Any]) -> tuple[int, str]:
        request_id = self.next_id
        self.next_id += 1
        self.pending[request_id] = method
        payload = {"jsonrpc": "2.0", "id": request_id, "method": method, "params": params}
        return request_id, json.dumps(payload, ensure_ascii=False)

    def accept(self, raw: str) -> tuple[str, Any]:
        message = json.loads(raw)
        request_id = int(message["id"])
        method = self.pending.pop(request_id)
        if "error" in message:
            raise RuntimeError(f"MCP {method} failed: {message['error']}")
        return method, message.get("result")


def mcp_tool_result(payload: dict[str, Any]) -> ToolResult:
    blocks = payload.get("content", [])
    text = "\n".join(str(block.get("text", "")) for block in blocks if block.get("type") == "text")
    return ToolResult(not payload.get("isError", False), text, None if not payload.get("isError") else "mcp_error")


if __name__ == "__main__":
    session = JsonRpcSession()
    request_id, payload = session.request("tools/list", {})
    assert json.loads(payload)["id"] == request_id
    method, result = session.accept(json.dumps({"jsonrpc": "2.0", "id": request_id, "result": {"tools": []}}))
    assert method == "tools/list" and result == {"tools": []}
    print("MCP protocol: OK")

