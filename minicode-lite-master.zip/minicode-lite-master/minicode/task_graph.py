"""minicode 的任务图与文件所有权（Day 26）。

任务图 = 逻辑任务的依赖 DAG（「分析 → 修改 → 验证」），不对应 OS 进程（那是
background_tasks），也不对应隔离 agent 循环（那是子 Agent）。它只表达「哪些任务、
依赖什么、谁在跑、进度多少」。

写任务隔离用「文件所有权」：写任务声明要写的文件，冲突则拒绝（课件「独立 worktree 或
明确文件所有权」二选一，选文件所有权，不引入 git worktree 依赖）。

裁剪说明：参考项目 task_graph.py 含 WorktreeIsolator（git worktree），这里用 FileOwnership
替代（用户拍板）。
"""

from __future__ import annotations

import json
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class TaskState(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


class TaskPriority(str, Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


_PRIORITY_ORDER = {TaskPriority.CRITICAL: 0, TaskPriority.HIGH: 1, TaskPriority.NORMAL: 2, TaskPriority.LOW: 3}


@dataclass
class TaskDefinition:
    """要做什么（任务定义，跨会话可持久化）。"""

    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = ""
    description: str = ""
    dependencies: list[str] = field(default_factory=list)
    priority: TaskPriority = TaskPriority.NORMAL
    timeout_seconds: int = 300
    created_at: float = field(default_factory=time.time)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TaskSlot:
    """谁在跑、进度多少（执行槽位，会话内状态）。"""

    task_id: str
    slot_name: str = "default"
    state: TaskState = TaskState.PENDING
    progress: float = 0.0
    started_at: float | None = None
    completed_at: float | None = None
    error: str | None = None
    result: str | None = None


@dataclass
class TaskGraph:
    """任务依赖 DAG + 执行槽位 + 并发上限。"""

    name: str = ""
    max_slots: int = 2
    definitions: dict[str, TaskDefinition] = field(default_factory=dict)
    slots: dict[str, TaskSlot] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    # --- 定义 ---
    def add_task(
        self,
        name: str,
        description: str = "",
        dependencies: list[str] | None = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        timeout_seconds: int = 300,
    ) -> TaskDefinition:
        task_def = TaskDefinition(name=name, description=description, dependencies=dependencies or [], priority=priority, timeout_seconds=timeout_seconds)
        self.definitions[task_def.id] = task_def
        self.updated_at = time.time()
        return task_def

    # --- 槽位 ---
    def assign_slot(self, task_id: str, slot_name: str = "default") -> TaskSlot:
        if task_id not in self.definitions:
            raise ValueError(f"Task {task_id} not found")
        slot = TaskSlot(task_id=task_id, slot_name=slot_name)
        self.slots[f"{slot_name}:{task_id}"] = slot
        self.updated_at = time.time()
        return slot

    def start_task(self, slot_key: str) -> TaskSlot:
        slot = self._require_slot(slot_key)
        slot.state = TaskState.RUNNING
        slot.started_at = time.time()
        self.updated_at = time.time()
        return slot

    def complete_task(self, slot_key: str, result: str = "") -> TaskSlot:
        slot = self._require_slot(slot_key)
        slot.state = TaskState.DONE
        slot.completed_at = time.time()
        slot.progress = 1.0
        slot.result = result
        self.updated_at = time.time()
        return slot

    def fail_task(self, slot_key: str, error: str) -> TaskSlot:
        slot = self._require_slot(slot_key)
        slot.state = TaskState.FAILED
        slot.completed_at = time.time()
        slot.error = error
        self.updated_at = time.time()
        return slot

    def _require_slot(self, slot_key: str) -> TaskSlot:
        slot = self.slots.get(slot_key)
        if slot is None:
            raise ValueError(f"Slot {slot_key} not found")
        return slot

    # --- 图逻辑 ---
    def get_ready_tasks(self) -> list[TaskDefinition]:
        """依赖全 DONE 且未 running 的任务，按优先级排序，受 slot 上限截断。"""
        done = {s.task_id for s in self.slots.values() if s.state is TaskState.DONE}
        running = {s.task_id for s in self.slots.values() if s.state is TaskState.RUNNING}
        available = max(0, self.max_slots - len(running))

        ready: list[TaskDefinition] = []
        for task_def in self.definitions.values():
            if task_def.id in done or task_def.id in running:
                continue
            if all(dep in done for dep in task_def.dependencies):
                ready.append(task_def)
        ready.sort(key=lambda t: _PRIORITY_ORDER.get(t.priority, 2))
        return ready[:available]

    def is_complete(self) -> bool:
        if not self.definitions:
            return True
        done = {s.task_id for s in self.slots.values() if s.state is TaskState.DONE}
        return all(tid in done for tid in self.definitions)

    def get_progress_percentage(self) -> float:
        if not self.definitions:
            return 0.0
        done = sum(1 for s in self.slots.values() if s.state is TaskState.DONE)
        return (done / len(self.definitions)) * 100

    # --- 持久化 ---
    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "max_slots": self.max_slots,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "definitions": {
                tid: {
                    "id": td.id, "name": td.name, "description": td.description,
                    "dependencies": td.dependencies, "priority": td.priority.value,
                    "timeout_seconds": td.timeout_seconds, "created_at": td.created_at, "metadata": td.metadata,
                }
                for tid, td in self.definitions.items()
            },
            "slots": {
                sk: {
                    "task_id": s.task_id, "slot_name": s.slot_name, "state": s.state.value,
                    "progress": s.progress, "started_at": s.started_at, "completed_at": s.completed_at,
                    "error": s.error, "result": s.result,
                }
                for sk, s in self.slots.items()
            },
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TaskGraph":
        graph = cls(
            name=data.get("name", ""),
            max_slots=data.get("max_slots", 2),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
        )
        for tid, td in data.get("definitions", {}).items():
            graph.definitions[tid] = TaskDefinition(
                id=td["id"], name=td["name"], description=td.get("description", ""),
                dependencies=td.get("dependencies", []), priority=TaskPriority(td.get("priority", "normal")),
                timeout_seconds=td.get("timeout_seconds", 300), created_at=td.get("created_at", time.time()),
                metadata=td.get("metadata", {}),
            )
        for sk, s in data.get("slots", {}).items():
            graph.slots[sk] = TaskSlot(
                task_id=s["task_id"], slot_name=s.get("slot_name", "default"),
                state=TaskState(s.get("state", "pending")), progress=s.get("progress", 0.0),
                started_at=s.get("started_at"), completed_at=s.get("completed_at"),
                error=s.get("error"), result=s.get("result"),
            )
        return graph


def save_task_graph(graph: TaskGraph, graph_id: str, directory: str | Path) -> Path:
    """保存任务图到磁盘。"""
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    graph_file = d / f"{graph_id}.json"
    graph_file.write_text(json.dumps(graph.to_dict(), indent=2, ensure_ascii=False), encoding="utf-8")
    return graph_file


def load_task_graph(graph_id: str, directory: str | Path) -> TaskGraph | None:
    graph_file = Path(directory) / f"{graph_id}.json"
    if not graph_file.exists():
        return None
    try:
        return TaskGraph.from_dict(json.loads(graph_file.read_text(encoding="utf-8")))
    except (json.JSONDecodeError, KeyError):
        return None


def list_task_graphs(directory: str | Path) -> list[str]:
    d = Path(directory)
    if not d.exists():
        return []
    return [f.stem for f in d.glob("*.json")]


class FileOwnership:
    """文件所有权注册表：写任务声明要写的文件，冲突则拒绝（写隔离）。"""

    def __init__(self) -> None:
        self._owners: dict[str, str] = {}  # file_path -> task_id

    def claim(self, task_id: str, files: list[str]) -> list[str]:
        """声明文件所有权，返回冲突的文件列表（空 = 无冲突且声明成功）。"""
        conflicts = [f for f in files if f in self._owners and self._owners[f] != task_id]
        if not conflicts:
            for f in files:
                self._owners[f] = task_id
        return conflicts

    def release(self, task_id: str) -> None:
        for f in [f for f, owner in self._owners.items() if owner == task_id]:
            del self._owners[f]

    def owner_of(self, path: str) -> str | None:
        return self._owners.get(path)
