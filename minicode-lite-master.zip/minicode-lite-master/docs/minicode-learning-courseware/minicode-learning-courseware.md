# MiniCode 本地 AI Coding Agent 学习课件



# 1.1 项目图谱：MiniCode 到底是什么

## 学习目标
- 理解 MiniCode 的项目定位。
- 区分“模型 API 包装器”“RAG 系统”和“Agent Runtime”。
- 建立后续读源码的全局地图。

## 项目一句话
MiniCode 是一个面向真实代码仓库的本地 AI Coding Agent Runtime。它接收用户自然语言任务，调用模型进行推理，再通过受控工具读取代码、修改文件、执行命令、运行测试、保存会话，并在长任务中处理上下文、记忆、权限和恢复问题。

如果 EduRAG 的主问题是“如何让大模型回答知识库问题”，MiniCode 的主问题是“如何让大模型在真实开发环境里安全、连续、可恢复地干活”。

## 三条主线
| 主线 | 要回答的问题 | 关键源码 |
| --- | --- | --- |
| 运行链路 | 用户输入一句开发任务后，Agent 如何推理、调用工具并完成任务？ | `minicode/main.py`, `minicode/headless.py`, `minicode/agent_loop.py`, `minicode/turn_kernel.py` |
| 治理链路 | Agent 如何避免乱改文件、乱执行命令、上下文爆炸和任务丢失？ | `permissions.py`, `file_review.py`, `context_compactor.py`, `memory.py`, `session.py` |
| 评估链路 | 如何知道 Agent 稳不稳定、是否完成、失败在哪里？ | `runtime_profile_eval.py`, `cybernetic_ablation.py`, `release_readiness.py`, `benchmarks/` |

## 总体架构图
```text
用户输入 / CLI / TUI / Headless
        |
        v
配置加载 + Prompt 构建 + 模型适配 + 工具注册 + 权限初始化
        |
        v
Agent 主循环 run_agent_turn
        |
        +--> 模型推理: Anthropic / OpenAI-compatible / OpenRouter / Custom / Mock
        +--> 工具调用: read, grep, write, patch, command, git, test, MCP, task
        +--> 安全治理: path permission, command guard, edit diff, checkpoint
        +--> 上下文治理: token estimate, tool budget, dedup, compact, recover
        +--> 记忆治理: user/project/local memory, retrieval, injection, reflection
        +--> 会话治理: transcript, session delta, checkpoint, replay, rewind
        |
        v
最终回复 + 文件结果 + 运行事件 + 会话持久化
```

## 和 RAG 项目的差异
| 对比项 | EduRAG | MiniCode |
| --- | --- | --- |
| 输入 | 用户问题 | 开发任务或代码操作请求 |
| 核心链路 | 检索增强生成 | Agent 推理 + 工具执行 |
| 数据对象 | FAQ、文档块、向量库 | 代码文件、终端命令、会话状态、工具结果 |
| 主要难点 | 召回质量、答案相关性 | 安全执行、长上下文、任务恢复、工具可靠性 |
| 质量评估 | RAGAS、日志、压测 | Runtime Eval、Ablation、Release Readiness、测试 |

## 代码规模观察
当前活跃包是 `minicode/`，不是 `ts-src/`。仓库里还有 `docs/`、`openspec/`、`benchmarks/`、`tests/` 等辅助资料。`pyproject.toml` 显示项目运行时依赖非常少，说明它没有用 LangChain / LlamaIndex 这类 Agent 框架，而是自己实现了核心 Runtime。

## 本章小结
MiniCode 的学习重点不是“会调用一个大模型 API”，而是理解一个 Agent 工程系统如何把模型、工具、权限、记忆、上下文、会话和评估组织起来。



# 1.2 源码阅读路线：先主链路再子系统

## 学习目标
- 知道哪些文件必须先看。
- 知道哪些模块属于核心路径，哪些属于扩展和治理。
- 形成适合面试复盘的源码阅读顺序。

## 推荐阅读顺序
1. 入口层：`main.py`、`headless.py`
2. 抽象协议：`types.py`、`tooling.py`
3. 主循环：`agent_loop.py`、`turn_kernel.py`
4. 工具系统：`tools/__init__.py`、`read_file.py`、`write_file.py`、`edit_file.py`、`run_command.py`
5. 安全系统：`permissions.py`、`workspace.py`、`file_review.py`
6. 模型适配：`model_registry.py`、`anthropic_adapter.py`、`openai_adapter.py`
7. 上下文和记忆：`context_manager.py`、`context_compactor.py`, `memory.py`, `memory_pipeline.py`
8. 会话恢复：`session.py`、`cli_commands.py`
9. 扩展能力：`mcp.py`、`skills.py`、`hooks.py`、`tools/task.py`
10. 评估与工程化：`runtime_profile_eval.py`、`cybernetic_ablation.py`、`release_readiness.py`、`benchmarks/`

## 为什么这样读
MiniCode 模块很多，如果直接从 `memory.py` 或 `context_compactor.py` 开始读，很容易记住一堆类名但不知道它们什么时候被调用。更好的方式是从一次用户请求出发，沿着运行路径往下看：

```text
main/headless
  -> load_runtime_config
  -> create_default_tool_registry
  -> create_model_adapter
  -> build_system_prompt_bundle
  -> run_agent_turn
  -> model.next / tools.execute
  -> session save / checkpoint / memory reflection
```

## 核心文件优先级
| 优先级 | 文件 | 读什么 |
| --- | --- | --- |
| P0 | `agent_loop.py` | Agent turn 如何执行，模型和工具如何交替 |
| P0 | `turn_kernel.py` | 阶段、策略、停止原因、验证逻辑 |
| P0 | `tooling.py` | Tool Registry 和 ToolResult 协议 |
| P0 | `permissions.py` | 路径、命令、编辑权限如何拦截 |
| P1 | `context_compactor.py` | 长上下文如何治理 |
| P1 | `memory_pipeline.py` | 记忆如何读取、注入、写入和维护 |
| P1 | `session.py` | checkpoint、rewind、replay 如何实现 |
| P2 | `mcp.py`, `hooks.py`, `skills.py` | 扩展生态和外围能力 |

## 阅读时抓住的四个问题
- Agent 每一步为什么继续、停止或验证？
- 模型什么时候只是“建议”，什么时候能真正改文件？
- 上下文爆了怎么办，哪些内容能删，哪些必须保护？
- 任务中断后，系统靠什么恢复到可继续状态？

## 本章小结
MiniCode 要按“入口 -> 主循环 -> 工具/权限 -> 记忆/上下文 -> 会话/评估”的路线读。这样你看到每个模块时，都知道它在 Agent 运行链路里的位置。



# 2.1 环境、依赖与运行形态

## 学习目标
- 看懂 `pyproject.toml` 中暴露出来的工程定位。
- 理解 MiniCode 没有依赖 LangChain，而是自研 Agent Runtime。
- 知道项目有哪些运行形态：交互式、非交互、容器、CI。

## 依赖特征
`pyproject.toml` 中最关键的信息是：

```toml
requires-python = ">=3.11"
dependencies = []

[project.optional-dependencies]
dev = ["pytest>=8.0.0"]

[project.scripts]
minicode-py = "minicode.main:main"
minicode-headless = "minicode.headless:main"
```

这说明 MiniCode 的主路径没有使用 LangChain、LlamaIndex、CrewAI、AutoGen 这类现成 Agent 框架。模型 API、工具协议、会话、权限、上下文、记忆等能力基本都在项目内部实现。

## 技术栈不是堆名词
MiniCode 涉及的技术栈可以按功能理解：

| 能力 | 实现方式 |
| --- | --- |
| Agent Runtime | Python dataclass / TypedDict / Protocol 建模消息、步骤、工具调用和运行事件 |
| 模型 API | `urllib.request` 直接请求 Anthropic Messages API 和 OpenAI-compatible Chat Completions |
| 工具调用 | 自定义 `ToolDefinition`, `ToolRegistry`, `ToolContext`, `ToolResult` |
| 本地文件操作 | `pathlib`, `difflib`, 原子写入、checkpoint |
| 命令执行 | `subprocess`, 后台任务注册、危险命令检测、输出截断 |
| 会话存储 | JSON session store, delta save, transcript, checkpoints |
| 记忆系统 | JSON / Markdown 本地存储、BM25 检索、标签分类、反思写入 |
| 上下文压缩 | token 估算、工具结果预算、读文件去重、micro compact、auto compact、reactive compact |
| 扩展协议 | MCP stdio JSON-RPC、hooks、skills |
| 质量保障 | pytest、benchmark scripts、release readiness、GitHub Actions、Docker |

## 运行形态
| 形态 | 入口 | 适用场景 |
| --- | --- | --- |
| 交互式 CLI/TUI | `minicode.main:main` | 日常本地 coding agent 使用 |
| Headless | `minicode.headless:main` | CI、脚本、一问一答式自动任务 |
| Docker CLI | `Dockerfile`, `docker-compose.yml` | 隔离环境运行 |
| Benchmark/Eval | `benchmarks/*.py` | 性能、稳定性、策略对比 |

## CI 的含义
`.github/workflows/ci.yml` 覆盖 Python 3.11/3.12 和 Ubuntu/Windows/macOS，执行：

- 安装 `.[dev]`
- `compileall` 编译源码和测试
- ruff 检查 `E,F`
- mypy baseline 检查
- packaging smoke tests
- pytest 全量测试

它说明项目不是只追求能跑，而是有跨平台和回归验证意识。

## 注意一个现实问题
当前仓库 `pyproject.toml` 的 dev 依赖只声明了 pytest，但测试里有 property-based test 需要 `hypothesis`。如果本地没有安装 `hypothesis`，pytest 收集会中断。这属于依赖声明和测试集合之间的小缺口，学习时要能区分“架构能力”和“工程打磨问题”。

## 本章小结
MiniCode 是一个低依赖、自研主链路的 Python Agent Runtime。它的技术栈要从“每个工程问题如何解决”来理解，而不是简单列框架名。



# 2.2 入口层：CLI 与 Headless

## 学习目标
- 理解 `main.py` 和 `headless.py` 的职责区别。
- 看懂启动时如何装配配置、模型、工具、权限和 prompt。
- 明白入口层不负责智能决策，只负责组装运行环境。

## 两个主入口
| 文件 | 作用 | 特点 |
| --- | --- | --- |
| `minicode/main.py` | 主 CLI/TUI 入口 | 支持交互、session、rewind、inspect、local commands |
| `minicode/headless.py` | 非交互入口 | 从参数或 stdin 读取 prompt，适合脚本和 CI |

## main.py 的核心流程
`main.py` 的职责可以概括为“启动一个完整 Agent 工作台”：

```text
解析命令行参数
  -> 处理 session/list/inspect/replay/rewind 等管理命令
  -> load_runtime_config 加载模型和项目配置
  -> create_default_tool_registry 注册工具、skills、MCP
  -> PermissionManager 初始化权限
  -> create_model_adapter 创建模型适配器
  -> ContextManager 初始化上下文管理
  -> MemoryManager / UserProfileManager 初始化个性化上下文
  -> build_system_prompt_bundle 构造系统提示词
  -> TTY 模式进入 run_tty_app
  -> 非 TTY 模式逐行读取 stdin 并调用 run_agent_turn
```

这里值得注意：入口层并不直接实现 Agent 智能，只负责把所需组件装配起来。真正的“想、做、验证”发生在 `run_agent_turn`。

## headless.py 的核心流程
Headless 模式更像“一次性 Agent 执行器”：

```text
读取 prompt
  -> 可选开启 allow edits
  -> 装配 runtime / tools / permissions / memory / model / prompt
  -> 调用 run_agent_turn
  -> 输出最后一条 assistant message
  -> 可选写出 messages trace JSON
```

它适合自动化场景，例如：

- CI 中让 Agent 检查某个文件
- 脚本里让 Agent 执行一次固定任务
- benchmark 中构造可重复的 Agent turn

## 入口层的设计思想
入口层要解决的是“运行方式差异”，不是“推理逻辑差异”。交互式和 headless 的输入输出不同，但它们最终都收敛到同一个核心：

```text
run_agent_turn(model, tools, messages, cwd, permissions, session, runtime, ...)
```

这保证了 CLI、TUI、测试、评估可以复用同一套 Agent Runtime。

## 学习时看什么
- 看 `argparse` 支持哪些产品功能：session、rewind、config、logging。
- 看配置失败时如何 fallback 到 mock model。
- 看 non-TTY 和 TTY 的分支差异。
- 看哪些对象被传入 `run_agent_turn`，这些就是主循环依赖的核心组件。

## 本章小结
MiniCode 的入口层像一个装配器：它把配置、模型、工具、权限、上下文、记忆和会话拼成一个可运行环境，然后交给 Agent 主循环执行。



# 3.1 Agent 主循环：从想法到工具执行

## 学习目标
- 理解 Agent Loop 和普通 Chat Completion 的区别。
- 看懂 `run_agent_turn` 为什么是项目核心。
- 掌握 explore / execute / verify 阶段化设计。

## 普通 LLM 调用 vs Agent Loop
普通 LLM 调用通常是：

```text
用户问题 -> 模型 -> 文本回答
```

Agent Loop 是：

```text
用户任务
  -> 模型判断下一步
  -> 调用工具读取/修改/执行
  -> 工具结果回填给模型
  -> 模型继续判断
  -> 验证是否完成
  -> 输出最终回复
```

也就是说，Agent Loop 的关键不是“模型回答”，而是“模型和工具交替工作”。

## MiniCode 的主循环入口
`minicode/agent_loop.py` 中的 `run_agent_turn` 接收大量依赖：

```python
def run_agent_turn(
    *,
    model,
    tools,
    messages,
    cwd,
    permissions=None,
    session=None,
    store=None,
    max_steps=50,
    context_manager=None,
    runtime=None,
    system_prompt="",
    project_context="",
    enable_work_chain=True,
)
```

这些参数反映了 Agent Runtime 的边界：

- `model`：负责推理和产生工具调用
- `tools`：负责真实执行动作
- `messages`：保存上下文
- `cwd`：限定工作区
- `permissions`：控制危险操作
- `session`：保存可恢复状态
- `context_manager`：管理上下文窗口
- `runtime`：控制 profile、模型和策略

## 阶段化执行
`turn_kernel.py` 把一次任务拆成阶段和策略：

| 阶段 | 目标 | 典型动作 |
| --- | --- | --- |
| explore | 理解需求和仓库 | list、grep、read、code_nav |
| execute | 修改代码或执行任务 | write、edit、patch、run_command |
| verify | 验证结果 | test_runner、git diff、read back |

这种阶段化能缓解两个问题：

- 模型一上来就乱改文件。
- 模型改完后不验证就宣布完成。

## 停止原因
MiniCode 不只是“循环到没工具调用就结束”，而是显式记录停止原因：

- `done`：正常完成
- `max_steps`：超过最大步数
- `await_user`：需要用户确认
- `blocked`：无法继续
- `verification_failed`：验证失败
- `widen_needed`：需要扩大上下文或策略

这就是 Agent 工程里很重要的“可观测性”：失败不是一个模糊的失败，而是可以归因的状态。

## 工具调用调度
Agent Loop 里会区分工具调用类型：

- 单个工具：直接执行。
- 多个工具：读类工具可以并发，写类/命令类工具串行执行。

依据来自工具 metadata：`READ_ONLY`、`DESTRUCTIVE`、`CONCURRENCY_SAFE`、`REQUIRES_PERMISSION`。这比简单地把所有 tool call 串行跑更有效，也比盲目并发更安全。

## 错误处理
主循环会处理多类异常：

- 模型连接错误、超时、API 错误。
- prompt-too-long 触发 reactive compact。
- provider 不可用时尝试 model switch。
- 工具失败时把错误作为 tool result 回填，让模型继续修复。

这说明 MiniCode 把 Agent 当成一个长期运行系统，而不是一次性 API 请求。

## 本章小结
`run_agent_turn` 是 MiniCode 的心脏。它负责把模型推理、工具执行、权限、上下文、记忆、会话、评估事件串成一个完整闭环。读懂它，就读懂了 MiniCode 的主体。



# 3.2 Tool Calling：工具注册、执行与截断

## 学习目标
- 理解 MiniCode 的工具抽象。
- 知道模型如何通过工具操作真实代码仓库。
- 看懂工具执行安全网和输出截断策略。

## 工具系统的核心类
`minicode/tooling.py` 定义了工具协议：

| 类型 | 作用 |
| --- | --- |
| `ToolDefinition` | 描述一个工具：名称、说明、输入 schema、validator、run 函数、metadata |
| `ToolMetadata` | 标注工具能力：只读、破坏性、可并发、需要权限 |
| `ToolContext` | 工具运行上下文：cwd、permissions、session、runtime |
| `ToolResult` | 工具执行结果：ok、output、backgroundTask、awaitUser |
| `ToolRegistry` | 工具注册表，负责查找、校验、执行和异常兜底 |

## 核心工具集合
`minicode/tools/__init__.py` 中 `_CORE_TOOLS` 注册了主工具面：

- 用户交互：`ask_user`
- 文件操作：`list_files`, `grep_files`, `read_file`, `write_file`, `edit_file`, `patch_file`
- 批量操作：`batch_copy`, `batch_move`, `batch_delete`
- 命令执行：`run_command`
- Web：`web_fetch`, `web_search`
- 任务管理：`todo_write`
- 子代理：`task`
- Git：`git`
- 代码智能：`find_symbols`, `find_references`, `get_ast_info`, `code_review`
- 可视化/差异：`file_tree`, `diff_viewer`
- 测试：`test_runner`

还有 utility profile，会延迟加载压缩包、hash、json、regex、csv、http、编码等工具。默认不全量暴露，是为了减少工具面和 prompt 成本。

## 工具执行流程
`ToolRegistry.execute` 的流程：

```text
find tool
  -> validator 解析和校验输入
  -> run(parsed, context)
  -> 输出为空则归一化
  -> 大输出智能截断
  -> 记录工具日志
  -> 出错时返回 ToolResult(ok=False)
```

这里最重要的设计是：工具内部异常不会直接击穿 Agent 主循环，而是被包装成失败的 tool result。这样模型还能看到错误并尝试修复。

## 大输出治理
工具输出是 Agent 最容易污染上下文的来源。MiniCode 为不同工具配置了输出上限：

| 工具 | 默认上限 |
| --- | --- |
| `read_file` | 40,000 chars |
| `grep_files` | 20,000 chars |
| `run_command` | 30,000 chars |
| `web_fetch` | 20,000 chars |
| `test_runner` | 25,000 chars |

截断策略不是简单砍头：

- 读文件保留头部和尾部，便于理解结构。
- 命令输出保留头部、尾部和错误/警告行。
- 搜索结果保留前 N 条和总量摘要。

## 为什么 Tool Calling 是核心技术栈
Coding Agent 的能力上限很大程度取决于工具系统。模型本身不能读取本地文件，也不能执行测试；它必须通过工具和真实环境连接。MiniCode 的工具系统做了三件关键事：

- 给模型提供可调用能力。
- 给工具执行加上校验、权限和错误兜底。
- 给上下文窗口控制工具结果大小。

## 本章小结
MiniCode 的 Tool Calling 不是简单函数映射，而是一套包含元信息、权限、安全网、并发策略和输出治理的本地工具运行系统。



# 3.3 权限与安全：让 Agent 可控地操作本地环境

## 学习目标
- 理解为什么 Coding Agent 必须有权限层。
- 看懂路径、命令、文件编辑三类安全检查。
- 理解 checkpoint 和 rewind 对安全性的意义。

## 为什么需要权限系统
RAG 系统最坏可能是答错，而 Coding Agent 最坏可能是：

- 删除文件。
- 覆盖用户未提交代码。
- 执行危险命令。
- 把工作区外的文件读走或改掉。
- 强制推送、重置 Git 历史。

因此 MiniCode 不能只信任模型输出，必须把模型能力限制在工程边界内。

## 权限系统的三条线
| 安全对象 | 实现位置 | 处理方式 |
| --- | --- | --- |
| 路径访问 | `permissions.py`, `workspace.py` | 默认允许 cwd 内路径，cwd 外需要审批或拒绝 |
| 命令执行 | `permissions.py`, `run_command.py` | 检测危险命令、shell 片段、破坏性操作 |
| 文件修改 | `permissions.py`, `file_review.py` | 写入前 diff 预览、权限确认、checkpoint |

## 路径权限
`PermissionManager.ensure_path_access` 会先把路径 normalize，再判断目标是否位于 workspace root 下。

```text
目标路径
  -> Path.resolve 规范化
  -> 判断是否在 workspace root 内
  -> 检查 session/global allow/deny
  -> auto mode 风险评估
  -> TTY 下请求用户审批
  -> 非 TTY 下默认拒绝需要审批的 cwd 外访问
```

这能阻止 Agent 在用户没意识到的情况下读写工作区外文件。

## 危险命令识别
`_classify_dangerous_command` 会识别：

- `git reset --hard`
- `git clean`
- `git checkout --`
- `git push --force`
- `rm -rf`
- `dd`, `mkfs`, `fdisk`, `format`
- `chmod 777`
- `bash`, `sh`, `powershell`, `python`, `node` 等任意代码执行入口

注意：不是所有命令都禁止，而是高风险命令进入审批链路。

## 文件编辑审查
文件写入统一走 `apply_reviewed_file_change`：

```text
读取旧文件
  -> 生成 unified diff
  -> permissions.ensure_edit
  -> create_file_checkpoint
  -> 写入新内容
```

这条链路很重要，因为它把“模型想改文件”变成“可审查、可恢复的文件变更”。

## checkpoint 与 rewind
`session.py` 中 `create_file_checkpoint` 会在文件修改前记录：

- checkpoint id
- 创建时间
- 文件路径
- 文件是否存在
- 修改前内容

如果后续发现改错，可以用 rewind 恢复。`rewind_session_data` 在恢复前还会创建 reverse checkpoint，使得“撤销 rewind”也有安全记录。

## 本章小结
MiniCode 的安全设计不是单点规则，而是路径边界、命令风险、diff 审查、checkpoint、rewind 组合起来的多层保护。它的核心思想是：模型可以提出动作，但动作落地必须经过工程安全边界。



# 3.4 模型适配：Anthropic-first 但不是 Anthropic-only

## 学习目标
- 澄清 MiniCode 的模型调用方式。
- 理解 `ModelAdapter` 为什么重要。
- 看懂 Anthropic 和 OpenAI-compatible 两条 API 链路。

## 不是 LangChain，也不是只支持 Anthropic
MiniCode 没有使用 LangChain 等框架，模型层也不是只写死 Anthropic。更准确地说：

> MiniCode 是 Anthropic-first / Claude-first，但通过统一 `ModelAdapter` 抽象兼容 OpenAI、OpenRouter 和自定义 OpenAI-compatible 服务。

## 内部模型协议
`types.py` 定义了 `ModelAdapter`：

```python
class ModelAdapter(Protocol):
    def next(
        self,
        messages,
        on_stream_chunk=None,
        store=None,
    ) -> AgentStep:
        ...
```

主循环只关心 `model.next()` 返回一个 `AgentStep`，不关心背后是 Anthropic、OpenAI 还是 Mock。这样上层 Agent Loop 和具体 provider 解耦。

## create_model_adapter 分发逻辑
`model_registry.py` 中 `create_model_adapter` 根据 provider 创建适配器：

```text
force_mock or MINI_CODE_MODEL_MODE=mock
  -> MockModelAdapter

OpenAI / OpenRouter / Custom
  -> OpenAIModelAdapter

Anthropic
  -> AnthropicModelAdapter
```

OpenRouter 和 Custom 走 OpenAI-compatible 格式，因为它们通常兼容 Chat Completions。

## Anthropic Adapter
`anthropic_adapter.py` 直接用 `urllib.request` 调用 Anthropic Messages API，处理：

- system prompt 与 messages 转换。
- tool use / tool result content block。
- streaming chunk。
- thinking block。
- `<final>`、`[FINAL]`、`<progress>`、`[PROGRESS]` 等输出约定。
- Retry-After、rate limit、server error 重试。
- token/cost/context 统计。

## OpenAI-compatible Adapter
`openai_adapter.py` 处理：

- OpenAI Chat Completions 消息格式。
- tool_calls/function arguments JSON。
- OpenRouter headers：`HTTP-Referer`, `X-Title`。
- 自定义 base URL。
- streaming 和 non-streaming response。
- 非 JSON 成功响应的错误提示。

## 模型切换和 fallback
`model_switcher.py` 负责 provider 失败后的 fallback。它会考虑：

- 当前 provider。
- runtime 中配置的 fallback models。
- 同 provider 下可用模型。
- 自定义 OpenAI-compatible host 的边界，避免随意切到不可用模型族。

## 技术栈角度怎么讲
这一章的技术栈不是“Anthropic API”四个字，而是：

- 自定义模型协议抽象。
- Provider 检测和模型注册。
- HTTP API 直接封装。
- Tool call 格式转换。
- Streaming 解析。
- 错误分类、重试和 fallback。

## 本章小结
MiniCode 的模型层有明确抽象边界：Agent Loop 不直接依赖 provider，provider 差异都被 adapter 吞掉。这是它能支持多模型、mock 测试和 runtime eval 的基础。



# 3.5 Prompt 与产品面：系统提示词不是一段字符串

## 学习目标
- 理解 MiniCode 的 prompt 不是硬编码单文本。
- 看懂静态 prompt、动态上下文和产品状态如何组合。
- 理解 prompt cache 边界的设计。

## Prompt 的组成
MiniCode 的系统提示词由 `prompt.py` 和 `prompt_pipeline.py` 构造，最终形成 `PromptBundle`。

它大体分为：

- 静态角色和工程规则。
- 权限摘要。
- skills 列表。
- MCP servers 状态。
- memory context。
- instruction layers。
- hooks / delegation / extensions。
- readiness report。
- user profile 和 project context。

## PromptPipeline 的意义
`PromptPipeline` 把静态区和动态区分开：

```text
Static prompt sections
  -> 角色、行为规范、工程约束

Dynamic prompt sections
  -> skills、MCP、memory、session、readiness、项目指令
```

这样做的好处是：

- 静态内容可以稳定复用。
- 动态内容每 turn 刷新。
- 有利于 provider 的 prompt caching。
- 便于定位某块上下文从哪里来。

## Product Surfaces
`product_surfaces.py` 不是业务页面，而是“Agent 产品状态”的结构化表达，例如：

- instruction layers：全局/项目级指令。
- extension manifest：扩展包元信息。
- hook status：hook 是否启用。
- delegation status：后台任务/子代理状态。
- readiness report：当前 runtime 是否准备好。
- prompt bundle：最终系统提示词和快照。

这说明 MiniCode 把 prompt 当成“运行时状态的投影”，而不是单纯提示词工程。

## 为什么这很重要
Coding Agent 的 prompt 里必须告诉模型：

- 你有哪些工具。
- 你当前有哪些权限。
- 当前项目有什么约束。
- 哪些记忆和用户偏好需要遵守。
- 当前 runtime 是否存在 provider 或 fallback 风险。

如果这些信息散落在代码里，模型就无法稳定执行。MiniCode 通过 PromptBundle 把这些状态组织进系统提示词。

## 本章小结
MiniCode 的 Prompt 系统体现的是 Agent Runtime 思维：prompt 不是固定模板，而是由工具、权限、记忆、扩展、配置和产品状态共同生成的动态运行上下文。



# 4.1 上下文治理：长任务为什么不会轻易爆掉

## 学习目标
- 理解 Coding Agent 为什么特别容易上下文爆炸。
- 掌握 MiniCode 的上下文压缩链路。
- 区分 Micro Compact、Auto Compact 和 Reactive Compact。

## 上下文爆炸来自哪里
Coding Agent 的上下文增长速度比普通聊天快得多，因为它会不断产生：

- 用户需求和澄清。
- 模型推理过程。
- 文件读取结果。
- grep 搜索结果。
- 命令和测试输出。
- Git diff。
- 工具错误堆栈。
- 中间计划和验证记录。

如果全部塞进 messages，很快超过模型窗口。

## ContextManager
`context_manager.py` 负责基础上下文管理：

- 模型 context window 识别。
- token 估算。
- CJK 友好的 token 估算。
- context stats 统计。
- 多级摘要压缩。
- 老消息摘要和保留近期关键消息。

它回答的是：“当前上下文用了多少，还能不能继续？”

## ContextCompactor
`context_compactor.py` 是更接近 Claude Code 风格的压缩编排器。`ContextCompactor.process_request` 的流程：

```text
messages
  -> Tool Result Budget: 大工具结果外置化/替换
  -> Read Dedup: 处理重复读文件结果
  -> Microcompact: 清理陈旧可压缩内容
  -> Auto Compact: 高水位触发 session/full compact
  -> Reactive Recover: API 报 prompt-too-long 后兜底恢复
```

## Tool Result Budget
工具结果可能非常大，例如读大文件、跑测试、搜索仓库。MiniCode 会把过大的工具结果持久化到本地，再在上下文中保留摘要或引用，减少 prompt 压力。

这个思想和 RAG 中“文档块不全部塞进 prompt，只塞相关片段”有点像，但对象从知识库文档变成了 Agent 工具结果。

## Read Dedup
如果 Agent 多次读取同一个文件，重复内容会浪费大量上下文。Read Dedup 的目标是识别重复读文件结果，减少重复传输，同时保留必要的引用信息。

## Micro Compact / Auto Compact / Reactive Compact
| 类型 | 触发时机 | 解决问题 |
| --- | --- | --- |
| Micro Compact | 平时、轻量、时间或预算驱动 | 清理陈旧工具结果，低成本释放空间 |
| Auto Compact | 上下文接近阈值 | 主动压缩历史消息，避免请求失败 |
| Reactive Compact | API 已经报超限 | 紧急截断/压缩，恢复请求能力 |

## 难点：压缩不能丢任务状态
长上下文治理最难的是：不能为了省 token 把任务目标、文件变更、用户约束、验证结果压没。MiniCode 通过 working memory、stable task pack、session memory compact 等方式保护关键状态。

## 本章小结
MiniCode 的上下文治理不是“超过就摘要一下”，而是一条分层 pipeline：先预算和去重，再轻量压缩，再主动 compact，最后 reactive recover。它体现了把上下文当成有限资源治理的思路。



# 4.2 记忆系统：从临时上下文到可复用经验

## 学习目标
- 理解 MiniCode 中 memory 和普通聊天历史的区别。
- 看懂 user / project / local 三层记忆。
- 掌握 MemoryPipeline 的 read / inject / write / feedback / maintain。

## 为什么 Coding Agent 需要记忆
如果 Agent 每次都从零开始，它会反复踩同样的坑：

- 不知道用户偏好的代码风格。
- 不记得项目里的约定。
- 不记得之前修过的 bug。
- 不知道哪些命令在这个项目里可用。
- 不知道哪些模块曾经被验证过。

记忆系统的目标是把这些经验从“当前对话上下文”沉淀为“跨会话可复用资产”。

## 三层记忆
`memory.py` 中把记忆分成三类：

| Scope | 含义 | 例子 |
| --- | --- | --- |
| user | 用户级，跨项目共享 | 用户偏好中文回答、测试前先看现有模式 |
| project | 项目级，当前仓库共享 | MiniCode 的核心入口是 `agent_loop.py` |
| local | 本地私有，不适合提交 | 本机路径、私有配置、临时环境差异 |

存储形式是本地 JSON / Markdown，既便于程序检索，也便于人读。

## MemoryManager
`MemoryManager` 负责：

- 加载和保存记忆文件。
- 添加、删除、更新记忆条目。
- 维护 tag、category、domain。
- 做 BM25 相关性检索。
- 按 local > project > user 的优先级组织上下文。
- 处理损坏 JSON 的恢复和备份。

## MemoryPipeline
`memory_pipeline.py` 把记忆治理拆成几个阶段：

```text
READ
  -> 根据任务描述和当前文件检索相关记忆
  -> domain classify
  -> BM25 search
  -> query reformulation fallback
  -> optional vector search + RRF
  -> optional reranker
  -> spreading activation

INJECT
  -> 根据上下文压力和记忆质量决定是否注入
  -> 把相关记忆追加到 system prompt

WRITE
  -> ReflectionEngine 从执行轨迹中提炼经验
  -> 写入 project memory

FEEDBACK
  -> 任务成功则提升相关记忆 utility
  -> 任务失败则轻微衰减

MAINTAIN
  -> curator 合并、归档、去重、校验、链接记忆
```

## Working Memory
`working_memory.py` 处理的是另一类记忆：当前任务中不能丢的关键状态。

长期记忆回答“以前学到了什么”，工作记忆回答“这次任务正在做什么不能忘”：

- 当前目标。
- 用户约束。
- 已修改文件。
- 验证结果。
- 待完成事项。

这和上下文压缩强相关，因为压缩时最怕删掉这些关键状态。

## 记忆注入的难点
记忆不是越多越好。召回不准的旧记忆会污染 prompt。MiniCode 用几种方式控制：

- BM25 相关性过滤。
- domain/tag/category 限定。
- reranker 可选精排。
- adaptive cooldown 避免每一轮都注入。
- feedback 根据成功/失败调整记忆权重。
- curator 做去重和维护。

## 和 RAG 的类比
MiniCode 的记忆系统和 RAG 有相似点：都是“检索相关信息再注入 prompt”。但对象不同：

| RAG | MiniCode Memory |
| --- | --- |
| 检索知识文档 | 检索项目经验和用户偏好 |
| 文档切块 | 记忆条目 |
| 向量召回/关键词召回 | BM25 / optional vector |
| 生成答案 | 指导 Agent 执行工具和修改代码 |

## 本章小结
MiniCode 的记忆系统体现了“Agent 自我沉淀”的思路：不是简单保存聊天记录，而是把可复用的项目经验、用户偏好和执行结论组织成可检索、可注入、可反馈的资产。



# 4.3 会话、Checkpoint 与 Rewind

## 学习目标
- 理解 session 不只是聊天历史。
- 看懂 checkpoint 和 rewind 的文件恢复逻辑。
- 知道为什么会话恢复是 Coding Agent 的核心能力。

## session 保存什么
`session.py` 中 `SessionData` 不只保存 messages，还保存：

- session metadata。
- messages。
- transcript entries。
- history。
- permissions summary。
- skills。
- MCP servers。
- instruction layers。
- hook/delegation/extensions/readiness surfaces。
- file checkpoints。

这些信息共同构成“Agent 当时的工作现场”。

## 为什么不能只保存聊天记录
长任务中断后，仅有聊天记录是不够的。Agent 还需要知道：

- 哪些文件被改过。
- 改之前是什么内容。
- 哪些工具运行过。
- 当时有哪些权限。
- 当前 runtime 是否可用。
- 用户是否已经看过某些结果。

所以 MiniCode 把会话做成 durable runtime state。

## Delta Save
session 保存采用 full snapshot + delta 的策略：

```text
Session full json
  -> 周期性保存完整状态
Delta files
  -> 保存新增 messages / transcript / checkpoints
  -> 减少每次写入成本
  -> 加载时重放 delta 合并状态
```

这适合长会话，因为每轮都写完整大 JSON 成本高，也容易放大损坏风险。

## Checkpoint
文件修改前调用 `create_file_checkpoint`：

```text
file_path
existed
previous_content
created_at
checkpoint_id
```

它记录的是“修改前快照”，不是修改后的内容。因此 rewind 时可以恢复到改动之前。

## Rewind
`rewind_session_data` 的核心步骤：

```text
选择要恢复的 checkpoint
  -> 为当前文件状态创建 reverse checkpoint
  -> 按 checkpoint 恢复旧内容
  -> 如果旧文件不存在则删除新文件
  -> 删除被 rewind 的 checkpoint
  -> 追加 reverse checkpoint
  -> full save session
```

reverse checkpoint 很关键。它使得 rewind 本身也是可追踪、可撤销的安全动作。

## Replay 和 Inspect
MiniCode 提供 session inspect / replay：

- inspect：查看 session 概要、模型、工具、权限、readiness、checkpoint。
- replay：按 transcript 重放当时对话和工具过程。

这对学习和调试都很重要：你可以复盘 Agent 为什么走到某个状态。

## 本章小结
会话系统是 MiniCode “长任务可恢复”的基础。checkpoint 解决文件安全，rewind 解决误修改恢复，replay/inspect 解决过程可解释。



# 5.1 MCP、Skills 与 Hooks：扩展 Agent 能力边界

## 学习目标
- 理解 MiniCode 如何接入外部工具生态。
- 区分 MCP、Skill、Hook 的职责。
- 理解扩展系统里的安全边界。

## 三类扩展能力
| 扩展 | 解决什么问题 | 关键文件 |
| --- | --- | --- |
| MCP | 接入外部工具服务器 | `mcp.py` |
| Skills | 把领域能力组织成可加载说明和工具 | `skills.py`, `tools/load_skill.py` |
| Hooks | 在 Agent 生命周期事件中触发动作 | `hooks.py` |

## MCP
MCP 是 Model Context Protocol。MiniCode 的 `mcp.py` 实现了 stdio JSON-RPC 客户端，可以：

- 启动 MCP server。
- 调用 `initialize`。
- 拉取 `tools/list`。
- 调用 `tools/call`。
- 支持 `resources/list/read`。
- 支持 `prompts/list/get`。
- 把 MCP 工具包装成 MiniCode 工具。

MCP 工具命名格式一般是：

```text
mcp__server__tool
```

## MCP 安全边界
MCP 可以启动外部进程，风险不低，所以 MiniCode 做了限制：

- project MCP 默认不信任，需要显式开启。
- MCP command 有白名单。
- 参数禁止 shell 元字符。
- payload 有 50MB 上限。
- Windows 下特殊处理 `.cmd` / `.bat` 启动方式。
- 禁止直接执行危险 shell。

这说明扩展能力不是“随便接”，而是经过安全治理。

## Skills
Skills 更像“能力说明 + 使用边界 + 示例 + 相关工具”的组织方式。MiniCode 会从项目和用户目录发现 skills，并通过 `load_skill` 工具按需加载。

它和 Tool 的区别：

| Tool | Skill |
| --- | --- |
| 可执行动作 | 指导如何执行某类任务 |
| 有输入 schema 和 run 函数 | 有说明、约束、示例、元信息 |
| 直接被模型 tool call | 被加载进上下文后指导模型 |

## Hooks
`hooks.py` 支持多种生命周期事件：

- PRE_TOOL_USE
- POST_TOOL_USE
- AGENT_START
- AGENT_STOP
- SESSION_SAVE
- SESSION_RESUME
- USER_INPUT
- ASSISTANT_OUTPUT
- STARTUP / SHUTDOWN

Hooks 适合做日志、审计、自动通知、外部脚本联动。

## 本章小结
MCP、Skills、Hooks 共同构成 MiniCode 的扩展面：MCP 扩展工具，Skills 扩展知识和操作方法，Hooks 扩展生命周期动作。它们都围绕一个核心目标：让 Agent 能力增长，但不突破安全边界。



# 5.2 子代理与任务协作：主控不失控

## 学习目标
- 理解 MiniCode 的子代理不是完全独立多智能体系统。
- 看懂 `task` 工具如何把子任务交给受限 Agent。
- 理解中心化多 Agent 的安全取舍。

## 为什么需要子代理
在复杂代码任务中，主 Agent 可能需要并行或分工处理：

- 让一个子代理只读代码并总结模块。
- 让一个子代理制定修改计划。
- 让一个子代理执行局部任务。

但如果多个 Agent 都能自由改文件和执行命令，就会出现状态冲突、权限混乱和结果不可控。

## MiniCode 的做法
MiniCode 把子代理做成一个普通工具：`tools/task.py`。

这意味着：

- 主 Agent 不移交控制权。
- 子代理的结果以 tool result 返回。
- 子代理能用哪些工具由主系统裁剪。
- 子代理步数有限。
- 子代理的输出被压缩成摘要返回主 Agent。

## Agent 类型
`task` 工具中有几种 agent 类型：

| 类型 | 权限倾向 | 用途 |
| --- | --- | --- |
| explore | 只读 | 搜索、阅读、总结代码 |
| plan | 只读 + review | 制定方案、分析风险 |
| general | 工具面更广 | 执行一般子任务 |

这种设计避免了“所有子代理都拥有完整权限”。

## 中心化协作思想
MiniCode 的多 Agent 协作更接近：

```text
主 Agent 统一规划、审批、质量控制
  -> 子 Agent 作为工具执行局部任务
  -> 子 Agent 返回摘要
  -> 主 Agent 决定下一步
```

而不是：

```text
多个 Agent 彼此通信、互相派活、共享复杂状态
```

后者更像完整多智能体平台，但工程成本和不确定性更高。

## 本章小结
MiniCode 的子代理设计重点是“协作但不失控”：把子代理纳入工具调用体系，用权限裁剪、步数限制和结果摘要保持主 Agent 的控制权。



# 5.3 CLI/TUI：本地产品交互面

## 学习目标
- 理解 MiniCode 不只有后端逻辑，也有本地产品交互。
- 看懂 slash commands 和 TTY app 的职责。
- 理解为什么 transcript 是 Agent 产品的重要界面。

## CLI Commands
`cli_commands.py` 提供大量 slash commands，例如：

- `/help`
- `/tools`
- `/status`
- `/cost`
- `/context`
- `/memory`
- `/config`
- `/sessions`
- `/session`
- `/session-replay`
- `/checkpoints`
- `/rewind-preview`
- `/rewind`
- `/model`
- `/mcp`
- `/permissions`
- `/read`
- `/write`
- `/edit`
- `/patch`
- `/cmd`

这些命令的意义是：用户不必每件事都交给模型，可以直接查询和控制 Agent runtime。

## TTY App
`tty_app.py` 和 `minicode/tui/` 实现交互式终端界面，包含：

- 屏幕状态。
- transcript 渲染。
- 工具输出折叠。
- 审批弹窗。
- 后台 agent 线程。
- 键盘输入处理。
- session autosave。
- slash command 本地处理。

## Transcript
transcript 是用户理解 Agent 行为的窗口：

- Agent 说了什么。
- 调用了哪些工具。
- 工具结果是什么。
- 哪些步骤需要审批。
- 是否出现 checkpoint。
- readiness 是否阻塞。

这让 Agent 从“黑盒模型”变成“可观察工作台”。

## CLI/TUI 和 Agent Loop 的关系
CLI/TUI 不直接决定任务怎么做，它负责：

```text
展示状态
接收输入
处理本地命令
发起 run_agent_turn
显示工具和模型输出
保存 session
```

真正的智能执行仍然在 Agent Loop 中。

## 本章小结
MiniCode 的 CLI/TUI 是本地 Agent 产品面。它让用户能看到、控制和恢复 Agent 的工作过程，而不只是看到最后一段回答。



# 6.1 Harness 与评估：让 Agent 质量可度量

## 学习目标
- 理解 Agent 评估和普通单元测试的区别。
- 看懂 Runtime Eval 和 Ablation Harness 的作用。
- 知道 release readiness 如何把质量结果产品化。

## 为什么 Agent 需要 Harness
普通函数测试检查输入输出即可，但 Agent 的质量不能只看最终文本。还要看：

- 模型调用了几次。
- 工具调用是否合理。
- 是否触发验证。
- 是否卡在 max steps。
- 是否上下文压力过高。
- 是否因为 provider 故障失败。
- 是否能从中断会话恢复。

Harness Engineering 的目标就是把这些过程变成可重复、可比较、可输出报告的评估流程。

## Runtime Profile Eval
`runtime_profile_eval.py` 定义：

- `RuntimeEvalScenario`
- `RuntimeEvalCondition`
- `RuntimeEvalRow`
- `evaluate_runtime_profiles`
- `runtime_profile_eval_as_dict`
- `runtime_profile_eval_as_markdown`

它可以用同一组 scenario 对比不同 runtime profile，例如 `single` 和 `single-deep`。

输出指标包括：

- wall time。
- model calls。
- tool starts / results。
- progress events。
- runtime events。
- stop reason。
- widened。
- verification guard。
- completed。
- final message。

## Cybernetic Ablation
`cybernetic_ablation.py` 是确定性控制器消融 harness。它不真实调用模型，而是用合成任务画像比较：

- static baseline。
- cybernetic controller。

它评估 completion score、tool error rate、context peak、verification strength、memory mode、model effort、progress action、supervisor risk、intervention count、estimated cost index。

这类评估不等于真实端到端胜率，但能隔离分析控制系统有没有产生合理决策。

## Release Readiness
`release_readiness.py` 和 `benchmarks/release_readiness.py` 把多个质量检查合在一起：

- compile check。
- test check。
- runtime profile eval。
- smoke checks。
- provider diagnostics。
- 输出 JSON 和 Markdown 报告。

这相当于把“是否可以发布”变成可检查结果，而不是凭感觉判断。

## Benchmark
`benchmarks/` 中包含：

- performance benchmark。
- multi-round stress test。
- cluster stress test。
- runtime profile eval。
- release readiness。

它们覆盖性能、压力、策略对比和发布门禁。

## 本章小结
MiniCode 的评估体系体现了 Agent 工程的关键思维：不只测试函数是否正确，还要观察 Agent 的执行过程、恢复能力、停止原因、上下文压力和 provider 故障。



# 6.2 控制系统：把 Agent 当成可调节运行系统

## 学习目标
- 理解 MiniCode 中 cybernetic control 的定位。
- 知道这些控制器如何服务 Agent 稳定性。
- 区分“必要主链路”和“高级控制层”。

## 为什么需要控制系统
一个 Coding Agent 在真实任务中会遇到很多动态情况：

- 工具连续失败。
- 上下文压力升高。
- 模型输出空内容。
- 任务复杂度超过预期。
- 测试失败需要切换策略。
- 成本或延迟过高。

如果主循环完全靠固定规则，就容易卡住或过度执行。控制系统的目标是根据运行状态动态调整策略。

## CyberneticOrchestrator
`cybernetic_orchestrator.py` 是控制器门面，它集中管理多个控制模块：

- feedback controller。
- feedforward controller。
- stability monitor。
- adaptive PID tuner。
- state observer。
- decoupling controller。
- predictive controller。
- self-healing engine。
- context cybernetics。
- cost control loop。
- progress controller。
- memory injection controller。
- model selection controller。
- smart router。
- reflection engine。
- model switcher。

## Feedforward 与 Feedback
| 类型 | 含义 | Agent 场景 |
| --- | --- | --- |
| Feedforward | 执行前预测风险并预配置 | 根据任务复杂度限制步数、调整超时、建议模型 |
| Feedback | 执行中根据状态纠偏 | 工具失败多就降低并发、上下文高就压缩、任务停滞就换策略 |

这是控制系统的核心思想：不是等失败后才崩溃，而是提前预测，执行中持续修正。

## Progress Controller
`progress_controller.py` 根据任务进展决定：

- continue。
- verify。
- switch_strategy。
- narrow_scope。
- request_confirmation。
- stop。

这解决的是 Agent 常见问题：一直继续、没有验证、失败后不换策略。

## Cost Control
成本控制关注 token、模型调用次数、上下文长度和 provider 费用。它的价值在于让 Agent 在可接受成本内完成任务，而不是无限调用模型。

## Self-Healing
自愈模块的思想是：当出现已知失败模式时，尝试自动恢复，例如：

- API 错误触发重试。
- 上下文超限触发 compact。
- provider 故障触发模型切换。
- 工具失败进入错误分类和修复提示。

## 如何评价这部分
这部分很亮眼，但学习时要注意：控制系统属于高级增强层，不是 MiniCode 最小可用链路。最小可用链路是入口、模型、工具、权限和主循环；控制系统是在复杂任务中提高稳定性和可观测性。

## 本章小结
MiniCode 的 cybernetic 模块体现了高级 Agent 工程思维：把 Agent 当成一个动态系统，通过预测、反馈、监控、恢复和成本控制来提升长任务稳定性。



# 7.1 测试、CI 与部署：工程质量怎么兜底

## 学习目标
- 理解 MiniCode 的质量保障体系。
- 知道 tests、benchmarks、CI、Docker 分别解决什么。
- 识别当前工程中的已知缺口。

## 测试覆盖面
`tests/` 覆盖范围很广，包括：

- Agent flow / loop / stress / intelligence。
- 模型适配器。
- 工具系统。
- 权限系统。
- 配置加载。
- MCP。
- 会话、checkpoint、rewind。
- TUI。
- 记忆系统。
- 上下文压缩。
- cybernetic 控制器。
- runtime profile eval。
- release readiness。

这说明项目不是只测单点函数，而是围绕 Agent Runtime 的关键风险建测试。

## CI
GitHub Actions 做了几类检查：

```text
checkout
  -> setup Python 3.11/3.12
  -> pip install -e .[dev]
  -> compileall
  -> ruff E,F
  -> mypy baseline
  -> packaging smoke tests
  -> pytest
```

CI 覆盖 Ubuntu、Windows、macOS，这对终端工具、路径处理、subprocess、MCP 这类跨平台能力很重要。

## Docker
Dockerfile 使用多阶段构建：

- builder 安装 package 到 venv。
- runtime 只复制 venv。
- 创建非 root 用户。
- 设置 `/workspace`。
- 持久化 `~/.mini-code` 目录。
- 默认入口 `minicode-py`。

docker-compose 声明了 CLI、gateway、cron、headless 等模式。但当前 Python 包里没有完整 gateway/cron runner 实现，学习时要把它看成部署规划或历史演进痕迹，不要当成完全落地能力。

## 当前测试依赖缺口
当前环境下 pytest 收集时会遇到 `hypothesis` 缺失，而 `pyproject.toml` 的 dev 依赖只声明了 pytest。这说明：

- 项目测试规模大。
- 依赖声明还需要补齐。
- 学习源码时要区分“已有架构能力”和“工程打磨问题”。

## 本章小结
MiniCode 的工程质量主要靠 tests、benchmarks、CI 和 release readiness 兜底。它已经有比较完整的质量意识，但仍存在测试依赖和部分部署声明超前的问题。



# 7.2 源码索引：核心文件逐类速查

## 学习目标
- 建立源码文件和功能模块之间的映射。
- 后续精读时能快速定位。
- 避免被 100 多个 Python 文件淹没。

## 入口与运行
| 文件 | 作用 |
| --- | --- |
| `minicode/main.py` | 交互式 CLI/TUI 主入口 |
| `minicode/headless.py` | 非交互一次性执行入口 |
| `minicode/config.py` | 配置加载、provider 凭证、fallback 配置 |
| `minicode/runtime_profiles.py` | single / single-deep 等运行画像 |

## Agent 核心
| 文件 | 作用 |
| --- | --- |
| `minicode/agent_loop.py` | Agent 主循环 |
| `minicode/turn_kernel.py` | turn 状态机、阶段、停止原因、验证策略 |
| `minicode/types.py` | ChatMessage、ToolCall、AgentStep、ModelAdapter 协议 |
| `minicode/intent_parser.py` | 任务意图解析 |
| `minicode/task_object.py` | 任务对象建模 |
| `minicode/task_graph.py` | 任务图和 worktree 隔离相关能力 |

## 工具系统
| 文件 | 作用 |
| --- | --- |
| `minicode/tooling.py` | ToolDefinition、ToolRegistry、ToolResult |
| `minicode/tools/__init__.py` | 核心工具注册 |
| `minicode/tools/read_file.py` | 读取文件 |
| `minicode/tools/grep_files.py` | 搜索文件 |
| `minicode/tools/write_file.py` | 写文件 |
| `minicode/tools/edit_file.py` | 精确/模糊替换 |
| `minicode/tools/patch_file.py` | 批量 patch |
| `minicode/tools/run_command.py` | 命令执行 |
| `minicode/tools/git.py` | Git 工具 |
| `minicode/tools/test_runner.py` | 测试运行工具 |
| `minicode/tools/task.py` | 子代理工具 |

## 安全与恢复
| 文件 | 作用 |
| --- | --- |
| `minicode/permissions.py` | 权限审批和危险操作识别 |
| `minicode/workspace.py` | 工作区路径解析 |
| `minicode/file_review.py` | diff 审查与 checkpoint 写入 |
| `minicode/session.py` | session、checkpoint、rewind、replay |
| `minicode/background_tasks.py` | 后台任务管理 |

## 模型层
| 文件 | 作用 |
| --- | --- |
| `minicode/model_registry.py` | provider 检测、模型注册、adapter 创建 |
| `minicode/anthropic_adapter.py` | Anthropic Messages API |
| `minicode/openai_adapter.py` | OpenAI-compatible Chat Completions |
| `minicode/mock_model.py` | mock adapter |
| `minicode/api_retry.py` | API 错误分类和退避 |
| `minicode/model_switcher.py` | 模型 fallback/switch |

## 上下文与记忆
| 文件 | 作用 |
| --- | --- |
| `minicode/context_manager.py` | token 估算、上下文统计、基础压缩 |
| `minicode/context_compactor.py` | tool budget、dedup、micro/auto/reactive compact |
| `minicode/micro_compact.py` | 轻量工具结果压缩 |
| `minicode/memory.py` | 分层记忆管理 |
| `minicode/memory_pipeline.py` | read/inject/write/feedback/maintain |
| `minicode/working_memory.py` | 当前任务关键状态保护 |
| `minicode/timeline_memory.py` | 时间线和状态记忆 |

## 扩展与产品面
| 文件 | 作用 |
| --- | --- |
| `minicode/mcp.py` | MCP stdio JSON-RPC 客户端 |
| `minicode/skills.py` | skills 发现和管理 |
| `minicode/hooks.py` | 生命周期 hooks |
| `minicode/product_surfaces.py` | instruction、extension、readiness 等产品状态 |
| `minicode/prompt.py` | 系统提示词构建 |
| `minicode/prompt_pipeline.py` | prompt 静态/动态 section 管理 |
| `minicode/cli_commands.py` | slash commands |
| `minicode/tty_app.py` | 终端交互应用 |
| `minicode/tui/` | TUI 子模块 |

## 评估与工程化
| 文件 | 作用 |
| --- | --- |
| `minicode/runtime_profile_eval.py` | runtime profile 对比评估 |
| `minicode/cybernetic_ablation.py` | 控制器消融 harness |
| `minicode/release_readiness.py` | 发布就绪报告 |
| `minicode/paper_a_task_completion_eval.py` | 任务完成度实验 |
| `benchmarks/` | 性能、压力和 release benchmark |
| `tests/` | 单元和集成测试 |

## 本章小结
精读 MiniCode 时不要平均用力。先看 Agent 核心、工具、安全、上下文、记忆、会话，再看扩展和高级控制模块。



# 8.1 亮点、难点与解决方案

## 学习目标
- 把 MiniCode 的技术点转成项目亮点。
- 理解每个难点背后的工程问题。
- 形成面试时可展开的讲法。

## 亮点一：自研 Agent Runtime
难点：不能只调用模型，因为 coding agent 需要多轮推理、工具执行、验证和失败恢复。

解决：用 `agent_loop.py` 和 `turn_kernel.py` 实现主循环和状态机，把任务拆成 explore、execute、verify 阶段，并记录 runtime event、stop reason、widening、guard 等过程指标。

面试讲法：我不是简单封装 LLM API，而是实现了一个本地 Agent Runtime，让模型通过受控工具完成代码分析、修改和验证。

## 亮点二：统一 Tool Calling 框架
难点：工具种类多，文件、命令、Git、测试、MCP 的风险和输出格式都不同。

解决：用 `ToolDefinition`、`ToolRegistry`、`ToolContext`、`ToolResult` 统一工具协议，通过 metadata 标注只读、破坏性、可并发和权限需求，并对大输出做智能截断。

面试讲法：我把工具从普通函数抽象成可注册、可校验、可审计、可限流的 Agent 动作。

## 亮点三：权限安全审查
难点：模型可能生成危险命令或错误文件修改，真实仓库不能无保护执行。

解决：路径访问限制在 workspace 内，危险命令进入审批，文件写入前生成 diff 并创建 checkpoint，支持 rewind 恢复。

面试讲法：模型只负责提出动作，真正落地前必须经过权限边界和变更审查。

## 亮点四：长上下文治理
难点：Agent 会不断读取文件、执行命令、收集测试结果，messages 很快超过模型窗口。

解决：用 token 估算、tool result budget、read dedup、micro compact、auto compact 和 reactive compact 分层治理，同时用 working memory 保护关键任务状态。

面试讲法：我把上下文当成有限资源，而不是无限往 prompt 里塞。

## 亮点五：分层记忆系统
难点：Agent 每次从零开始会重复犯错，旧记忆又可能污染上下文。

解决：把记忆分成 user/project/local 三层，结合 BM25、tag/category/domain、reranker、adaptive cooldown、reflection 和 feedback 实现按需召回和沉淀。

面试讲法：记忆系统不是聊天记录，而是从执行过程提炼可复用的项目经验和用户偏好。

## 亮点六：会话恢复和 Rewind
难点：长任务中断后，恢复不能只靠聊天历史，还要恢复文件状态和运行状态。

解决：session 保存 messages、transcript、permissions、readiness、checkpoints；文件修改前 checkpoint，支持 inspect、replay、rewind 和 reverse checkpoint。

面试讲法：我把一次 Agent 会话做成可检查、可回放、可撤销的运行现场。

## 亮点七：Harness 评估
难点：Agent 质量不能只看最后一句回答，过程质量同样重要。

解决：Runtime Eval 记录 model calls、tool events、runtime events、stop reason、verification guard；Cybernetic Ablation 比较 baseline 和控制器策略；Release Readiness 输出发布门禁报告。

面试讲法：我建立了 Agent 的可观测评估链路，用过程指标定位复杂任务中的稳定性问题。

## 本章小结
MiniCode 的核心亮点不是某一个库，而是 Agent 工程思维：运行时、工具、安全、上下文、记忆、恢复和评估共同构成一个可控系统。



# 8.2 源码精读实验与二次开发任务

## 学习目标
- 通过小实验真正读懂源码。
- 把课件内容转化成可演示能力。
- 为后续简历和面试准备素材。

## 实验一：跑通 Mock Agent Turn
目标：不用真实 API key，通过 `MockModelAdapter` 跑一次 `run_agent_turn`。

观察点：

- messages 如何变化。
- 是否产生 tool call。
- tool result 如何回填。
- final message 在哪里生成。

涉及文件：

- `mock_model.py`
- `agent_loop.py`
- `tooling.py`
- `tests/test_agent_loop.py`

## 实验二：新增一个只读工具
目标：新增一个 `count_python_files` 工具，统计当前仓库 Python 文件数量。

步骤：

1. 在 `minicode/tools/` 下新增工具文件。
2. 定义 validator 和 run。
3. 设置 metadata 为 READ_ONLY 和 CONCURRENCY_SAFE。
4. 在 `tools/__init__.py` 注册。
5. 写 pytest 验证。

学习收益：理解 ToolDefinition、ToolRegistry 和工具元信息。

## 实验三：观察文件写入 checkpoint
目标：用 write/edit/patch 修改一个临时文件，查看 session checkpoints。

观察点：

- 修改前内容是否保存。
- checkpoint_id 是否生成。
- rewind preview 显示什么。
- rewind 后文件是否恢复。

涉及文件：

- `file_review.py`
- `session.py`
- `write_file.py`
- `edit_file.py`
- `tests/test_tools.py`
- `tests/test_session.py`

## 实验四：模拟上下文超限
目标：构造大量 tool result，观察 `ContextCompactor.process_request` 如何压缩。

观察点：

- tool budget 是否生效。
- microcompact 是否释放 token。
- auto compact 是否触发。
- stats 中各类计数如何变化。

涉及文件：

- `context_compactor.py`
- `context_manager.py`
- `micro_compact.py`

## 实验五：添加一条项目记忆并召回
目标：向 project memory 写入一条约束，再用任务描述触发检索。

观察点：

- memory.json 如何变化。
- BM25 是否召回。
- inject 是否进入 system prompt。
- feedback 是否影响 usage_count。

涉及文件：

- `memory.py`
- `memory_pipeline.py`
- `memory_injector.py`

## 实验六：运行 Runtime Profile Eval
目标：用 benchmark 或测试中的 scenario 比较 `single` 和 `single-deep`。

观察点：

- completed。
- model_calls。
- runtime_events。
- widened。
- verification_guard。
- stop_reason。

涉及文件：

- `runtime_profile_eval.py`
- `benchmarks/runtime_profile_eval.py`
- `tests/test_runtime_profile_eval.py`

## 实验七：做一个面试讲解图
目标：画出 MiniCode 从用户输入到最终回复的链路图。

建议图示：

```text
User
 -> main/headless
 -> runtime config
 -> prompt bundle
 -> model adapter
 -> agent loop
 -> tool registry
 -> permissions/checkpoint
 -> context/memory/session
 -> final answer
```

## 本章小结
读 Agent 项目不能只看源码，要通过小实验观察状态变化。MiniCode 最适合用“主循环 + 工具 + 权限 + 上下文 + 记忆 + 会话恢复 + 评估”这几条实验线来掌握。



# 8.3 全项目复盘：只看这一页也能讲清 MiniCode

## 项目定位
MiniCode 是一个本地 AI Coding Agent Runtime。它不是 RAG 系统，也不是 LangChain Agent 示例，而是围绕真实代码仓库构建的模型推理、工具执行、安全审查、上下文治理、记忆沉淀、会话恢复和运行时评估系统。

## 一句话链路
用户提出开发任务后，MiniCode 通过 CLI/TUI 或 headless 入口装配配置、模型、工具、权限、prompt、记忆和会话状态，然后由 `run_agent_turn` 驱动模型和工具交替执行，最终完成代码读取、修改、验证和回复。

## 核心技术栈
- Python 3.11+ 自研 Agent Runtime。
- Anthropic Messages API。
- OpenAI-compatible Chat Completions。
- Tool Calling。
- MCP stdio JSON-RPC。
- 本地 Session Store。
- Memory System。
- Context Compaction。
- Pytest / Benchmarks / CI / Docker。

## 核心源码
| 方向 | 关键文件 |
| --- | --- |
| 入口 | `main.py`, `headless.py` |
| 主循环 | `agent_loop.py`, `turn_kernel.py` |
| 工具 | `tooling.py`, `tools/` |
| 权限 | `permissions.py`, `file_review.py`, `workspace.py` |
| 模型 | `model_registry.py`, `anthropic_adapter.py`, `openai_adapter.py` |
| 上下文 | `context_manager.py`, `context_compactor.py`, `micro_compact.py` |
| 记忆 | `memory.py`, `memory_pipeline.py`, `working_memory.py` |
| 会话 | `session.py`, `cli_commands.py`, `tty_app.py` |
| 扩展 | `mcp.py`, `skills.py`, `hooks.py`, `tools/task.py` |
| 评估 | `runtime_profile_eval.py`, `cybernetic_ablation.py`, `release_readiness.py` |

## 最重要的六个亮点
1. Agent 主循环工程化：阶段、策略、事件、停止原因可观测。
2. Tool Calling 体系完整：工具注册、参数校验、异常兜底、输出截断。
3. 权限安全可控：路径、命令、编辑、diff、checkpoint、rewind。
4. 长上下文治理：预算、去重、压缩、超限恢复、工作记忆保护。
5. 分层记忆沉淀：user/project/local、检索、注入、反思、反馈。
6. Harness 评估：过程指标、策略对比、release readiness。

## 最核心的难点
MiniCode 的难点不是调用模型，而是让模型能在本地代码仓库里“真的干活”：

- 干活要有工具。
- 工具要有权限。
- 长任务要有上下文治理。
- 中断要能恢复。
- 经验要能沉淀。
- 失败要能观察和评估。

## 推荐面试表达
可以这样讲：

> 这个项目我更关注的是 Agent 工程化，而不是简单接一个模型 API。我把一次编程任务抽象成可观测的 Agent Turn，模型通过 Tool Registry 调用文件、命令、Git、测试等工具；工具执行前有权限审查和 diff checkpoint，执行过程中有上下文压缩和记忆注入，执行后会保存 session 并通过 runtime eval 观察完成状态、停止原因和工具轨迹。

## 本章小结
如果只记一句话：MiniCode 的价值在于把 AI Coding Agent 从“会聊天的模型”变成“能在真实仓库里安全执行、持续记忆、可恢复、可评估的本地运行时系统”。

