"""Day 27: 以显式信号选择模型和验证范围，并保留审计理由。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True, slots=True)
class ModelInfo:
    name: str
    power: float
    relative_cost: float
    long_context: bool = False


@dataclass(frozen=True, slots=True)
class RoutingSignal:
    complexity: float
    budget_pressure: float
    latency_pressure: float
    requires_long_context: bool = False


@dataclass(frozen=True, slots=True)
class RoutingDecision:
    model: str
    score: float
    reasons: tuple[str, ...]


def choose_model(models: list[ModelInfo], signal: RoutingSignal, failed: set[str]) -> RoutingDecision:
    candidates: list[tuple[float, ModelInfo]] = []
    for model in models:
        if model.name in failed or (signal.requires_long_context and not model.long_context):
            continue
        score = 1 - abs(model.power - signal.complexity)
        score -= signal.budget_pressure * model.relative_cost * 0.5
        score -= signal.latency_pressure * model.power * 0.2
        candidates.append((score, model))
    if not candidates:
        raise RuntimeError("no eligible fallback model")
    score, selected = max(candidates, key=lambda row: row[0])
    return RoutingDecision(selected.name, score, (f"power={selected.power:.2f}", f"cost={selected.relative_cost:.2f}"))


def verification_mode(changed_files: list[str], previous_failure: bool) -> Literal["none", "targeted", "full"]:
    if not changed_files or all(path.endswith((".md", ".txt")) for path in changed_files):
        return "none"
    if previous_failure or len(changed_files) > 5:
        return "full"
    return "targeted"


@dataclass(slots=True)
class DecisionAudit:
    rows: list[dict] = field(default_factory=list)

    def record(self, kind: str, decision: object, evidence: str) -> None:
        self.rows.append({"kind": kind, "decision": repr(decision), "evidence": evidence})


if __name__ == "__main__":
    catalog = [ModelInfo("small", .3, .2), ModelInfo("strong", .9, .9, True)]
    decision = choose_model(catalog, RoutingSignal(.85, .1, .1, True), set())
    assert decision.model == "strong" and verification_mode(["core.py"], False) == "targeted"
    print(decision)

