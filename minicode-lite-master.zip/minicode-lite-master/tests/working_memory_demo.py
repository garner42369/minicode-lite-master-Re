"""Day 18 working_memory 演示：保护事实 + 预算淘汰 + TTL。

运行（项目根目录）：
    python tests/working_memory_demo.py
"""

import sys
import time
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.working_memory import WorkingMemory


def main():
    memory = WorkingMemory()
    memory.set("goal", "修复 divide 的整除 bug", importance=10)
    memory.set("constraint", "不要改 formatter.py", importance=8)
    memory.set("note", "读过 calculator.py", importance=3)
    memory.set("temp", "临时观察", importance=1)

    print("== render（按重要度降序，注入摘要用）==")
    print(memory.render())

    print("\n== 预算淘汰（最多保留 2 条）==")

    evicted = memory.evict_by_budget(2)
    print(f"淘汰（低 importance 先淘汰）: {evicted}")
    print("剩余:")
    print(memory.render())

    print("\n== TTL 过期淘汰 ==")
    memory2 = WorkingMemory()
    memory2.set("perm", "永久", importance=5, ttl=float("inf"))
    memory2.set("temp", "1 秒后过期", importance=5, ttl=1)
    time.sleep(1.1)
    expired = memory2.evict_expired()
    print(f"过期淘汰: {expired}")
    print(f"永久仍在: {memory2.get('perm') is not None}")


if __name__ == "__main__":
    main()
