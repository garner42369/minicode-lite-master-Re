"""minicode 的自动模式风险分类：命令风险等级与原因。

Day 11 引入。auto 模式需要「哪些动作明确安全、哪些中高风险」的判断，本模块
提供命令的风险分类能力，供构造 PermissionRequest 时填写 risk 字段使用。

两条红线（课件）：
1. 风险分类只用于审批决策，不宣称是 OS 沙箱——正则能识别「看似危险」的
   片段，但无法阻止一个「看似安全」的 Python 脚本访问任意系统资源；
2. Prompt injection 检测只是风险信号，不要因命中某短语就永久拒绝合法任务，
   也不要因未命中就自动信任外部内容。
"""

from __future__ import annotations

from minicode.permissions import RiskLevel

# 危险命令片段 → (升级到的风险等级, 原因)
# 顺序重要：先匹配更危险/更具体的片段。命中即返回，不再继续。
_DANGEROUS_PATTERNS: list[tuple[str, RiskLevel, str]] = [
    ("rm -rf", RiskLevel.DANGEROUS, "递归强制删除"),
    ("rm -fr", RiskLevel.DANGEROUS, "递归强制删除"),
    ("mkfs", RiskLevel.DANGEROUS, "格式化文件系统"),
    ("dd if=", RiskLevel.DANGEROUS, "直接写块设备"),
    ("/dev/sd", RiskLevel.DANGEROUS, "操作块设备"),
    ("sudo", RiskLevel.HIGH, "提权执行"),
    ("| sh", RiskLevel.HIGH, "内容直接交给 shell 执行"),
    ("| bash", RiskLevel.HIGH, "内容直接交给 shell 执行"),
    ("chmod 777", RiskLevel.HIGH, "放开全部文件权限"),
    ("shutdown", RiskLevel.HIGH, "关闭系统"),
    ("reboot", RiskLevel.HIGH, "重启系统"),
    ("git push --force", RiskLevel.HIGH, "强制推送"),
    ("git reset --hard", RiskLevel.HIGH, "丢弃本地更改（不可恢复）"),
]

# 只读命令：不修改文件系统、无网络副作用，视为 safe。
# 同时收录 Unix 与 Windows 原生命令：dir/type 是 cmd 内置，findstr/where/more/sort
# 是 System32 的独立 exe。Windows 下列目录用 dir，不是 Unix 的 ls。
_READ_ONLY_EXECUTABLES = {
    # Unix / Linux
    "ls", "cat", "grep", "find", "head", "tail", "wc",
    "pwd", "which", "echo", "date", "tree", "file",
    # Windows
    "dir", "type", "findstr", "where", "more", "sort",
}


def classify_command(
    executable: str,
    argv: list[str] | None = None,
) -> tuple[RiskLevel, str]:
    """对命令做风险分类，返回 (风险等级, 原因)。

    executable: 可执行文件名（如 "rm"、"python"、"curl"）
    argv: 参数列表，不含 executable（如 ["-rf", "/tmp/x"]）

    分类顺序：危险片段 → 只读命令 → 默认 medium。
    原因字符串用于「强制提示」——审批时让用户/模型知道为什么被标为这个风险。
    """
    argv = argv or []
    full = " ".join([executable, *argv]).lower()

    # 1. 危险片段：命中即按该片段升级风险（不再往下看）
    for fragment, level, reason in _DANGEROUS_PATTERNS:
        if fragment in full:
            return level, reason

    # 2. 只读命令：明确安全
    if executable.lower() in _READ_ONLY_EXECUTABLES:
        return RiskLevel.SAFE, "只读命令"

    # 3. 默认：可能有副作用，需要询问
    return RiskLevel.MEDIUM, "可能有副作用的命令"
