"""minicode 的 OpenAI 兼容 Provider 适配器（当前对接 DeepSeek V4）。

Day 10 引入。把内部 ChatMessage 历史翻译成 OpenAI Chat Completions 格式
发给 Provider，再把 Provider 响应翻译回统一的 AgentStep。

核心约定（课件红线）：Provider 原始 JSON 只存在于本模块；Loop 与工具协议
不感知 OpenAI 格式。本模块负责处理 Provider 特有、而通用协议没有的东西：

1. thinking 思考链（reasoning_content）：DeepSeek V4 默认开启，响应里有
   reasoning_content，且「带 tool_calls 的 assistant 消息回传必须带上它」，
   否则 Provider 返回 400（实测确认）。它只落进 AgentStep.reasoning 这个
   诊断字段，不改变核心协议语义。
2. tool_calls 的 arguments 是 JSON 字符串，需要 json.loads 反序列化成 dict；
3. usage 里 Provider 特有的 reasoning_tokens 等，只落成本记录，不进核心协议。

DeepSeek V4 的两个关键事实（实测确认）：
- base_url 不带 /v1，请求路径 = base_url + /chat/completions；
- 非流式即可完成工具闭环，流式（SSE 分片拼装）作为后续增强另做。
"""

from __future__ import annotations

import json
from typing import Any

from minicode.api_retry import encode_json_body, request_with_retry
from minicode.cost_tracker import CostTracker, compute_cost
from minicode.tooling import ToolDefinition
from minicode.types import AgentStep, ChatMessage, ToolCall

# 进度/最终协议标记：prompt 的 protocol 段要求模型在「还在工作」时以
# <progress> 开头、在「真正完成」时以 <final> 开头。这里据此区分 kind。
_FINAL_MARK = "<final>"
_PROGRESS_MARK = "<progress>"
# 模型偶尔把 <final> 当 XML 开标签、在末尾补一个闭合标签；剥离它避免污染回答
_FINAL_CLOSE_MARK = "</final>"


def to_openai_messages(messages: list[ChatMessage]) -> list[dict[str, Any]]:
    """把内部 ChatMessage 历史翻译成 OpenAI messages 数组。

    关键转换规则（与内部历史写法的差异）：
    - 内部每个工具调用拆成一条 assistant_tool_call + 一条 tool_result；
      而 OpenAI 要求「一条 assistant 消息携带整个 tool_calls 数组」，
      所以这里要把连续的 assistant_tool_call 合并成一条 assistant。
    - tool_result → role="tool"（必须带 tool_call_id 与请求配对）；
    - assistant_progress → role="assistant"（OpenAI 没有 progress 角色）。
    """
    out: list[dict[str, Any]] = []
    i = 0
    n = len(messages)

    while i < n:
        msg = messages[i]
        role = msg["role"]

        if role == "assistant_tool_call":
            # 合并连续的工具请求为一条 assistant(tool_calls=[...])
            tool_calls: list[dict[str, Any]] = []
            reasoning = ""
            while i < n and messages[i]["role"] == "assistant_tool_call":
                call = messages[i]
                tool_calls.append(
                    {
                        "id": call["tool_call_id"],
                        "type": "function",
                        "function": {
                            "name": call["tool_name"],
                            # arguments 是 JSON 字符串（Provider 协议），内部 input 是 dict
                            "arguments": json.dumps(call["input"], ensure_ascii=False),
                        },
                    }
                )
                # 同一步的多个调用共享同一段思考链，取第一条的即可
                if not reasoning and call.get("reasoning"):
                    reasoning = call["reasoning"]
                i += 1

            assistant: dict[str, Any] = {"role": "assistant", "content": None, "tool_calls": tool_calls}
            # DeepSeek V4：带 tool_calls 的 assistant 回传必须带 reasoning_content，
            # 否则 400。只有模型确实输出了思考链才带。
            if reasoning:
                assistant["reasoning_content"] = reasoning
            out.append(assistant)
            continue

        if role == "tool_result":
            out.append(
                {"role": "tool", "tool_call_id": msg["tool_call_id"], "content": msg.get("content", "")}
            )
        elif role in {"system", "user", "assistant", "assistant_progress"}:
            # assistant_progress 折叠为 assistant（OpenAI 无 progress 角色）
            openai_role = "assistant" if role == "assistant_progress" else role
            item: dict[str, Any] = {"role": openai_role, "content": msg.get("content", "")}
            # 最终回答若带思考链也一并回传，保证历史可完整重放
            if msg.get("reasoning"):
                item["reasoning_content"] = msg["reasoning"]
            out.append(item)
        i += 1

    return out


def to_openai_tools(tools: list[ToolDefinition]) -> list[dict[str, Any]]:
    """把工具定义翻译成 OpenAI tools 数组。

    ToolMetadata.input_schema 本身就是 JSON Schema（{"type":"object",...}），
    直接作为 function.parameters 传给 Provider，无需二次包装。
    """
    return [
        {
            "type": "function",
            "function": {
                "name": tool.metadata.name,
                "description": tool.metadata.description,
                "parameters": tool.metadata.input_schema,
            },
        }
        for tool in tools
    ]


def extract_usage(payload: dict[str, Any]) -> dict[str, int]:
    """从响应里抽取 token 用量，统一成内部字段。

    只取 Provider 通用字段；reasoning_tokens 这类 Provider 特有字段单独保留，
    用于成本观测，不进 AgentStep 核心协议。
    """
    usage = payload.get("usage") or {}
    details = usage.get("completion_tokens_details") or {}
    return {
        "input_tokens": usage.get("prompt_tokens", 0),
        "output_tokens": usage.get("completion_tokens", 0),
        "total_tokens": usage.get("total_tokens", 0),
        "reasoning_tokens": details.get("reasoning_tokens", 0),
    }


def _classify_text(content: str) -> tuple[str, str]:
    """根据协议前缀把文本拆成 (kind, 去掉标记后的正文)。

    标记 <final>/<progress> 是给模型看的「输出协议」，属于元信息而非正文，
    展示给用户前应剥离。无标记时按最终回答处理（对非协议输出宽容）。
    """
    stripped = content.lstrip()
    if stripped.startswith(_FINAL_MARK):
        text = stripped[len(_FINAL_MARK):].strip().removesuffix(_FINAL_CLOSE_MARK).strip()
        return "final", text
    if stripped.startswith(_PROGRESS_MARK):
        return "progress", stripped[len(_PROGRESS_MARK):].strip()
    return "final", content


def parse_openai_response(payload: dict[str, Any]) -> AgentStep:
    """把 OpenAI 响应翻译成 AgentStep。

    规则：有 tool_calls 就返回工具请求步（含思考链）；否则是文本步，按
    <final>/<progress> 前缀判定 kind。
    """
    choice = payload["choices"][0]
    message = choice.get("message") or {}
    reasoning = message.get("reasoning_content") or ""

    raw_calls = message.get("tool_calls") or []
    if raw_calls:
        calls: list[ToolCall] = []
        for item in raw_calls:
            function = item["function"]
            # arguments 是 JSON 字符串，反序列化成 dict；空串/缺省按空参处理
            try:
                arguments = json.loads(function.get("arguments") or "{}")
            except json.JSONDecodeError:
                arguments = {}
            calls.append(ToolCall(id=item["id"], name=function["name"], arguments=arguments))
        return AgentStep(type="tool_calls", calls=calls, reasoning=reasoning)

    content = message.get("content") or ""
    kind, text = _classify_text(content)
    return AgentStep(type="assistant", kind=kind, content=text, reasoning=reasoning)


class OpenAIAdapter:
    """实现 ModelAdapter 协议的 OpenAI 兼容适配器（非流式）。

    职责边界：只翻译协议 + 发请求 + 记成本。不判断文件权限、不决定任务是否
    完成、不管理工具副作用——那些是 Loop 与权限层的职责。
    """

    def __init__(
        self,
        model: str,
        base_url: str,
        api_key: str,
        *,
        tools: list[ToolDefinition] | None = None,
        cost_tracker: CostTracker | None = None,
        input_price_per_mtok: float = 0.0,
        output_price_per_mtok: float = 0.0,
        timeout: float = 120.0,
        max_retries: int = 3,
    ) -> None:
        self._model = model
        self._base_url = base_url
        self._api_key = api_key
        self._tools = tools or []
        self._cost_tracker = cost_tracker
        self._input_price = input_price_per_mtok
        self._output_price = output_price_per_mtok
        self._timeout = timeout
        self._max_retries = max_retries

    def next(
        self,
        messages: list[ChatMessage],
        on_stream_chunk=None,
        store=None,
    ) -> AgentStep:
        """发一次非流式 Chat Completions 请求，返回翻译后的 AgentStep。

        on_stream_chunk 在非流式下于拿到完整文本后回调一次（与 ScriptedModel
        行为一致），保持协议对齐；真流式分片回调在后续实现。
        """
        payload: dict[str, Any] = {
            "model": self._model,
            "messages": to_openai_messages(messages),
            "stream": False,
        }
        if self._tools:
            payload["tools"] = to_openai_tools(self._tools)

        url = self._base_url + "/chat/completions"
        headers = {
            "Content-Type": "application/json",
            # 认证头只出现在请求里；日志/快照层负责脱敏，这里绝不打印密钥
            "Authorization": f"Bearer {self._api_key}",
        }
        body = encode_json_body(payload)

        status, raw = request_with_retry(
            url, headers, body, timeout=self._timeout, max_retries=self._max_retries
        )
        data = json.loads(raw.decode("utf-8"))
        step = parse_openai_response(data)

        if self._cost_tracker is not None:
            self._record_usage(data)

        # 非流式：整段文本一次性回调（有文本才回调）
        if on_stream_chunk is not None and step.type == "assistant" and step.content:
            on_stream_chunk(step.content)
        return step

    def with_tools(self, tools: list[ToolDefinition]) -> "OpenAIAdapter":
        """返回一个同配置、但工具清单不同的适配器（子 Agent 只读工具过滤用）。

        tools 在构造时冻结进 self._tools，next() 每轮都传它；子 Agent 需要模型
        只看到过滤后的工具（否则 explore/plan 的模型仍能看到 write_file/run_command），
        所以要一个「同配置 + 新工具清单」的浅拷贝适配器。
        """
        return OpenAIAdapter(
            model=self._model,
            base_url=self._base_url,
            api_key=self._api_key,
            tools=tools,
            cost_tracker=self._cost_tracker,
            input_price_per_mtok=self._input_price,
            output_price_per_mtok=self._output_price,
            timeout=self._timeout,
            max_retries=self._max_retries,
        )

    def with_model(self, model: str) -> "OpenAIAdapter":
        """返回一个同配置、但模型名不同的适配器（子 Agent 用低成本 flash 模型用）。"""
        return OpenAIAdapter(
            model=model,
            base_url=self._base_url,
            api_key=self._api_key,
            tools=self._tools,
            cost_tracker=self._cost_tracker,
            input_price_per_mtok=self._input_price,
            output_price_per_mtok=self._output_price,
            timeout=self._timeout,
            max_retries=self._max_retries,
        )

    def _record_usage(self, payload: dict[str, Any]) -> None:
        """抽取 usage 并按配置单价折算成本，交给 CostTracker 记录。"""
        usage = extract_usage(payload)
        cost = compute_cost(
            usage["input_tokens"],
            usage["output_tokens"],
            self._input_price,
            self._output_price,
        )
        assert self._cost_tracker is not None
        self._cost_tracker.record(
            model=self._model,
            input_tokens=usage["input_tokens"],
            output_tokens=usage["output_tokens"],
            cost_usd=cost,
        )
