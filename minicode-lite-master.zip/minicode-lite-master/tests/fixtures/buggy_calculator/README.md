# buggy_calculator

演示用缺陷计算器，贯穿 30 天复现全程：只读解释、失败测试、受控编辑、
Checkpoint、Rewind、上下文压缩、记忆召回、Headless 与最终评估都会复用这个
小仓库，以便观察运行时能力如何逐层叠加。

## 预设缺陷

`calculator.py` 的 `divide(a, b)` 把真除法 `/` 误写成了整除 `//`，
导致 `divide(5, 2)` 返回 `2` 而非 `2.5`。

## 测试命令

```bash
cd tests/fixtures/buggy_calculator
python -m pytest tests/test_calculator.py -q
```

## 预期结果

- `test_divide_returns_true_division` 失败 —— 失败原因正是预设缺陷；
- `test_format_result` 通过。

## 最终修复验收命令

修复后再次运行：

```bash
python -m pytest tests/test_calculator.py -q
```

应当 `2 passed`，即证明 `divide` 已改为真除法。
