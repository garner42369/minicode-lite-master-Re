"""minicode 的预测控制器（Day 28）。轻量趋势预测：指数平滑 + 移动平均趋势。

裁剪参考项目 predictive_controller 的「多指标预测 + 动作推荐」——这里只留「趋势预测」
这一个轻量能力，用来提前应对上下文增长（「预测失败时回退阈值策略」由 context_action 的
usage 阈值兜底）。
"""

from __future__ import annotations


class ExponentialSmoother:
    """指数平滑：对历史值加权平均，近期权重高，用于预测下一值。"""

    def __init__(self, alpha: float = 0.3) -> None:
        self.alpha = alpha
        self._forecast: float | None = None

    def update(self, actual: float) -> float:
        if self._forecast is None:
            self._forecast = actual
        else:
            self._forecast = self.alpha * actual + (1 - self.alpha) * self._forecast
        return self._forecast

    def predict(self) -> float:
        return self._forecast if self._forecast is not None else 0.0

    def reset(self) -> None:
        self._forecast = None


def predict_trend(values: list[float], short: int = 5, long: int = 20) -> str:
    """用短/长移动平均判断趋势：short > long → "up"，short < long → "down"，否则 "stable"。"""
    if len(values) < short:
        return "stable"
    short_avg = sum(values[-short:]) / short
    window = min(long, len(values))
    long_avg = sum(values[-window:]) / window
    if short_avg > long_avg + 0.01:
        return "up"
    if short_avg < long_avg - 0.01:
        return "down"
    return "stable"
