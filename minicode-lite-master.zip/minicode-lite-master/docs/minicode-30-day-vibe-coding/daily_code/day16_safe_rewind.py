"""Day 16: Replay 只读，Rewind 先做 after-hash 冲突检测。"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True, slots=True)
class FileCheckpoint:
    path: str
    existed: bool
    before: bytes
    after_hash: str
    group_id: str


def preview_rewind(checkpoints: list[FileCheckpoint]) -> list[str]:
    return [f"{'restore' if cp.existed else 'delete'} {cp.path} [{cp.group_id}]" for cp in checkpoints]


def rewind_group(checkpoints: list[FileCheckpoint]) -> None:
    conflicts: list[str] = []
    for checkpoint in checkpoints:
        target = Path(checkpoint.path)
        current = target.read_bytes() if target.exists() else b""
        if digest(current) != checkpoint.after_hash:
            conflicts.append(checkpoint.path)
    if conflicts:
        raise RuntimeError("rewind conflicts: " + ", ".join(conflicts))
    for checkpoint in checkpoints:
        target = Path(checkpoint.path)
        if checkpoint.existed:
            target.write_bytes(checkpoint.before)
        else:
            target.unlink(missing_ok=True)


def replay(events: list[dict]) -> str:
    """只格式化已经发生的事件，绝不调用模型或工具。"""
    return "\n".join(f"{event.get('type')}: {event.get('summary', '')}" for event in events)


if __name__ == "__main__":
    import tempfile

    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "demo.txt"
        path.write_text("after", encoding="utf-8")
        cp = FileCheckpoint(str(path), True, b"before", digest(b"after"), "g1")
        rewind_group([cp])
        assert path.read_text(encoding="utf-8") == "before"
        print(replay([{"type": "tool", "summary": "edited demo.txt"}]))

