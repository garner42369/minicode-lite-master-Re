"""minicode 的 API 重试层：错误分类、退避计算与带重试的 HTTP 传输。

Day 10 引入。真实模型调用必然面对网络抖动、限流（429）、服务端暂不可用
（5xx）、认证失败（401/403）等错误。这一层回答三个问题：

1. 哪些错误值得重试、哪些不该碰——认证失败 / 参数错误重试只会浪费请求
   甚至触发风控锁号，必须立即失败；
2. 重试间隔怎么算——指数退避 + 随机 jitter（避免大量客户端同刻重试造成
   惊群），且优先尊重服务端返回的 Retry-After；
3. 用什么发请求——urllib.request（项目「运行时零依赖」的硬约束，不引
   httpx / requests）。

关键边界：本层只保证「发请求 + 按状态重试」，只应对「尚未产生工具副作用」
的网络类错误。工具已经执行之后，Provider 层面的重试绝不能导致重复执行工具
——那属于 Adapter 上层的职责（见 openai_adapter 的注释）。这一层不碰工具、
不碰 Agent 历史，只做传输与重试。
"""

from __future__ import annotations

import json
import random
import time
import urllib.error
import urllib.request
from email.utils import parsedate_to_datetime
from typing import Any

# 可重试的 HTTP 状态码：请求超时、限流、服务端暂不可用。
# 401/403（认证）与 400/422（参数）不在其中——重试无意义。
RETRYABLE_STATUS = frozenset({408, 429, 500, 502, 503, 504})

# 默认指数退避基数（秒）：第 0 次重试前约 1s，之后 2s、4s、8s… 再加 jitter。
_BASE_DELAY = 1.0
# jitter 上限（秒）：在指数延迟上叠加一个 [0, _JITTER) 的随机量，打破同步重试。
_JITTER = 0.5


def should_retry_status(status: int) -> bool:
    """判断 HTTP 状态码是否值得重试（网络类/限流/服务端错误）。"""
    return status in RETRYABLE_STATUS


def classify_exception(exc: BaseException) -> bool:
    """判断异常是否属于「网络类、可重试」。

    - HTTPError：看状态码（429/5xx 重试，401/400 不重试）；
    - URLError / TimeoutError：网络层失败（连接被拒、DNS、读超时），可重试；
    - 其他（如 JSON 解码失败 = 畸形响应）：重试无意义，不重试。
    """
    if isinstance(exc, urllib.error.HTTPError):
        return should_retry_status(exc.code)
    if isinstance(exc, urllib.error.URLError):
        return True
    if isinstance(exc, TimeoutError):
        return True
    return False


def backoff_delay(attempt: int, retry_after: float | None = None) -> float:
    """计算第 attempt 次重试前的等待秒数（纯函数，便于测试）。

    attempt 从 0 开始。若服务端给了 Retry-After 则尊重它；否则用
    base * 2^attempt + jitter 的指数退避。
    """
    if retry_after is not None and retry_after > 0:
        return retry_after
    return _BASE_DELAY * (2 ** attempt) + random.uniform(0.0, _JITTER)


def _parse_retry_after(headers: Any) -> float | None:
    """从响应头解析 Retry-After（秒数或 HTTP 日期），解析失败返回 None。

    返回 None 时由指数退避兜底，不会因此放弃重试。
    """
    value = headers.get("Retry-After") if headers is not None else None
    if value is None:
        return None
    # 形式 1：秒数（如 "120"）
    try:
        return float(value)
    except (TypeError, ValueError):
        pass
    # 形式 2：HTTP 日期（如 "Wed, 21 Oct 2026 07:28:00 GMT"）
    try:
        dt = parsedate_to_datetime(value)
        if dt is not None:
            return max(0.0, dt.timestamp() - time.time())
    except (TypeError, ValueError, OverflowError):
        pass
    return None


def request_with_retry(
    url: str,
    headers: dict[str, str],
    body: bytes,
    *,
    timeout: float = 120.0,
    max_retries: int = 3,
) -> tuple[int, bytes]:
    """向 url POST 一段 JSON 字节，失败时按分类决定是否退避重试。

    返回 (HTTP 状态码, 响应体字节)。不重试的错误或重试耗尽后，抛最后一次
    异常交给上层（Adapter）处理。

    为什么要 sleep 真实等待：重试间隔是「对服务端限流的尊重」，用假 sleep
    绕过会立刻再次撞限流。测试不直接调用本函数的 sleep 路径（真实模型测试
    里正常不会触发），退避计算由 backoff_delay 单独覆盖。
    """
    last_exc: BaseException | None = None
    for attempt in range(max_retries + 1):
        try:
            request = urllib.request.Request(url, data=body, headers=headers, method="POST")
            with urllib.request.urlopen(request, timeout=timeout) as response:
                return response.status, response.read()
        except urllib.error.HTTPError as exc:
            last_exc = exc
            # 认证/参数错误绝不重试，直接抛
            if not should_retry_status(exc.code):
                raise
            if attempt >= max_retries:
                raise
            retry_after = _parse_retry_after(exc.headers)
            time.sleep(backoff_delay(attempt, retry_after))
        except (urllib.error.URLError, TimeoutError) as exc:
            last_exc = exc
            if attempt >= max_retries:
                raise
            time.sleep(backoff_delay(attempt))

    # 正常情况下循环内必定 return 或 raise，此句仅让类型检查器安心。
    assert last_exc is not None
    raise last_exc


def encode_json_body(payload: dict[str, Any]) -> bytes:
    """把请求体字典编码成 UTF-8 字节（含 Content-Type 头需要的 JSON 序列化）。"""
    return json.dumps(payload).encode("utf-8")
