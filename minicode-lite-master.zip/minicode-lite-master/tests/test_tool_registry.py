"""Day 5：ToolRegistry 异常防火墙的契约测试。"""

from minicode.tooling import (
    ToolCapability,
    ToolContext,
    ToolDefinition,
    ToolMetadata,
    ToolRegistry,
    ToolResult,
)


def _echo_tool() -> ToolDefinition:
    """构造一个回显教学工具，用于走完整个生命周期。"""

    def _validate(raw):
        text = raw.get("text")
        if not isinstance(text, str):
            raise ValueError("text is required")
        return {"text": text}

    def _run(parsed, ctx):
        return ToolResult(ok=True, output=parsed["text"])

    return ToolDefinition(
        validator=_validate,
        run=_run,
        metadata=ToolMetadata(
            name="echo",
            description="回显文本",
            max_result_size_chars=10,  # 设小上限，方便测截断
            capabilities={ToolCapability.READ_ONLY},
        ),
    )


class TestToolRegistry:
    def test_execute_success(self):
        registry = ToolRegistry([_echo_tool()])
        result = registry.execute("echo", {"text": "hello"}, ToolContext(cwd="."))
        assert result.ok is True
        assert result.output == "hello"

    def test_unknown_tool(self):
        registry = ToolRegistry([_echo_tool()])
        result = registry.execute("missing", {}, ToolContext(cwd="."))
        assert result.ok is False
        assert result.error_code == "unknown_tool"

    def test_missing_argument(self):
        # 缺参数 → 验证失败，不调用 run
        registry = ToolRegistry([_echo_tool()])
        result = registry.execute("echo", {}, ToolContext(cwd="."))
        assert result.ok is False
        assert result.error_code == "invalid_input"

    def test_runner_crash_is_contained(self):
        # 核心验收：Runner 抛异常不终止会话，归一化成 tool_crash

        def _validate(raw):
            return raw

        def _boom(parsed, ctx):
            raise RuntimeError("boom")

        tool = ToolDefinition(
            validator=_validate,
            run=_boom,
            metadata=ToolMetadata(name="boom", description="会崩溃的工具"),
        )
        registry = ToolRegistry([tool])
        result = registry.execute("boom", {}, ToolContext(cwd="."))
        assert result.ok is False
        assert result.error_code == "tool_crash"
        assert "RuntimeError" in result.output

    def test_large_output_truncated(self):
        registry = ToolRegistry([_echo_tool()])
        result = registry.execute("echo", {"text": "x" * 100}, ToolContext(cwd="."))
        assert result.metadata["truncated"] is True
        assert "omitted" in result.output  # 截断标注了被省略的规模

    def test_dispose_calls_disposer(self):
        called: list[bool] = []
        registry = ToolRegistry([_echo_tool()], disposer=lambda: called.append(True))
        registry.dispose()
        assert called == [True]
