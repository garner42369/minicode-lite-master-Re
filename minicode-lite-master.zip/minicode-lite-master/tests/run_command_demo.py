"""Day 13 run_command 演示：argv 执行、结构化结果、超时、输出截断。

运行（项目根目录）：
    python tests/run_command_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.tools.run_command import run_command


def main():
    py = sys.executable

    # 1. 正常命令
    r1 = run_command([py, "-c", "print('verified')"], ".")
    print(f"正常命令: ok={r1.ok} exit={r1.exit_code} stdout={r1.stdout!r}\n")

    # 2. 失败命令（即使 stdout 有看似正常的输出，ok 仍为 False）
    r2 = run_command([py, "-c", "print('looks fine'); raise SystemExit(2)"], ".")
    print(f"失败命令: ok={r2.ok} exit={r2.exit_code} stdout={r2.stdout!r}\n")

    # 3. 超时
    r3 = run_command([py, "-c", "import time; time.sleep(10)"], ".", timeout=1)
    print(f"超时命令: ok={r3.ok} exit={r3.exit_code} timed_out={r3.timed_out}\n")

    # 4. 大输出截断
    r4 = run_command([py, "-c", "print('x' * 50000)"], ".", output_limit=100)
    print(f"大输出: truncated={r4.truncated} stdout_len={len(r4.stdout)}")
    print(f"  截断后 head: {r4.stdout[:30]!r}")
    print(f"  截断后 tail: {r4.stdout[-30:]!r}")


if __name__ == "__main__":
    main()
