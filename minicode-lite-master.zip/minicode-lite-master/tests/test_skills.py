"""Day 23：Skill 系统的契约测试。

覆盖：extract_description（按课件 description: 前缀）、discover_skills（四根优先级）、
load_skill（按需读全文）、install/remove（托管目录）、load_skill 工具。
"""

from minicode.skills import (
    discover_skills,
    extract_description,
    install_skill,
    load_skill,
    remove_managed_skill,
)


class TestExtractDescription:
    def test_extracts_description_prefix(self):
        md = "---\ndescription: 运行测试\n---\n# 正文\n详细内容\n"
        assert extract_description(md) == "运行测试"
        print(f"\n提取 description: {extract_description(md)!r}")

    def test_no_description_returns_empty(self):
        # 无 frontmatter description: 前缀时返回空串，不回退到正文首段（按课件）
        md = "# 标题\n正文段落\n"
        assert extract_description(md) == ""
        print("\n无 description 前缀返回空串")


class TestDiscoverSkills:
    def test_discovers_summary_only(self, tmp_path, monkeypatch):
        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").write_text(
            "description: TDD 工作流\n\n# 内容\n完整指令", encoding="utf-8"
        )
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")
        skills = discover_skills(tmp_path)
        assert len(skills) == 1
        assert skills[0].name == "tdd"
        assert skills[0].description == "TDD 工作流"
        assert skills[0].source == "project"
        print(f"\n发现 project skill: {skills[0]}")

    def test_priority_project_over_user(self, tmp_path, monkeypatch):
        home = tmp_path / "home"
        (tmp_path / ".mini-code" / "skills" / "demo" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / ".mini-code" / "skills" / "demo" / "SKILL.md").write_text("description: project版\n", encoding="utf-8")
        (home / ".mini-code" / "skills" / "demo" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (home / ".mini-code" / "skills" / "demo" / "SKILL.md").write_text("description: user版\n", encoding="utf-8")
        monkeypatch.setattr("minicode.skills._home_dir", lambda: home)
        skills = discover_skills(tmp_path)
        assert len(skills) == 1  # 同名 skill 高优先级覆盖低优先级
        assert skills[0].description == "project版"
        print(f"\nproject 覆盖 user: {skills[0]}")

    def test_compat_roots_discovered(self, tmp_path, monkeypatch):
        home = tmp_path / "home"
        (home / ".claude" / "skills" / "compat" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (home / ".claude" / "skills" / "compat" / "SKILL.md").write_text("description: 兼容技能\n", encoding="utf-8")
        monkeypatch.setattr("minicode.skills._home_dir", lambda: home)
        skills = discover_skills(tmp_path)
        assert any(s.name == "compat" and s.source == "compat_user" for s in skills)
        print(f"\n兼容根发现: {[f'{s.name}:{s.source}' for s in skills]}")


class TestLoadSkill:
    def test_load_full_content(self, tmp_path, monkeypatch):
        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").write_text(
            "description: TDD\n\n完整指令内容", encoding="utf-8"
        )
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")
        skill = load_skill(tmp_path, "tdd")
        assert skill is not None
        assert "完整指令内容" in skill.content
        assert skill.source == "project"
        print(f"\n加载全文: {skill.content[:50]!r}")

    def test_unknown_returns_none(self, tmp_path, monkeypatch):
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")
        assert load_skill(tmp_path, "nope") is None
        print("\n未知 skill 返回 None")


class TestInstallRemove:
    def test_install_and_discover(self, tmp_path, monkeypatch):
        src = tmp_path / "src" / "SKILL.md"
        src.parent.mkdir(parents=True, exist_ok=True)
        src.write_text("description: 新技能\n", encoding="utf-8")
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")

        result = install_skill(tmp_path, str(src), name="myskill", scope="project")
        assert result["name"] == "myskill"
        assert (tmp_path / ".mini-code" / "skills" / "myskill" / "SKILL.md").is_file()
        assert any(s.name == "myskill" for s in discover_skills(tmp_path))
        print(f"\ninstall 后被发现: {[s.name for s in discover_skills(tmp_path)]}")

    def test_remove(self, tmp_path, monkeypatch):
        (tmp_path / ".mini-code" / "skills" / "tmp" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / ".mini-code" / "skills" / "tmp" / "SKILL.md").write_text("description: x\n", encoding="utf-8")
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")

        result = remove_managed_skill(tmp_path, "tmp", scope="project")
        assert result["removed"] is True
        assert not (tmp_path / ".mini-code" / "skills" / "tmp").exists()
        print("\nremove 删除成功")


class TestLoadSkillTool:
    def test_load_skill_tool_reads_full_content(self, tmp_path, monkeypatch):
        from minicode.tooling import ToolContext
        from minicode.tools.load_skill import LOAD_SKILL

        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").parent.mkdir(parents=True, exist_ok=True)
        (tmp_path / ".mini-code" / "skills" / "tdd" / "SKILL.md").write_text(
            "description: TDD\n\n指令内容", encoding="utf-8"
        )
        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")
        result = LOAD_SKILL.run({"name": "tdd"}, ToolContext(cwd=str(tmp_path)))
        assert result.ok
        assert "指令内容" in result.output
        assert "SKILL: tdd" in result.output
        print(f"\nload_skill 工具输出:\n{result.output[:120]}")

    def test_unknown_skill_tool_returns_not_found(self, tmp_path, monkeypatch):
        from minicode.tooling import ToolContext
        from minicode.tools.load_skill import LOAD_SKILL

        monkeypatch.setattr("minicode.skills._home_dir", lambda: tmp_path / "home")
        result = LOAD_SKILL.run({"name": "nope"}, ToolContext(cwd=str(tmp_path)))
        assert not result.ok
        assert result.error_code == "not_found"
        print(f"\n未知 skill 工具: {result.output!r}")
