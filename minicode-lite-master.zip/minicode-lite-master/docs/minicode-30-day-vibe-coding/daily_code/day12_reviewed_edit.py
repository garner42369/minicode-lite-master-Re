"""Day 12: diff → approval → checkpoint → hash recheck → atomic write。"""

from __future__ import annotations

import difflib
import hashlib
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True, slots=True)
class Checkpoint:
    path: str
    existed: bool
    before: bytes
    before_hash: str
    after_hash: str
    group_id: str


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def unified_diff(path: str, before: str, after: str) -> str:
    return "\n".join(difflib.unified_diff(before.splitlines(), after.splitlines(), f"a/{path}", f"b/{path}", lineterm=""))


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        os.replace(temp_name, path)
    except Exception:
        Path(temp_name).unlink(missing_ok=True)
        raise


def reviewed_edit(
    path: Path,
    old: str,
    new: str,
    approve: Callable[[str], bool],
    group_id: str,
) -> Checkpoint:
    existed = path.exists()
    before_bytes = path.read_bytes() if existed else b""
    before_text = before_bytes.decode("utf-8")
    count = before_text.count(old)
    if count != 1:
        raise ValueError(f"expected one match, found {count}")
    after_text = before_text.replace(old, new, 1)
    if not approve(unified_diff(path.name, before_text, after_text)):
        raise PermissionError("edit denied")
    current = path.read_bytes() if path.exists() else b""
    if digest(current) != digest(before_bytes):
        raise RuntimeError("file changed after review")
    after_bytes = after_text.encode("utf-8")
    checkpoint = Checkpoint(str(path), existed, before_bytes, digest(before_bytes), digest(after_bytes), group_id)
    atomic_write(path, after_bytes)
    return checkpoint


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as directory:
        target = Path(directory) / "calculator.py"
        target.write_text("def divide(a, b): return a // b\n", encoding="utf-8")
        cp = reviewed_edit(target, "a // b", "a / b", lambda diff: "-def" in diff, "edit-1")
        assert "a / b" in target.read_text(encoding="utf-8") and cp.existed
        print("reviewed edit: OK")

