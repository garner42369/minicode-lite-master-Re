# 记忆与上下文混用：一次架构踩坑记录

> 记录时间：2026-10-05（Day 18 推进中）
> 状态：已实施（commit 79ffb33、c5f78ba）

## 一、发生了什么

Day 18 做「压缩与工作记忆」时，我们实现了一个 `compact_messages` 函数，它把「受保护的工作记忆」直接渲染进「压缩摘要」的文本里。具体代码（`minicode/context_compactor.py:140`）：

```python
summary_content = "COMPACTED (older context summarized)\n"
summary_content += "Protected facts:\n" + (protected.render() or "(none)") + "\n"  # ← 记忆被硬塞进摘要
if files:
    summary_content += "Files touched: " + ", ".join(files) + "\n"
if errors:
    summary_content += "Errors encountered:\n" + "\n".join(...)
```

于是压缩产物（`summary`）的 `content` 里，混进了两种**来源完全不同**的内容：

| 段落 | 来源 | 性质 |
|---|---|---|
| `Protected facts` | `WorkingMemory.render()`（外部记忆） | 记忆注入 |
| `Files touched` | 从被压缩的 `removed` 消息提取 | 压缩摘要 |
| `Errors encountered` | 从被压缩的 `removed` 消息提取 | 压缩摘要 |

这导致了最初那个问题：**「保护记忆到底包含哪些」不可控**——因为它取决于「压缩那一刻 `render()` 渲染了什么」，而不是一张清晰的、集中定义的清单。

## 二、根源：把「记忆注入」放进了「压缩」

记忆和上下文在参考项目里是**四个独立动作**组成的链路：

```
记忆(StableTaskPack / WorkingMemory)      ← 独立的、受保护的存储
   ↓ [注入] 请求组装时，作为 system 消息放进上下文
上下文(messages)                          ← 发给模型的对话历史
   ↓ [压缩] 上下文超限时，只把「对话历史」摘要化
压缩后上下文                              ← system 消息(含注入的记忆)原样保留，历史变摘要
```

关键在「注入」和「压缩」是**不同环节、由不同模块负责**的两个动作：

- **注入**：每个 step 发请求前，把记忆作为一条独立的 system 消息 upsert 进消息列表。
- **压缩**：token 超阈值时，只把「对话历史」（non-system）摘要化，system 消息（含记忆）原样保留。

我们的实现**省略了「注入」这个环节**，把「记忆进上下文」硬塞进了「压缩」：

```
记忆(WorkingMemory)
   ↓ [压缩] compact_messages 里 protected.render() 塞进 summary 字符串
摘要                                       ← 记忆被硬塞进了压缩产物
```

参考项目的正确时序（`MiniCode-Python/minicode/agent_loop.py:1200-1226`，每个 step 开始时）：

```python
current_messages = compact_messages(...)          # ① 先压缩（若超阈值）→ 产生 summary
stable_task_pack = build_stable_task_pack(...)     # ② 构建记忆（每轮重建，验证/进度在变）
stable_text = stable_task_pack.to_protected_text()
current_messages = _upsert_stable_task_state_message(current_messages, stable_text)  # ③ 注入记忆
```

记忆注入用的是「upsert 一条带固定标记的 system 消息」（`agent_loop.py:154-172`）：

```python
STABLE_TASK_STATE_MARKER = "[Stable task state]"

def _upsert_stable_task_state_message(messages, stable_text):
    filtered = [m for m in messages
                if not (m["role"] == "system"
                        and str(m.get("content", "")).startswith(STABLE_TASK_STATE_MARKER))]
    filtered.append({"role": "system", "content": f"{STABLE_TASK_STATE_MARKER}\n{stable_text}"})
    return filtered
```

所以记忆和摘要在参考项目里是**两条不同的 system 消息**：摘要带 `_compact_boundary` 标记、偶发（超阈值才产生）；记忆带 `[Stable task state]` 标记、常态（每轮 upsert 更新）。

## 三、会产生什么后果

1. **边界模糊**：保护记忆包含哪些，取决于「压缩时 render 了什么」，而不是一张集中清单，无法枚举、无法验证。
2. **记忆被降级**：记忆沦为摘要里的一段文字，失去「独立消息」身份，无法每轮单独更新（upsert）——验证状态、进度、最新工具结果这些**每轮都在变**的事实，被冻结在压缩那一刻。
3. **动作耦合**：压缩和注入被焊死在一起，无法各自独立演化。想改记忆的注入策略（比如按相关性筛选注入多少），就得动压缩逻辑。
4. **摘要语义污染**：摘要本该是「对被压缩历史的确定性提取」，现在混进了「外部记忆」，两者语义不可分。
5. **触发时机错乱**：记忆本该**每轮都注入**，现在只在**压缩发生时**才出现；不压缩时模型根本看不到受保护记忆。

## 四、如何解决

方向：**功能 + 策略对齐参考项目，架构自定**（回到 CLAUDE.md 的本意——不逐行照搬，参考源码自上而下看架构，用自己的结构）。

核心是**拆开两条线**：

1. **`compact_messages` 只做摘要**：删掉 `protected.render()` 那行，摘要只从被压缩的 `removed` 消息里确定性提取 `topics / tools / files / errors`（不调 LLM）。
2. **记忆改走「每 step 发请求前注入」**：循环里在发请求前，用 `_upsert` 一条带标记的 system 消息注入记忆，压缩时 system 消息原样保留，记忆因此永不进摘要。

功能/策略对齐清单（这是要盯的目标，架构实现随我们）：

| 功能 | 策略 | 状态 |
|---|---|---|
| Token 观测 | 估算标 estimated、预留输出余量 | ✅ |
| 工具结果预算 | 大结果落盘 artifact、head/tail + 路径 | ✅ 已接 agent_loop |
| 读取去重 | path+hash、文件变化失效 | ✅ 已接 agent_loop |
| 轻量裁剪 | 确定性去重/去空、不调 LLM | ✅ |
| 结构化摘要 | 确定性提 topics/tools/files/errors/unlinked | ✅ 五字段 |
| 保护记忆注入 | 请求组装时注入、压缩不碰 | ✅ 已接 agent_loop |
| 自动压缩 | 高水位触发、SessionMemory 优先 Full 兜底 | ❌ 消息数占位待换 token |
| 响应式恢复 | overflow 激进恢复 | ❌ |
| 熔断 | 连续失败阈值 3 | ❌ |
| 工作记忆淘汰 | importance + TTL + 预算 | ✅ |

## 五、偏离的起点：Day 14

这次混用的根子在 Day 14 就埋下了。课件 Day 14 的 daily_code（64 行）只讲了 turn_kernel 的**验证门槛**（`Phase/TurnState/Decision`），而参考项目的 turn_kernel（890 行）核心是 **`StableTaskPack`**——「保护任务状态跨压缩存活」的载体。

我们跟着课件只做了验证门槛，漏掉了 `StableTaskPack`。到 Day 18 要「保护记忆」时，没有架构参照，只能临时发明一个简化版 `stable_task_pack` 函数，还塞错了位置。

## 六、经验教训

1. **记忆注入和上下文压缩是两个动作**，必须分开：注入在请求组装时（常态、每轮），压缩在超限时（偶发）。谁进摘要、谁进 system 消息，边界要清晰。
2. **课件的 daily_code 是极简教学版，参考源码才是架构的完整参照**。CLAUDE.md 要求「参考源码自上而下对照架构」，不能只复刻课件 daily_code 就以为覆盖了完整需求。
3. **每天推进前必须查课件 + 参考源码**，尤其要核实「模块到底有没有被调用」「前后 Day 的接线关系」，不能凭记忆写。
4. **功能 + 策略对齐，架构自定**：不必照搬参考项目的类结构和分层，但要盯住「做什么功能、用什么策略」。
