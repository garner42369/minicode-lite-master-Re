"""minicode 的成本控制闭环（Day 28）。

控制「消耗速度」（cost_per_minute），不是累计花费——累计花费只能增加，PID 控制它无意义
（GPT 提醒的关键点）。PID 输出映射到预算乘数 [0.3, 2.0]（1.0 = 默认预算），带总预算上限：
已超预算就强制收紧，不再依赖 PID。
"""

from __future__ import annotations

from dataclasses import dataclass

from minicode.pid_controller import PID


@dataclass(frozen=True, slots=True)
class BudgetAdjustment:
    budget_multiplier: float  # 1.0 = 默认预算；<1 收紧，>1 放宽
    reason: str


class CostController:
    """成本闭环：感知消耗速度 → PID → 预算乘数。"""

    def __init__(
        self,
        target_cost_per_min: float = 0.5,
        total_budget: float = 5.0,
        kp: float = 1.5,
        ki: float = 0.08,
        kd: float = 0.2,
    ) -> None:
        # PID 输出 [-0.7, 1.0]，乘数 = 1 + output ∈ [0.3, 2.0]
        self.pid = PID(kp, ki, kd, output_min=-0.7, output_max=1.0)
        self.target = target_cost_per_min
        self.total_budget = total_budget
        self._spent = 0.0

    def decide(self, cost_per_min: float) -> BudgetAdjustment:
        """根据当前消耗速度给出预算乘数。"""
        if self._spent >= self.total_budget:
            return BudgetAdjustment(0.3, f"total budget exhausted (spent={self._spent:.2f})")
        control = self.pid.update(self.target, cost_per_min)
        multiplier = round(1.0 + control, 3)
        if multiplier < 0.8:
            reason = f"over-spending (rate={cost_per_min:.2f}/min > target={self.target})"
        elif multiplier > 1.2:
            reason = f"under-spending (rate={cost_per_min:.2f}/min < target={self.target})"
        else:
            reason = f"on-target (rate={cost_per_min:.2f}/min)"
        return BudgetAdjustment(multiplier, reason)

    def record_spend(self, cost: float) -> None:
        self._spent += cost

    def reset(self) -> None:
        self.pid.reset()
        self._spent = 0.0
