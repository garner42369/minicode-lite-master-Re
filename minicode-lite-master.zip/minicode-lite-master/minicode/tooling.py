"""minicode 的工具协议：定义、元数据、上下文与统一结果。

Day 2 落地协议与数据结构；Day 5 加入 ToolRegistry（查找/校验/执行/异常兜底/输出截断）。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable


class ToolCapability(str, Enum):
    """工具能力标志，供调度与权限判断使用（读类工具可并发，写类工具需串行/审批）。"""

    READ_ONLY = "read_only"
    DESTRUCTIVE = "destructive"
    CONCURRENCY_SAFE = "concurrency_safe"
    REQUIRES_PERMISSION = "requires_permission"


@dataclass
class ToolMetadata:
    """工具的完整描述：名称、说明、输入 schema、能力标志、开关、输出上限与标签。

    name / description / input_schema 放在这里，让 metadata 可以自包含地独立传递
    （例如构建 prompt 时只需要工具描述，不需要执行函数）。
    """

    name: str                                                        # 工具名
    description: str                                                 # 工具说明
    capabilities: set[ToolCapability] = field(default_factory=set)   # 能力标志集合
    input_schema: dict[str, Any] = field(default_factory=dict)       # JSON schema，供模型了解入参结构
    is_enabled: bool = True
    max_result_size_chars: int = 10_000                              # 输出截断上限（字符）
    tags: list[str] = field(default_factory=list)

    @property
    def is_read_only(self) -> bool:
        return ToolCapability.READ_ONLY in self.capabilities

    @property
    def is_destructive(self) -> bool:
        return ToolCapability.DESTRUCTIVE in self.capabilities

    @property
    def is_concurrency_safe(self) -> bool:
        return ToolCapability.CONCURRENCY_SAFE in self.capabilities


@dataclass(slots=True)
class ToolResult:
    """工具执行后的统一回执。

    即使工具内部抛异常，Loop 最终也应拿到一个可处理的结果（由 Registry 兜底转换），
    而不是让异常击穿整个 Agent 主循环。
    """

    ok: bool                        # 是否成功
    output: str                     # 归一化后的文本输出（可能被截断）
    error_code: str | None = None   # 失败时的错误码，如 unknown_tool / validation_error
    metadata: dict[str, Any] = field(default_factory=dict)  # 附加元信息


@dataclass(slots=True)
class ToolContext:
    """工具运行上下文：工作目录、权限、会话与运行时引用。"""

    cwd: str
    permissions: Any | None = None  # 具体类型到 Day 11 引入 PermissionManager
    session: Any | None = None
    depth: int = 0  # Day 26：子 Agent 委派深度，防止无限递归
    model: Any | None = None  # Day 26：子 Agent 递归用的模型
    tools: Any | None = None  # Day 26：子 Agent 递归用的工具注册表


# 校验器：原始输入 -> 解析后的参数；执行器：参数 + 上下文 -> ToolResult
Validator = Callable[[Any], Any]
Runner = Callable[[Any, ToolContext], ToolResult]


@dataclass(slots=True)
class ToolDefinition:
    """一个可注册工具：执行逻辑（validator + run）+ 完整描述（metadata）。

    """

    validator: Validator
    run: Runner
    metadata: ToolMetadata


# 错误码 → 恢复建议的映射。恢复建议是「环境给模型的纠正信号」，不是用户消息：
# 它附在 ToolResult.metadata 里，模型能区分「运行时纠正」与「用户新指令」。
_RECOVERY_HINTS: dict[str, str] = {
    "unknown_tool": "未知工具，请检查工具名，或改用 list_files / read_file / grep_files。",
    "invalid_input": "参数无效，请核对输入 schema 后重试。",
    "tool_crash": "工具内部异常，请换一种方式或重试。",
    "not_found": "文件不存在，请先用 list_files 确认路径。",
    "binary_file": "二进制文件无法按文本读取，请改用其他方式。",
    "not_directory": "路径不是目录，请核对路径后重试。",
}


def recovery_hint_for(error_code: str) -> str:
    """把结构化错误码映射为给模型的恢复建议文本。"""
    return _RECOVERY_HINTS.get(error_code, "请检查输入并重试。")


def _fail(output: str, error_code: str) -> ToolResult:
    """构造带恢复建议的失败结果，保证所有失败路径都带 metadata["recovery_hint"]。"""
    return ToolResult(
        ok=False,
        output=output,
        error_code=error_code,
        metadata={"recovery_hint": recovery_hint_for(error_code)},
    )


class ToolRegistry:
    """工具注册表：O(1) 查找 + 异常防火墙 + 输出截断。

    它是 Agent Loop 与具体工具之间的「异常防火墙」：
    未知工具、验证失败、执行崩溃、超大输出都归一化成 ToolResult，不击穿主循环。
    """

    def __init__(self, tools: list[ToolDefinition], disposer: Callable[[], Any] | None = None) -> None:
        # O(1) 名称索引；工具名在 metadata 里
        self._tools = {tool.metadata.name: tool for tool in tools}
        # 多个 disposer（Day 24 MCP 进程清理可追加）；dispose 时依次调用
        self._disposers: list[Callable[[], Any]] = [disposer] if disposer is not None else []

    def list(self) -> list[ToolDefinition]:
        return list(self._tools.values())

    def register(self, tool: ToolDefinition) -> None:
        """动态注册一个工具（Day 24 MCP 工具运行时注册用）。"""
        self._tools[tool.metadata.name] = tool

    def find(self, name: str) -> ToolDefinition | None:
        return self._tools.get(name)

    def execute(self, name: str, raw_input: Any, context: ToolContext) -> ToolResult:
        tool = self.find(name)
        if tool is None:
            return _fail(f"Unknown tool: {name}", "unknown_tool")

        # 阶段 1：验证输入（验证错误 → invalid_input）
        try:
            parsed = tool.validator(raw_input)
        except (TypeError, ValueError, KeyError) as exc:
            return _fail(f"Invalid input for {name}: {exc}", "invalid_input")

        # 阶段 2：执行（执行崩溃 → tool_crash）
        try:
            result = tool.run(parsed, context)
        except Exception as exc:  # noqa: BLE001
            return _fail(f"{type(exc).__name__}: {exc}", "tool_crash")

        # 阶段 3：输出归一化与截断
        if result.output is None:
            result.output = ""
        limit = tool.metadata.max_result_size_chars
        if len(result.output) > limit:
            omitted = len(result.output) - limit
            result.output = result.output[:limit] + f"\n... [{omitted} chars omitted]"
            result.metadata["truncated"] = True

        # 阶段 4：工具自身返回的失败（如 not_found）也补上恢复建议
        if not result.ok and result.error_code and "recovery_hint" not in result.metadata:
            result.metadata["recovery_hint"] = recovery_hint_for(result.error_code)
        return result

    def add_disposer(self, disposer: Callable[[], Any]) -> None:
        """追加一个 dispose 回调（MCP 进程清理等）。"""
        self._disposers.append(disposer)

    def dispose(self) -> None:
        for disposer in self._disposers:
            disposer()
