"""Day 21: CLI 与 Headless 共用同一个 Runtime 装配。"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from day04_scripted_model import ScriptedModel
from day05_tool_registry import ToolRegistry
from day07_agent_loop import run_agent_turn


@dataclass(slots=True)
class Runtime:
    cwd: str
    model: ScriptedModel
    tools: ToolRegistry

    def run(self, prompt: str) -> str:
        messages = run_agent_turn(self.model, self.tools, [{"role": "user", "content": prompt}], self.cwd)
        return str(messages[-1].get("content", ""))


class RuntimeFactory:
    def __init__(self, model_builder, tool_builder) -> None:
        self.model_builder, self.tool_builder = model_builder, tool_builder

    def create(self, cwd: str) -> Runtime:
        normalized = str(Path(cwd).resolve())
        return Runtime(normalized, self.model_builder(), self.tool_builder(normalized))


def run_headless(factory: RuntimeFactory, prompt: str, cwd: str) -> tuple[int, str]:
    try:
        response = factory.create(cwd).run(prompt)
        return 0, response
    except PermissionError as exc:
        return 3, f"permission denied: {exc}"
    except Exception as exc:
        return 1, f"runtime error: {exc}"


if __name__ == "__main__":
    from day04_scripted_model import demo_model
    from day06_readonly_tools import LIST_FILES, READ_FILE

    factory = RuntimeFactory(demo_model, lambda _: ToolRegistry([LIST_FILES, READ_FILE]))
    code, response = run_headless(factory, "解释课件", str(Path(__file__).parents[1]))
    assert code == 0
    print(response)

