"""minicode 的权限系统：类型化权限请求与决策（Day 11 第 1 步：数据模型）。

这是「模型想做」与「程序允许做」之间硬边界的类型基础。Day 9 已强调
「Prompt 不是授权」——提示词只是对模型的请求，模型可能遵守也可能不遵守；
真正的授权必须在这里以结构化类型强制发生，而不是靠自然语言约定。

本文件只定义「形状」（请求长什么样、决策长什么样、有哪些模式/风险等级），
不包含任何决策逻辑。决策逻辑（PermissionManager.check）在下一步实现。
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Callable, Literal

from minicode.logging_config import log_permission_check


class Mode(str, Enum):
    """四种运行模式，决定权限层对「有副作用动作」的默认态度。

    plan    只读：执行与写入直接阻止，仅允许安全读取
    default 每个有副作用动作都询问用户
    auto    明确安全的读取自动通过，中高风险仍询问或阻止
    bypass  跳过审批，仅用于用户明确授权的隔离环境
    """

    PLAN = "plan"
    DEFAULT = "default"
    AUTO = "auto"
    BYPASS = "bypass"


class RiskLevel(str, Enum):
    """风险等级，从安全到危险五档。

    风险等级是「审批决策的信号」，不是 OS 沙箱——一个被标为 safe 的 Python
    脚本仍可能访问任意系统资源（见课件「为什么正则风险检查不等于沙箱」）。
    """

    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    DANGEROUS = "dangerous"


class PermissionKind(str, Enum):
    """三条授权线：每条线的授权最小粒度不同（见课件「三个判断对象」）。"""

    PATH = "path"        # 是否允许读/写某个路径（规范路径 + intent）
    COMMAND = "command"  # 是否允许启动某命令（executable + argv + cwd + 风险原因）
    EDIT = "edit"        # 是否接受某份具体修改（文件路径 + diff + 范围）


# 六种决策。交互式产品至少需要这六种，才能表达「一次性 / 本轮 / 永久」的
# 允许，与「一次性 / 带反馈 / 永久」的拒绝。值用字符串字面量，便于序列化
# 进日志、也便于与 UI 层交互。
Verdict = Literal[
    "allow_once",          # 允许这一次
    "allow_turn",          # 本轮内对同一 scope 允许
    "allow_always",        # 永久允许（必须绑定明确 scope，不能放开整个磁盘）
    "deny_once",           # 拒绝这一次
    "deny_with_feedback",  # 拒绝，并把原因送回模型上下文
    "deny_always",         # 永久拒绝
]


@dataclass(frozen=True, slots=True)
class PermissionRequest:
    """一条待审批的权限请求。

    scope 是授权的「目标」，随 kind 不同含义不同：
      - path     → 规范化的绝对路径
      - command  → executable + argv 的可读表示
      - edit     → 文件路径 + diff 标识
    用 frozen：请求一旦发出不可被中途篡改（防止审批对象和实际执行对象不一致）。
    """

    kind: PermissionKind
    scope: str
    summary: str
    risk: RiskLevel


@dataclass(frozen=True, slots=True)
class PermissionDecision:
    """一条权限决策：裁决 + 可选反馈。

    feedback 用于 deny_with_feedback——它进入模型上下文（告诉模型为什么被拒、
    该怎么改），但绝不改变权限配置本身（见课件验收「deny_with_feedback 的文字
    进入模型上下文，但不会改变权限配置」）。
    """

    verdict: Verdict
    feedback: str = ""


class PermissionManager:
    """权限决策器：把 PermissionRequest 映射成 PermissionDecision。

    决策顺序（为什么是这个顺序，见每个分支的行内注释）：
      1. bypass 跳过一切审批；
      2. plan 只读硬约束（非安全读取直接拒绝）；
      3. 已记忆的永久拒绝（deny_always）优先于允许；
      4. 已记忆的永久允许（allow_always）；
      5. 本轮已允许（allow_turn）；
      6. auto 模式对安全/低风险自动放行；
      7. 无交互 prompt 时默认拒绝（绝不永久等待）；
      8. 询问用户，并按需记忆本轮/永久决策。
    """

    def __init__(
        self,
        workspace: str,
        mode: Mode = Mode.DEFAULT,
        prompt: Callable[[PermissionRequest], PermissionDecision] | None = None,
    ) -> None:
        # 工作区路径解析为规范绝对路径：供路径授权（第 4 步）判断「是否在工作区内」。
        self.workspace = Path(workspace).resolve()
        self.mode = mode
        self.prompt = prompt
        # 三种授权寿命的记忆（scope 用 (kind, scope) 二元组，避免同名文件/命令互相混淆）：
        self._turn_scopes: set[tuple[PermissionKind, str]] = set()    # 本轮 allow_turn
        self._session_allow: set[tuple[PermissionKind, str]] = set()  # 会话 allow_always
        self._session_deny: set[tuple[PermissionKind, str]] = set()   # 会话 deny_always
        # 注：persistent（跨进程持久化到配置文件）留到后续 Day，本步只做进程内记忆。

    def check(self, request: PermissionRequest) -> PermissionDecision:
        """对请求做决策，并把决策写入脱敏日志。"""
        decision = self._decide(request)
        log_permission_check(
            kind=request.kind.value,
            target=request.scope,
            verdict=decision.verdict,
            risk=request.risk.value,
            feedback=decision.feedback,
        )
        return decision

    def _decide(self, request: PermissionRequest) -> PermissionDecision:
        """纯决策逻辑：按模式、记忆、prompt 返回决策（不写日志，便于单测）。"""
        key = (request.kind, request.scope)

        # 1. bypass：用户明确授权的隔离环境，跳过一切审批。
        if self.mode is Mode.BYPASS:
            return PermissionDecision(verdict="allow_once")

        # 2. plan：只读硬约束。只有「安全/低风险的路径读取」放行，其余（写入、
        #    命令、编辑）一律拒绝。放在记忆检查之前，是因为 plan 是比「之前
        #    授权过写文件」更强的约束——即使会话里 allow_always 过，plan 下仍阻止。
        if self.mode is Mode.PLAN:
            is_safe_read = request.kind is PermissionKind.PATH and request.risk in {
                RiskLevel.SAFE,
                RiskLevel.LOW,
            }
            # 安全读取直接放行；否则直接拒绝（都不能落到后面的默认拒绝分支）。
            return PermissionDecision(
                verdict="allow_once" if is_safe_read else "deny_once"
            )

        # 3. 永久拒绝优先于允许：deny_always 一旦记录，同 scope 永不再放行。
        if key in self._session_deny:
            return PermissionDecision(verdict="deny_always")

        # 4. 永久允许：allow_always 记录的 scope 直接放行（返回 allow_once，因为
        #    「永久」体现在记忆里，单次裁决仍是「允许这一次」）。
        if key in self._session_allow:
            return PermissionDecision(verdict="allow_once")

        # 5. 本轮已允许：allow_turn 记录的 scope，本轮内直接放行。
        if key in self._turn_scopes:
            return PermissionDecision(verdict="allow_once")

        # 6. auto：明确安全的读取自动通过，中高风险仍需询问/阻止。
        if self.mode is Mode.AUTO and request.risk in {RiskLevel.SAFE, RiskLevel.LOW}:
            return PermissionDecision(verdict="allow_once")

        # 7. 无交互 prompt：默认拒绝，而不是永久等待。否则 headless/CI 环境会挂死。
        if self.prompt is None:
            return PermissionDecision(verdict="deny_once")

        # 8. 询问用户，并按决策寿命记忆。
        decision = self.prompt(request)
        if decision.verdict == "allow_turn":
            self._turn_scopes.add(key)
        elif decision.verdict == "allow_always":
            self._session_allow.add(key)
        elif decision.verdict == "deny_always":
            self._session_deny.add(key)
        # deny_once / deny_with_feedback 不记忆：前者一次性、后者只送反馈不改配置。
        return decision

    def begin_turn(self) -> None:
        """新的一轮开始时调用，清空本轮（allow_turn）授权。

        会话级（allow_always / deny_always）授权跨轮保留，不在此清空。
        """
        self._turn_scopes.clear()
