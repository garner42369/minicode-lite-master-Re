"""minicode 的控制论消融（Day 29）。合成画像对比 baseline vs cybernetic。

不调真实模型——用合成任务画像跑两个「臂」：
- baseline：固定阈值（Day 28 的 ThresholdController），无 PID 调节；
- cybernetic：PID 上下文控制（Day 28 的 PIDContextController）。

比溢出次数（稳定）、压缩次数（省资源）、最终占用。回答「自动调整有没有更稳定、更省
资源」。大概率结论：阈值够用，PID 默认关闭（这正是消融要证明的，而不是假设）。
"""

from __future__ import annotations

from dataclasses import dataclass

from minicode.context_cybernetics import PIDContextController, ThresholdController, simulate


@dataclass(frozen=True, slots=True)
class AblationProfile:
    task_id: str
    turns: int = 20
    growth_per_turn: float = 0.05


@dataclass(frozen=True, slots=True)
class ArmResult:
    arm: str          # baseline / cybernetic
    overflows: int
    compactions: int
    final_usage: float


@dataclass(frozen=True, slots=True)
class AblationReport:
    profiles: list[AblationProfile]
    results: list[ArmResult]
    delta: dict


def run_ablation(profiles: list[AblationProfile]) -> AblationReport:
    """跑 baseline vs cybernetic 两臂，输出汇总 delta。"""
    results: list[ArmResult] = []
    for profile in profiles:
        b = simulate(ThresholdController(), profile.turns, profile.growth_per_turn)
        c = simulate(PIDContextController(), profile.turns, profile.growth_per_turn)
        results.append(ArmResult("baseline", b.overflows, b.compactions, b.final_usage))
        results.append(ArmResult("cybernetic", c.overflows, c.compactions, c.final_usage))
    return AblationReport(profiles, results, _summarize(results))


def _summarize(results: list[ArmResult]) -> dict:
    by_arm: dict[str, list[ArmResult]] = {"baseline": [], "cybernetic": []}
    for r in results:
        by_arm[r.arm].append(r)

    def avg(key: str, arm: str) -> float:
        items = by_arm[arm]
        return sum(getattr(r, key) for r in items) / len(items) if items else 0.0

    return {
        "baseline": {
            "overflows": avg("overflows", "baseline"),
            "compactions": avg("compactions", "baseline"),
            "final_usage": round(avg("final_usage", "baseline"), 3),
        },
        "cybernetic": {
            "overflows": avg("overflows", "cybernetic"),
            "compactions": avg("compactions", "cybernetic"),
            "final_usage": round(avg("final_usage", "cybernetic"), 3),
        },
        "delta_cybernetic_minus_baseline": {
            "overflows": avg("overflows", "cybernetic") - avg("overflows", "baseline"),
            "compactions": avg("compactions", "cybernetic") - avg("compactions", "baseline"),
            "final_usage": round(avg("final_usage", "cybernetic") - avg("final_usage", "baseline"), 3),
        },
    }
