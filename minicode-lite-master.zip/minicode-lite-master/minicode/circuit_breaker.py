"""压缩熔断：连续压缩失败时停止反复压缩，防止死循环（Day 18）。

参考 Claude Code 的 auto-compact 熔断（连续 3 次失败 → 阻断直到手动重置）。

为什么确定性压缩也需要熔断：我们的 compact_messages 不调 LLM、不抛异常，但
「压缩失败」的另一种形态是「压了也没用」——历史里有超大消息（如未截断的大
tool_result），压缩后 usage 仍超阈值，下一轮又触发压缩，形成「每轮都压但压不
下来」的死循环。熔断在连续失败达阈值后阻断压缩，改用保底截断，保证有限次结束。
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass


@dataclass
class CircuitBreakerConfig:
    """熔断配置。"""

    failure_threshold: int = 3      # 连续失败多少次后熔断
    auto_reset_seconds: float = 0.0  # 熔断后多久自动重置；0 = 永不自动重置


@dataclass
class CircuitBreakerState:
    """内部状态快照（供观测）。"""

    consecutive_failures: int = 0
    is_open: bool = False
    total_failures: int = 0
    total_successes: int = 0
    opened_at: float | None = None


class CompactionCircuitBreaker:
    """追踪压缩尝试，连续失败达阈值后阻断。"""

    def __init__(self, config: CircuitBreakerConfig | None = None) -> None:
        self.config = config or CircuitBreakerConfig()
        self._state = CircuitBreakerState()
        self._lock = threading.Lock()

    def record_success(self) -> None:
        """记录一次成功的压缩（清零连续失败计数）。"""
        with self._lock:
            self._state.consecutive_failures = 0
            self._state.total_successes += 1

    def record_failure(self) -> None:
        """记录一次失败的压缩，可能打开熔断。"""
        with self._lock:
            self._state.consecutive_failures += 1
            self._state.total_failures += 1
            if self._state.consecutive_failures >= self.config.failure_threshold:
                self._state.is_open = True
                self._state.opened_at = time.time()

    def is_allowed(self) -> bool:
        """当前是否允许压缩。熔断后除非自动重置，否则一直阻断。"""
        with self._lock:
            if not self._state.is_open:
                return True
            if (
                self.config.auto_reset_seconds > 0
                and self._state.opened_at is not None
                and time.time() - self._state.opened_at >= self.config.auto_reset_seconds
            ):
                self._reset()
                return True
            return False

    def reset(self) -> None:
        """手动重置熔断，回到闭合状态。"""
        with self._lock:
            self._reset()

    def _reset(self) -> None:
        """内部重置（调用方需持有 _lock）。"""
        self._state.consecutive_failures = 0
        self._state.is_open = False
        self._state.opened_at = None
