"""minicode 的 MCP 客户端（Day 24）。

MCP（Model Context Protocol）让 minicode 发现外部工具/资源/提示词。今天实现 stdio
客户端：懒启动、双协议（content-length / newline-json）auto-detect、request ID 关联、
reader/stderr 独立线程、超时、断线与关闭。

关键约束：MCP Tool Wrapper 仍然是 `ToolDefinition`——同样的参数校验、权限、截断、日志
和 Session 记录，Loop 不直接调用 MCP Client（课件「MCP 在架构中的位置」）。

安全（裁剪版，用户拍板）：
- 项目级 `.mcp.json` 默认不信任（enabled 默认 False，需显式启用）；
- 参数做 shell 元字符检查（Windows 上 .cmd 批处理包装器需 shell=True，防注入）；
- 不做硬编码命令白名单（参考项目的 ALLOWED_COMMANDS 太绑定其部署环境）。
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
from dataclasses import asdict, dataclass
from pathlib import Path
from queue import Empty, Queue
from typing import Any, Callable

from minicode.tooling import ToolCapability, ToolDefinition, ToolMetadata, ToolResult

# shell 元字符：Windows 上 .cmd 需 shell=True，参数必须先过滤这些字符防注入
_DANGEROUS_SHELL_CHARS = set('|&;`$(){}<>\n\r')

# MCP 消息体大小上限（防恶意服务端制造 OOM）
_MAX_MCP_PAYLOAD_BYTES = 50 * 1024 * 1024  # 50 MB

# Windows 可执行后缀（npx.cmd 等批处理包装器，判断时剥离）
_WIN_EXEC_EXTS = (".exe", ".cmd", ".bat")


@dataclass(slots=True)
class McpServerSummary:
    """一个 MCP server 的可观测摘要（供 prompt / readiness 展示）。"""

    name: str
    command: str
    status: str  # disabled / pending / connected / error
    toolCount: int = 0
    error: str = ""
    protocol: str = ""
    resourceCount: int = 0
    promptCount: int = 0


def _sanitize_tool_segment(value: str) -> str:
    """把 server/tool 名规范成工具名里可用的段（字母数字下划线，其余转下划线）。"""
    normalized = "".join(c.lower() if c.isalnum() or c in {"_", "-"} else "_" for c in value)
    return normalized.strip("_") or "tool"


def _validate_mcp_args(args: list[str]) -> None:
    """参数不得含 shell 元字符——因为 Windows 上 .cmd 批处理包装器要用 shell=True 启动。"""
    for arg in args:
        for char in arg:
            if char in _DANGEROUS_SHELL_CHARS:
                raise RuntimeError(
                    f"Invalid MCP argument: contains dangerous shell character '{char}'."
                )


def _prepare_spawn(command: str, args: list[str]) -> tuple[list[str] | str, dict]:
    """把命令解析成 subprocess 可启动的形式。

    Windows 上 npx/npm 等是 .cmd 批处理包装器，subprocess 在 shell=False 时走
    CreateProcess，既不能直接运行 .cmd 也不会按 PATHEXT 搜索。这里用 shutil.which
    解析真实可执行文件，批处理包装器经 cmd.exe（shell=True）启动。参数已过
    _validate_mcp_args 校验不含 shell 元字符，故 shell=True 安全。
    """
    if os.name == "nt":
        resolved = shutil.which(command)
        if resolved:
            if resolved.lower().endswith((".cmd", ".bat")):
                return subprocess.list2cmdline([resolved, *args]), {"shell": True}
            return [resolved, *args], {}
    return [command, *args], {}


def _normalize_input_schema(schema: dict[str, Any] | None) -> dict[str, Any]:
    return schema if isinstance(schema, dict) else {"type": "object", "additionalProperties": True}


def _format_content_block(block: Any) -> str:
    if not isinstance(block, dict):
        return json.dumps(block, indent=2, ensure_ascii=False)
    if block.get("type") == "text" and "text" in block:
        return str(block["text"])
    return json.dumps(block, indent=2, ensure_ascii=False)


def _format_tool_call_result(result: Any) -> ToolResult:
    """把 tools/call 的返回转成 ToolResult。isError 决定 ok，content 块拼成文本。"""
    if not isinstance(result, dict):
        return ToolResult(ok=True, output=json.dumps(result, indent=2, ensure_ascii=False))
    parts: list[str] = []
    content = result.get("content")
    if isinstance(content, list) and content:
        parts.append("\n\n".join(_format_content_block(block) for block in content))
    if "structuredContent" in result:
        parts.append("STRUCTURED_CONTENT:\n" + json.dumps(result["structuredContent"], indent=2, ensure_ascii=False))
    if not parts:
        parts.append(json.dumps(result, indent=2, ensure_ascii=False))
    return ToolResult(ok=not bool(result.get("isError")), output="\n\n".join(parts).strip())


def _format_read_resource_result(result: Any) -> ToolResult:
    if not isinstance(result, dict):
        return ToolResult(ok=False, output=json.dumps(result, indent=2, ensure_ascii=False))
    contents = result.get("contents", [])
    if not contents:
        return ToolResult(ok=True, output="No resource contents returned.")
    rendered: list[str] = []
    for item in contents:
        header_lines = [f"URI: {item.get('uri', '(unknown)')}"]
        if item.get("mimeType"):
            header_lines.append(f"MIME: {item['mimeType']}")
        header = "\n".join(header_lines) + "\n\n"
        if isinstance(item.get("text"), str):
            rendered.append(header + item["text"])
        elif isinstance(item.get("blob"), str):
            rendered.append(header + "BLOB:\n" + item["blob"])
        else:
            rendered.append(header + json.dumps(item, indent=2, ensure_ascii=False))
    return ToolResult(ok=True, output="\n\n".join(rendered))


def _format_prompt_result(result: Any) -> ToolResult:
    if not isinstance(result, dict):
        return ToolResult(ok=False, output=json.dumps(result, indent=2, ensure_ascii=False))
    header = f"DESCRIPTION: {result['description']}\n\n" if result.get("description") else ""
    body_parts: list[str] = []
    for message in result.get("messages", []):
        role = message.get("role", "unknown")
        content = message.get("content")
        if isinstance(content, str):
            rendered = content
        elif isinstance(content, list):
            rendered = "\n".join(
                str(part["text"]) if isinstance(part, dict) and "text" in part
                else json.dumps(part, indent=2, ensure_ascii=False)
                for part in content
            )
        else:
            rendered = json.dumps(content, indent=2, ensure_ascii=False)
        body_parts.append(f"[{role}]\n{rendered}")
    return ToolResult(ok=True, output=(header + "\n\n".join(body_parts)).strip() or json.dumps(result, indent=2, ensure_ascii=False))


class StdioMcpClient:
    """懒启动的 stdio MCP 客户端。

    进程不预先 spawn，第一次 request（如 list_tools）时才 spawn + initialize。
    双协议 auto-detect：reader 线程看首行是否以 ``Content-Length:`` 开头决定帧格式。
    """

    def __init__(self, server_name: str, config: dict[str, Any], cwd: str) -> None:
        self.server_name = server_name
        self.config = config
        self.cwd = cwd
        self.process: subprocess.Popen[bytes] | None = None
        self.protocol: str | None = None
        self.next_id = 1
        self._pending: dict[int, Queue[Any]] = {}
        self._lock = threading.Lock()
        self.stderr_lines: list[str] = []
        self._stderr_thread: threading.Thread | None = None
        self._stdout_thread: threading.Thread | None = None
        self._started = False
        self._start_error: str | None = None
        self._tools_cache: list[dict[str, Any]] | None = None
        self._resources_cache: list[dict[str, Any]] | None = None
        self._prompts_cache: list[dict[str, Any]] | None = None

    @property
    def is_started(self) -> bool:
        return self._started

    @property
    def start_error(self) -> str | None:
        return self._start_error

    def _protocol_candidates(self) -> list[str]:
        configured = self.config.get("protocol")
        if configured == "content-length":
            return ["content-length"]
        if configured == "newline-json":
            return ["newline-json"]
        return ["content-length", "newline-json"]

    def start(self) -> None:
        """启动进程并做 initialize 握手（幂等；失败重置以便重试）。"""
        if self._started:
            return
        last_error: Exception | None = None
        for protocol in self._protocol_candidates():
            try:
                self._spawn_process()
                self.protocol = protocol
                self.request(
                    "initialize",
                    {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "minicode", "version": "0.1.0"},
                    },
                    timeout_seconds=3.0,
                )
                self.notify("notifications/initialized", {})
                self._started = True
                self._start_error = None
                return
            except Exception as error:  # noqa: BLE001
                last_error = error
                self.close()
        self._start_error = str(last_error or f'Failed to connect MCP server "{self.server_name}".')
        raise RuntimeError(self._start_error)

    def _ensure_started(self) -> None:
        if self._started and not self._is_process_alive():
            self.close()
        if not self._started:
            self.start()

    def _is_process_alive(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def _spawn_process(self) -> None:
        command = str(self.config.get("command", "")).strip()
        if not command:
            raise RuntimeError(f'MCP server "{self.server_name}" has no command configured.')

        _validate_mcp_args(list(self.config.get("args", []) or []))

        process_cwd = Path(self.cwd)
        if self.config.get("cwd"):
            process_cwd = (process_cwd / str(self.config["cwd"])).resolve()
        env = os.environ.copy()
        for key, value in dict(self.config.get("env", {}) or {}).items():
            env[str(key)] = str(value)

        popen_kwargs: dict = {}
        if os.name == "nt":
            popen_kwargs["creationflags"] = 0x08000000  # CREATE_NO_WINDOW，避免子进程弹窗

        spawn_exec, spawn_extra = _prepare_spawn(command, list(self.config.get("args", []) or []))
        popen_kwargs.update(spawn_extra)
        try:
            self.process = subprocess.Popen(  # noqa: S603
                spawn_exec,
                cwd=str(process_cwd),
                env=env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                bufsize=0,
                **popen_kwargs,
            )
        except FileNotFoundError:
            raise RuntimeError(f"Command not found: {command}.") from None

        self.stderr_lines = []
        with self._lock:
            self._pending = {}
        self._stderr_thread = threading.Thread(target=self._consume_stderr, daemon=True)
        self._stderr_thread.start()

    def _consume_stderr(self) -> None:
        assert self.process is not None and self.process.stderr is not None
        for line in self.process.stderr:
            try:
                text = line.decode("utf-8", errors="replace").strip()
                if text:
                    self.stderr_lines.append(text)
                    self.stderr_lines = self.stderr_lines[-8:]
            except Exception:
                continue

    def _ensure_stdout_thread(self) -> None:
        if self._stdout_thread is None:
            self._stdout_thread = threading.Thread(target=self._consume_stdout, daemon=True)
            self._stdout_thread.start()

    def _consume_stdout(self) -> None:
        assert self.process is not None and self.process.stdout is not None
        try:
            while True:
                line_bytes = self.process.stdout.readline()
                if not line_bytes:
                    break
                try:
                    line = line_bytes.decode("utf-8")
                except UnicodeDecodeError:
                    continue
                stripped = line.strip()
                if not stripped:
                    continue
                if len(line_bytes) > _MAX_MCP_PAYLOAD_BYTES:
                    self.stderr_lines.append(f"MCP payload too large: {len(line_bytes)} bytes")
                    continue

                # 协议探测：未定时看首行是否 Content-Length 头
                if self.protocol is None:
                    self.protocol = "content-length" if stripped.lower().startswith("content-length:") else "newline-json"

                if self.protocol == "newline-json":
                    try:
                        self._handle_message(json.loads(stripped))
                    except json.JSONDecodeError:
                        continue
                else:
                    header_lines = [line.rstrip("\r\n")]
                    while True:
                        next_line_bytes = self.process.stdout.readline()
                        if not next_line_bytes:
                            return
                        try:
                            next_line = next_line_bytes.decode("utf-8")
                        except UnicodeDecodeError:
                            return
                        if next_line.rstrip("\r\n") == "":
                            break
                        header_lines.append(next_line.rstrip("\r\n"))

                    content_length = 0
                    for header in header_lines:
                        if header.lower().startswith("content-length:"):
                            try:
                                content_length = int(header.split(":", 1)[1].strip())
                            except ValueError:
                                pass
                            break
                    if content_length > _MAX_MCP_PAYLOAD_BYTES:
                        self.stderr_lines.append(f"MCP payload too large: {content_length} bytes")
                        continue
                    if content_length > 0:
                        body_bytes = self.process.stdout.read(content_length)
                        if len(body_bytes) < content_length:
                            return
                        try:
                            self._handle_message(json.loads(body_bytes.decode("utf-8")))
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            pass
        finally:
            # 进程退出：让所有 pending 请求失败，不永久挂起
            if self.process is not None:
                exit_code = self.process.poll()
                error_msg = {"error": {"code": -1, "message": f"MCP server process exited (code={exit_code})"}}
                with self._lock:
                    for q in list(self._pending.values()):
                        q.put(error_msg)
                    self._pending.clear()

    def _handle_message(self, message: dict[str, Any]) -> None:
        message_id = message.get("id")
        if not isinstance(message_id, int):
            return
        with self._lock:
            queue = self._pending.pop(message_id, None)
            if queue is not None:
                queue.put(message)

    def send(self, message: dict[str, Any]) -> None:
        if self.process is None or self.process.stdin is None:
            raise RuntimeError(f'MCP server "{self.server_name}" is not running.')
        payload_bytes = json.dumps(message, ensure_ascii=False).encode("utf-8")
        if self.protocol == "newline-json":
            self.process.stdin.write(payload_bytes + b"\n")
        else:
            header = f"Content-Length: {len(payload_bytes)}\r\n\r\n".encode("utf-8")
            self.process.stdin.write(header + payload_bytes)
        self.process.stdin.flush()
        self._ensure_stdout_thread()

    def notify(self, method: str, params: Any) -> None:
        self.send({"jsonrpc": "2.0", "method": method, "params": params})

    def request(self, method: str, params: Any, timeout_seconds: float = 5.0) -> Any:
        message_id = self.next_id
        self.next_id += 1
        response_queue: Queue[Any] = Queue(maxsize=1)
        with self._lock:
            self._pending[message_id] = response_queue
        self.send({"jsonrpc": "2.0", "id": message_id, "method": method, "params": params})
        try:
            message = response_queue.get(timeout=timeout_seconds)
        except Empty as error:
            with self._lock:
                self._pending.pop(message_id, None)
            stderr = "\n".join(self.stderr_lines)
            raise RuntimeError(
                f"MCP {self.server_name}: request timed out for {method}" + (f"\n{stderr}" if stderr else "")
            ) from error
        if message.get("error"):
            raise RuntimeError(f"MCP {self.server_name}: {message['error']['message']}")
        return message.get("result")

    def list_tools(self) -> list[dict[str, Any]]:
        if self._tools_cache is not None:
            return self._tools_cache
        self._ensure_started()
        result = self.request("tools/list", {})
        self._tools_cache = list(result.get("tools", []) if isinstance(result, dict) else [])
        return self._tools_cache

    def list_resources(self) -> list[dict[str, Any]]:
        if self._resources_cache is not None:
            return self._resources_cache
        self._ensure_started()
        result = self.request("resources/list", {}, timeout_seconds=3.0)
        self._resources_cache = list(result.get("resources", []) if isinstance(result, dict) else [])
        return self._resources_cache

    def read_resource(self, uri: str) -> ToolResult:
        self._ensure_started()
        return _format_read_resource_result(self.request("resources/read", {"uri": uri}))

    def list_prompts(self) -> list[dict[str, Any]]:
        if self._prompts_cache is not None:
            return self._prompts_cache
        self._ensure_started()
        result = self.request("prompts/list", {}, timeout_seconds=3.0)
        self._prompts_cache = list(result.get("prompts", []) if isinstance(result, dict) else [])
        return self._prompts_cache

    def get_prompt(self, name: str, args: dict[str, str] | None = None) -> ToolResult:
        self._ensure_started()
        return _format_prompt_result(self.request("prompts/get", {"name": name, "arguments": args or {}}))

    def call_tool(self, name: str, input_data: Any) -> ToolResult:
        self._ensure_started()
        return _format_tool_call_result(self.request("tools/call", {"name": name, "arguments": input_data or {}}))

    def close(self) -> None:
        with self._lock:
            pending = list(self._pending.values())
            self._pending.clear()
            for queue in pending:
                queue.put({"error": {"message": f'MCP server "{self.server_name}" closed.'}})

        if self.process is not None:
            try:
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
            except OSError:
                pass
            finally:
                self.process = None

        self.protocol = None
        self._stdout_thread = None
        self._stderr_thread = None
        self._started = False
        self._tools_cache = None
        self._resources_cache = None
        self._prompts_cache = None


def load_mcp_servers(cwd: str | Path) -> dict[str, dict[str, Any]]:
    """从项目级 ``.mcp.json`` 加载 MCP 服务器配置。

    项目级配置默认不信任：每个 server 的 ``enabled`` 默认 False，只有显式写
    ``"enabled": true`` 才启用。文件不存在或解析失败返回空 dict（不抛异常）。
    """
    path = Path(cwd) / ".mcp.json"
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    raw_servers = data.get("mcpServers", {}) if isinstance(data, dict) else {}
    if not isinstance(raw_servers, dict):
        return {}
    result: dict[str, dict[str, Any]] = {}
    for name, cfg in raw_servers.items():
        if not isinstance(cfg, dict):
            continue
        item = dict(cfg)
        item.setdefault("enabled", False)  # 默认不信任
        result[str(name)] = item
    return result


def create_mcp_backed_tools(*, cwd: str, mcp_servers: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """把 MCP server 的工具/资源/提示词包装成内部 ToolDefinition。

    懒启动：进程不预先 spawn，装配时尝试 list_tools 触发首次 spawn，失败降级 error
    状态（不抛异常、不阻塞其他 server）。工具名用 ``mcp__server__tool`` 前缀隔离。
    """
    clients: list[StdioMcpClient] = []
    tools: list[ToolDefinition] = []
    servers: list[dict[str, Any]] = []
    resource_index: dict[str, dict[str, Any]] = {}
    prompt_index: dict[str, dict[str, Any]] = {}

    for server_name, config in mcp_servers.items():
        if config.get("enabled") is False:
            servers.append(asdict(McpServerSummary(name=server_name, command=config.get("command", ""), status="disabled")))
            continue

        client = StdioMcpClient(server_name, config, cwd)
        clients.append(client)
        servers.append(asdict(McpServerSummary(
            name=server_name, command=config.get("command", ""), status="pending",
            protocol=config.get("protocol", ""),
        )))

        try:
            descriptors = client.list_tools()
            try:
                resources = client.list_resources()
            except Exception:  # noqa: BLE001
                resources = []
            try:
                prompts = client.list_prompts()
            except Exception:  # noqa: BLE001
                prompts = []

            for resource in resources:
                resource_index[f"{server_name}:{resource.get('uri')}"] = {"serverName": server_name, "resource": resource}
            for prompt in prompts:
                prompt_index[f"{server_name}:{prompt.get('name')}"] = {"serverName": server_name, "prompt": prompt}

            for descriptor in descriptors:
                descriptor_name = str(descriptor.get("name", "tool"))
                wrapped_name = f"mcp__{_sanitize_tool_segment(server_name)}__{_sanitize_tool_segment(descriptor_name)}"
                input_schema = _normalize_input_schema(descriptor.get("inputSchema"))

                def _validator(value: Any) -> Any:
                    return value if isinstance(value, dict) else {}

                def _run(input_data: Any, _context, *, _client=client, _name=descriptor_name) -> ToolResult:
                    return _client.call_tool(_name, input_data)

                tools.append(ToolDefinition(
                    validator=_validator,
                    run=_run,
                    metadata=ToolMetadata(
                        name=wrapped_name,
                        description=str(descriptor.get("description") or f"Call MCP tool {descriptor_name} from server {server_name}."),
                        input_schema=input_schema,
                    ),
                ))

            for i, s in enumerate(servers):
                if s["name"] == server_name:
                    servers[i] = asdict(McpServerSummary(
                        name=server_name, command=config.get("command", ""), status="connected",
                        toolCount=len(descriptors), protocol=client.protocol or "",
                        resourceCount=len(resources), promptCount=len(prompts),
                    ))
                    break
        except Exception as error:  # noqa: BLE001
            for i, s in enumerate(servers):
                if s["name"] == server_name:
                    servers[i] = asdict(McpServerSummary(
                        name=server_name, command=config.get("command", ""), status="error",
                        error=str(error)[:200], protocol=config.get("protocol", ""),
                    ))
                    break

    # 资源网关工具
    if resource_index:
        def _list_resources(input_data: dict, _context) -> ToolResult:
            rows = [
                f"{entry['serverName']}: {entry['resource'].get('uri')}"
                + (f" ({entry['resource'].get('name')})" if entry["resource"].get("name") else "")
                + (f" - {entry['resource'].get('description')}" if entry["resource"].get("description") else "")
                for entry in resource_index.values()
                if not input_data.get("server") or entry["serverName"] == input_data["server"]
            ]
            return ToolResult(ok=True, output="\n".join(rows) or "No MCP resources available.")

        def _read_resource(input_data: dict, _context) -> ToolResult:
            client = next((c for c in clients if c.server_name == input_data["server"]), None)
            if client is None:
                return ToolResult(ok=False, output=f"Unknown MCP server: {input_data['server']}")
            return client.read_resource(input_data["uri"])

        tools.append(ToolDefinition(
            validator=lambda v: v if isinstance(v, dict) else {},
            run=_list_resources,
            metadata=ToolMetadata(
                name="list_mcp_resources", description="List available MCP resources.",
                input_schema={"type": "object", "properties": {"server": {"type": "string"}}},
                capabilities={ToolCapability.READ_ONLY},
            ),
        ))
        tools.append(ToolDefinition(
            validator=lambda v: v if isinstance(v, dict) else {},
            run=_read_resource,
            metadata=ToolMetadata(
                name="read_mcp_resource", description="Read an MCP resource by server and URI.",
                input_schema={"type": "object", "properties": {"server": {"type": "string"}, "uri": {"type": "string"}}, "required": ["server", "uri"]},
                capabilities={ToolCapability.READ_ONLY},
            ),
        ))

    # Prompt 网关工具
    if prompt_index:
        def _list_prompts(input_data: dict, _context) -> ToolResult:
            rows = [
                f"{entry['serverName']}: {entry['prompt'].get('name')}"
                + (f" - {entry['prompt'].get('description')}" if entry["prompt"].get("description") else "")
                for entry in prompt_index.values()
                if not input_data.get("server") or entry["serverName"] == input_data["server"]
            ]
            return ToolResult(ok=True, output="\n".join(rows) or "No MCP prompts available.")

        def _get_prompt(input_data: dict, _context) -> ToolResult:
            client = next((c for c in clients if c.server_name == input_data["server"]), None)
            if client is None:
                return ToolResult(ok=False, output=f"Unknown MCP server: {input_data['server']}")
            return client.get_prompt(input_data["name"], input_data.get("arguments"))

        tools.append(ToolDefinition(
            validator=lambda v: v if isinstance(v, dict) else {},
            run=_list_prompts,
            metadata=ToolMetadata(
                name="list_mcp_prompts", description="List available MCP prompts.",
                input_schema={"type": "object", "properties": {"server": {"type": "string"}}},
                capabilities={ToolCapability.READ_ONLY},
            ),
        ))
        tools.append(ToolDefinition(
            validator=lambda v: v if isinstance(v, dict) else {},
            run=_get_prompt,
            metadata=ToolMetadata(
                name="get_mcp_prompt", description="Fetch a rendered MCP prompt by server and name.",
                input_schema={"type": "object", "properties": {"server": {"type": "string"}, "name": {"type": "string"}, "arguments": {"type": "object"}}, "required": ["server", "name"]},
                capabilities={ToolCapability.READ_ONLY},
            ),
        ))

    def _dispose() -> None:
        for client in clients:
            client.close()

    return {"tools": tools, "servers": servers, "dispose": _dispose}
