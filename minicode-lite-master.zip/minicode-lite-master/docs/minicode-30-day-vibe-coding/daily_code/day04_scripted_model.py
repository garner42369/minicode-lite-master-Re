"""Day 4: 可检查输入历史的确定性 ScriptedModel。"""

from __future__ import annotations

from copy import deepcopy

from day02_protocols import AgentStep, ChatMessage, ToolCall


class ScriptedModel:
    def __init__(self, steps: list[AgentStep]) -> None:
        self._steps = iter(steps)
        self.received_messages: list[list[ChatMessage]] = []

    def next(self, messages: list[ChatMessage], on_stream_chunk=None) -> AgentStep:
        self.received_messages.append(deepcopy(messages))
        try:
            step = next(self._steps)
        except StopIteration as exc:
            raise RuntimeError("ScriptedModel steps exhausted") from exc
        if on_stream_chunk and step.content:
            on_stream_chunk(step.content)
        return step


def demo_model() -> ScriptedModel:
    return ScriptedModel([
        AgentStep(type="tool_calls", calls=[ToolCall("1", "list_files", {"path": "."})]),
        AgentStep(type="tool_calls", calls=[ToolCall("2", "read_file", {"path": "README.md"})]),
        AgentStep(type="assistant", kind="final", content="仓库入口已经确认。"),
    ])


if __name__ == "__main__":
    model = demo_model()
    messages: list[ChatMessage] = [{"role": "user", "content": "解释仓库"}]
    assert model.next(messages).calls[0].name == "list_files"
    assert model.next(messages).calls[0].name == "read_file"
    assert model.next(messages).content == "仓库入口已经确认。"
    print("scripted model: OK")

