"""Day 28：上下文闭环（基线 vs PID）的契约测试。"""

from minicode.context_cybernetics import (
    PIDContextController,
    ThresholdController,
    context_action,
    simulate,
)


class TestContextAction:
    def test_critical_usage_full_compact(self):
        a = context_action(usage_ratio=0.95, trend_per_turn=0.0, control=0.0)
        assert a.action == "full_compact"
        print(f"\n临界 usage: {a}")

    def test_high_usage_micro_compact(self):
        a = context_action(usage_ratio=0.8, trend_per_turn=0.0, control=0.0)
        assert a.action == "micro_compact"
        print(f"\n高 usage: {a}")

    def test_healthy_no_op(self):
        a = context_action(usage_ratio=0.5, trend_per_turn=0.0, control=0.0)
        assert a.action == "no_op"
        print(f"\n健康: {a}")


class TestSimulate:
    def test_baseline_vs_pid(self):
        # 同样的压力序列，比较基线（阈值）和 PID 的溢出/压缩
        baseline = ThresholdController()
        pid = PIDContextController()
        b = simulate(baseline, turns=20, growth_per_turn=0.05)
        p = simulate(pid, turns=20, growth_per_turn=0.05)
        print(f"\n基线: 溢出={b.overflows}, 压缩={b.compactions}, 动作={b.actions}")
        print(f"PID:  溢出={p.overflows}, 压缩={p.compactions}, 动作={p.actions}")
        # 两个策略都应避免大量溢出（稳定性），压缩次数合理（省资源）
        assert b.overflows <= 5
        assert p.overflows <= 5

    def test_deterministic(self):
        r1 = simulate(ThresholdController(), 20, 0.05)
        r2 = simulate(ThresholdController(), 20, 0.05)
        assert r1.actions == r2.actions
        print("\n模拟确定性")
