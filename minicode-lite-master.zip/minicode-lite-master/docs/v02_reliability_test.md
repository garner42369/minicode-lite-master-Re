# V0.2 可靠性验证报告（第二次集成测试）

> Day 20 核心能力阶段收官后，第二次用真实模型跑集成测试，验证 Day 14-20 的能力
> 闭环（压缩、工作记忆、项目记忆、记忆流水线），找 bad case 并解决。

## 测试环境

- **模型**：deepseek-v4-pro（真实 API）
- **工具集**：全工具集
- **权限**：auto 模式 + 自动允许（dangerous 默认 deny）
- **运行时**：`tests/v02_memory_harness.py`（预置项目记忆 + 真实模型跑任务）
- **意图识别**：LLM 分类（`classify_intent_with_model`），关键词 fallback

## 任务集

| # | 意图 | 指令 | 期望 | 主要观察 |
|---|------|------|------|----------|
| 1 | DEBUG | 修复 `divide` 整除 bug | `//`→`/`，测试通过 | 冒烟，基础闭环 |
| 2 | SEARCH | 这个项目怎么跑测试？ | 回答 pytest 命令，不触发验证 | 意图识别 + 收敛 |

## 逐个任务结果

### 任务 1：修复 divide 整除 bug ✅ 成功
- **结果**：`list_files → read_file → edit_file(// → /) → test_runner(2 passed) → done`
- **失败模式**：无
- **观察**：模型一开始用绝对路径读文件（cwd 已是 fixture 目录）返回 ok=False，第二次
  改用相对路径成功——模型自我纠正，非系统缺陷，但值得留意。

### 任务 2：怎么跑测试 ❌→✅（暴露两个 bad case，已修复）
- **第一轮**：`intent` 误判为 CODE → `verification_missing` 拦截 → 模型被迫跑测试、
  read_file、git diff 一堆操作 → `max_steps` 耗尽，最终回答是 pytest 输出而非答案。
- **修复 1（意图误判）**：`parse_intent("怎么跑测试")` 命中不了关键词（`_SEARCH_WORDS`
  有英文 `how` 但没有中文「怎么」），默认落到 CODE。→ 引入 **LLM 意图分类**
  （`classify_intent_with_model`，prompt 规范四种意图，关键词保留作 fallback）。
- **第二轮**：意图分类正确（SEARCH，不再触发验证），但模型读 README + test 文件后
  **执行 pytest**（run_command）而非「回答」，`max_steps=4` 耗尽，没来得及 final 报告。
- **修复 2（step 太小）**：见下方专项记录。
- **最终**：`SEARCH_MAX_STEPS` 调到 6 后，模型读文件 → 回答 pytest 命令 → 主动跑测试
  验证（2 passed），7 步收敛 `done`。

### 任务 3：怎么跑覆盖率测试（验证记忆召回）⚠️→✅
- **场景**：预置一条 **README 里没有**的记忆「CI 覆盖率测试命令是 pytest --cov
  --cov-report=term-missing」，问「怎么跑覆盖率测试」——记忆是唯一答案来源。
- **第一轮（prompt 强化前）**：模型 `grep 'cov'` + `pytest --version`，**完全不用记忆**，
  `max_steps` 耗尽，回答「pytest 8.1.1」而非覆盖率命令。
- **根因**：模型起初不重视注入的记忆（详见下方专项记录）。
- **第二轮（prompt 强化后）**：模型 `run_command('pytest --cov --cov-report=term-missing')`，
  **用上了记忆** ✅——记忆召回链路（检索 → 注入 → 模型利用）全部打通。
- **残留问题 → 已修复**：模型执行失败（pytest-cov 未装）后反复诊断（pip show / pytest
  --version / import pytest_cov 一连串），`max_steps` 耗尽。加「失败立即报告」prompt 引导
  后，模型报告「需要 pip install pytest-cov」并 `done` 收敛（见「失败收敛」专项记录）。

## 专项记录：模型起初不重视注入的记忆

### 现象

第一轮任务 3 里，记忆系统明明正确召回了「覆盖率测试命令」并注入（inject 返回了这条），
但模型**视而不见**，自己去 `grep 'cov'`、`pytest --version` 探索，最终没找到答案。

### 根因

prompt 里对注入记忆的描述太弱——「Pay attention to them — they may contain knowledge
useful」里的 `may contain` / `useful` 让模型把注入记忆当成「可能有点用的背景」，而非
「可信的事实」，于是倾向自己重新探索。

### 修复

prompt 强化为「These are trustworthy facts accumulated from past sessions — prefer
them over re-exploring files」——把注入记忆定位为「可信事实」，引导优先利用而非重新探索。

### 教训

记忆注入的价值在于「省去重新探索」。但注入 ≠ 被利用——模型不信任/不重视时，注入的记忆
形同虚设。所以注入的**定位措辞**很关键：是「背景参考」还是「可信事实」，直接决定模型
用不用。

## 专项记录：失败后反复诊断（未收敛）

### 现象

任务 3 里，模型执行 `pytest --cov` 失败（pytest-cov 未装）后，没有及时报告，而是
`pip show pytest-cov` → `pytest --version` → `import pytest_cov` 一连串诊断，即使
`SEARCH_MAX_STEPS=10` 也耗尽。

### 根因

模型有「帮用户解决依赖问题」的倾向，失败后不是「报告 + 停」，而是「诊断 + 尝试解决」。
这不是步数不够（10 步也耗尽），是模型的「问题解决倾向」压过了「收敛」信号。

### 修复（关键措辞教训）

- 第一版「report ... instead of repeatedly retrying」→ 无效（模型不是 retry，是 diagnose）；
- 第二版「diagnose with at most ONE follow-up command」→ 无效（给了「诊断一次」的许可，
  模型还是顺手多查）；
- 最终版「report the failure and what is needed immediately」→ 有效，斩断「诊断」这条路。

**教训**：prompt 里「给多少步」不如「斩断整条路径」——「diagnose once」是给诊断开窗，
「report immediately」是关窗。对收敛类问题，措辞要「关闭」而非「限制」。

## 专项记录：SEARCH 任务 step 太小

### 现象

`SEARCH_MAX_STEPS = 4` 太短。模型在只读解释任务里「读 2-3 个关键文件 + 总结/回答」
就需要 4-5 步，甚至可能「读文件 + 执行验证（如跑 pytest）+ 报告结果」需要 5-6 步。
4 步的预算下，模型往往还没进入「总结/报告」阶段就被 `max_steps` 强制终止，最终回答
是最后一次工具调用的原始输出（如 pytest 输出、文件内容），**而不是对用户问题的回答**。

### 根因

V0.1 为了防「无限探索」（任务 12 模型反复重读文件 8 次耗尽步数），把 SEARCH 预算压到
4。但这个值矫枉过正——「防无限探索」和「给足步数完成总结」之间，4 步只解决了前者，
牺牲了后者。模型不是「无限探索」，是「步数不够完成正常的读 + 答」。

### 修复

`SEARCH_MAX_STEPS` 4 → 6。仍比默认 16 小（保留「防止无限探索」的意图），但给模型
「读几个文件 + 总结回答」留出了余量。

### 遗留观察

模型在 SEARCH 任务里「读到测试命令后主动执行 pytest」这个行为，严格说不符合 SEARCH
「只读」语义，但它「执行 + 报告」本身是有价值的（帮用户验证），不是缺陷。若后续要
严格「SEARCH 只读」，可在 SEARCH 意图下限制工具集（禁 run_command 等执行类工具）——
本次先不处理，观察更多任务再决定。

## 失败模式汇总（进行中）

| # | 失败模式 | 严重性 | 状态 |
|---|---------|--------|------|
| 1 | 意图误判（「怎么跑测试」→ CODE） | 🟡 中 | ✅ 已修（LLM 分类） |
| 2 | SEARCH step 太小（max_steps 耗尽） | 🟡 中 | ✅ 已修（4→10） |
| 3 | 模型起初不重视注入记忆 | 🟡 中 | ✅ 已修（prompt 强化） |
| 4 | 失败后反复诊断（未收敛） | 🟡 中 | ✅ 已修（report immediately） |

> 注：「怎么跑 X → 执行 X」不是 bug——Agent 有权限时默认「帮你执行」是合理甚至更优的
> 行为（跑一遍给你看 2 passed，比告诉命令更有信息量），已确认接受该行为。

## 待续

- 继续跑更多任务（工作记忆注入干扰、多轮膨胀、DEBUG/REFACTOR 边界回归）。

## 「记忆文件可见」的结论

模型偶发会 `list_files` 看到 `.mini-code-memory` 并 `read_file` 读 `memory.json`
原始 JSON（含 id/时间戳/confidence 内部字段）——这些是内部实现细节，对模型是噪声
不是知识。

**已实施**：`MemoryManager.save` 除写 `memory.json`（内部存储）外，同时写
`MEMORY.md`（`format_as_markdown` 的格式化产物，`# Project Memory / ## Testing /
- 内容`）。这样模型偶发读记忆文件时，读到的是干净的 markdown 而非 JSON。

**观察**：实际测试中，模型更多用**注入的记忆**（主动、受控、格式化），偶发才自己读
文件；MEMORY.md 兜住了偶发情况。不强制屏蔽记忆目录——「记忆给模型读」本身合理，
问题只在于「读到的形态」，MEMORY.md 解决了形态问题。
