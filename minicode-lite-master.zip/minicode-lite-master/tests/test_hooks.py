"""Day 23：Hooks 事件系统的契约测试。

覆盖：注册/触发、坏 hook 隔离（continue）、disable、统计、日志 hook，以及
run_agent_turn 在稳定事件点 fire hook + 记忆注入经 AGENT_START 可变容器传回。
"""

from minicode.hooks import HookEvent, HookManager, create_logging_hook


class TestRegisterAndFire:
    def test_fire_calls_registered_handler(self):
        mgr = HookManager()
        seen: list[str] = []
        mgr.register(HookEvent.PRE_TOOL_USE, lambda ctx: seen.append(ctx.data["tool_name"]))
        errors = mgr.fire_sync(HookEvent.PRE_TOOL_USE, tool_name="read_file")
        assert errors == []
        assert seen == ["read_file"]
        print(f"\n注册 handler 被调用: seen={seen}")

    def test_handler_can_write_to_shared_container(self):
        # 关键契约：handler 经可变容器（dict）写结果，fire 调用方读回——记忆注入靠这个
        mgr = HookManager()
        box: dict[str, str] = {}
        mgr.register(HookEvent.AGENT_START, lambda ctx: ctx.data["inject_box"].update({"project_text": "记忆文本"}))
        mgr.fire_sync(HookEvent.AGENT_START, inject_box=box)
        assert box["project_text"] == "记忆文本"
        print(f"\nhandler 写入共享容器: {box}")

    def test_disabled_hook_not_fired(self):
        mgr = HookManager()
        seen: list[int] = []
        mgr.register(HookEvent.AGENT_STOP, lambda ctx: seen.append(1))
        mgr.disable()
        mgr.fire_sync(HookEvent.AGENT_STOP)
        assert seen == []
        print("\ndisable 后不 fire")


class TestIsolation:
    def test_bad_hook_does_not_block_others(self):
        # 一个坏 hook 抛异常，其余 hook 照常执行，错误文本通过返回值可见（continue 策略）
        mgr = HookManager()
        seen: list[str] = []

        def bad(ctx):
            raise RuntimeError("boom")

        mgr.register(HookEvent.PRE_TOOL_USE, bad, description="bad hook")
        mgr.register(HookEvent.PRE_TOOL_USE, lambda ctx: seen.append("ok"))
        errors = mgr.fire_sync(HookEvent.PRE_TOOL_USE)
        assert seen == ["ok"]
        assert len(errors) == 1 and "boom" in errors[0]
        print(f"\n坏 hook 不阻断: seen={seen}, errors={errors}")

    def test_failure_is_recorded_in_stats(self):
        mgr = HookManager()

        def bad(ctx):
            raise ValueError("x")

        mgr.register(HookEvent.POST_TOOL_USE, bad, description="bad")
        mgr.fire_sync(HookEvent.POST_TOOL_USE)
        stats = mgr.get_stats(HookEvent.POST_TOOL_USE)
        assert stats["failure_count"] == 1
        assert stats["hooks"][0]["last_status"] == "error"
        assert "x" in stats["hooks"][0]["last_error"]
        print(f"\n失败统计: {stats}")


class TestLoggingHook:
    def test_logging_hook_writes_to_list(self):
        target: list[str] = []
        mgr = HookManager()
        mgr.register(HookEvent.PRE_TOOL_USE, create_logging_hook(target))
        mgr.fire_sync(HookEvent.PRE_TOOL_USE, tool_name="read_file")
        assert len(target) == 1
        assert "pre_tool_use" in target[0] and "read_file" in target[0]
        print(f"\n日志 hook: {target}")


class TestAgentLoopWiring:
    def test_hooks_fire_and_memory_inject_via_hook(self, tmp_path):
        """run_agent_turn 在稳定事件点 fire hook；记忆注入经 AGENT_START 传回 history。"""
        from minicode.agent_loop import run_agent_turn
        from minicode.intent_parser import Intent
        from minicode.mock_model import ScriptedModel
        from minicode.task_object import TaskObject
        from minicode.tools import create_core_tool_registry
        from minicode.types import AgentStep, ToolCall

        (tmp_path / "a.txt").write_text("hi", encoding="utf-8")
        events: list[str] = []
        mgr = HookManager()

        # 模拟 memory 扩展：AGENT_START 往 inject_box 写注入文本
        def inject_memory(ctx):
            ctx.data["inject_box"]["project_text"] = "[记忆] 测试命令是 pytest"

        mgr.register(HookEvent.AGENT_START, inject_memory, description="memory inject")
        mgr.register(HookEvent.AGENT_STOP, lambda ctx: events.append("agent_stop"))
        mgr.register(HookEvent.PRE_TOOL_USE, lambda ctx: events.append(f"pre:{ctx.data['tool_name']}"))
        mgr.register(HookEvent.POST_TOOL_USE, lambda ctx: events.append(f"post:{ctx.data['tool_name']}"))

        task = TaskObject(goal="侦察", intent=Intent.SEARCH)
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "list_files", {"path": "."})]),
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        history, stop = run_agent_turn(
            model,
            create_core_tool_registry(),
            [{"role": "user", "content": "侦察"}],
            str(tmp_path),
            task=task,
            hooks=mgr,
        )
        assert stop == "done"
        assert "agent_stop" in events
        assert "pre:list_files" in events
        assert "post:list_files" in events
        # 记忆注入文本经 hook 传回，被 upsert_project_memory 注入 history
        assert any("[记忆] 测试命令是 pytest" in str(m) for m in history)
        print(f"\n事件序列: {events}")
        injected = [str(m)[:80] for m in history if "[记忆]" in str(m)]
        print(f"\n注入记忆的历史消息: {injected}")

    def test_no_hooks_is_noop(self, tmp_path):
        # hooks 为 None 时主链路照常，不 fire 任何事件（扩展关闭不破坏核心）
        from minicode.agent_loop import run_agent_turn
        from minicode.mock_model import ScriptedModel
        from minicode.tools import create_core_tool_registry
        from minicode.types import AgentStep

        model = ScriptedModel([AgentStep(type="assistant", kind="final", content="完成")])
        history, stop = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], str(tmp_path)
        )
        assert stop == "done"
        print("\nhooks=None 主链路照常，无副作用")
