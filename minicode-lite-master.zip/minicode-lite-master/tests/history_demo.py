"""Day 15 history 演示：用户输入历史的上下键导航与去重。

运行（项目根目录）：
    python tests/history_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.history import InputHistory


def main():
    h = InputHistory()
    h.add("ls")
    h.add("read README.md")
    h.add("run tests")
    h.add("run tests")  # 连续重复，应被去重忽略
    h.add("")           # 空输入，应被忽略

    print(f"历史条目: {h.entries()}")

    print("\n== 上键（从最新往旧翻）==")
    print(f"  第 1 次上键: {h.previous()!r}")
    print(f"  第 2 次上键: {h.previous()!r}")
    print(f"  第 3 次上键: {h.previous()!r}")
    print(f"  第 4 次上键: {h.previous()!r}")

    print("\n== 下键（从旧往新翻）==")
    print(f"  第 1 次下键: {h.next()!r}")
    print(f"  第 2 次下键: {h.next()!r}")
    print(f"  第 3 次下键: {h.next()!r}")
    print(f"  第 4 次下键: {h.next()!r}（越过末尾 → None，回到当前输入）")


if __name__ == "__main__":
    main()
