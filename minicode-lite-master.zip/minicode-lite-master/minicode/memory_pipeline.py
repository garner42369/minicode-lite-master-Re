"""minicode 的记忆流水线：Day 19 MemoryManager 的统一外观（Day 20）。

Loop 只依赖 MemoryPipeline 的 inject / feedback / write / maintain 接口，不直接
import MemoryManager——任何内部替换（换检索、加插件）都不扩大影响面（课件 Day 20
「MemoryPipeline 为什么重要」）。

高级能力可插拔、有 fallback：reranker 是可选构造参数（None = 禁用），失败回退 BM25
基础排序；vector / timeline 需接真实模型或向量库，超出「运行时零依赖」底线，Day 20
不实现（课件也标了「可选 / 专用研究能力」）。禁用所有高级模块时主流程照常工作。
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Callable

from minicode.hooks import HookEvent
from minicode.memory import MemoryEntry, MemoryManager, MemoryScope


@dataclass(frozen=True, slots=True)
class InjectionDecision:
    """一次注入决策：注入多少、每条多长。"""

    mode: str            # off / summary / full
    max_entries: int
    max_chars_each: int


def decide_injection(context_ratio: float) -> InjectionDecision:
    """根据上下文压力决定注入策略（课件 daily_code 阈值）。

    上下文越满，注入越少：临界（>=90%）不注入，高压（>=75%）注入摘要，低压注入全文。
    为什么随压力降级：记忆注入是辅助，不喧宾夺主——上下文快满了还塞全文，反而挤掉
    当前对话的关键信息。
    """
    if context_ratio >= 0.90:
        return InjectionDecision("off", 0, 0)
    if context_ratio >= 0.75:
        return InjectionDecision("summary", 2, 120)
    return InjectionDecision("full", 5, 500)


class MemoryPipeline:
    """记忆流水线外观：统一 inject / write / feedback / maintain 生命周期。"""

    def __init__(
        self,
        manager: MemoryManager,
        reranker: Callable[[str, list[MemoryEntry]], list[MemoryEntry]] | None = None,
        cooldown_seconds: float = 60.0,
    ) -> None:
        self.manager = manager
        self.reranker = reranker
        self.cooldown_seconds = cooldown_seconds
        self._last_injected_ids: list[str] = []  # 上次注入的记忆 id，供 feedback 闭环
        self._last_inject_key: str | None = None  # 上次注入的任务 hash
        self._last_inject_time: float = 0.0

    def inject(self, query: str, context_ratio: float) -> str:
        """按上下文压力注入相关记忆。

        流程：decide（压力→策略）→ search（BM25 召回 10 条）→ rerank（可选，失败
        回退 BM25 排序）→ 截断（max_entries + max_chars_each）→ 格式化。
        """
        decision = decide_injection(context_ratio)
        if decision.mode == "off":
            self._last_injected_ids = []
            return ""
        # cooldown：相同任务（query hash 相同）在冷却期内不重复注入同一批记忆
        key = hashlib.sha256(query.encode("utf-8")).hexdigest()
        now = time.time()
        if key == self._last_inject_key and now - self._last_inject_time < self.cooldown_seconds:
            return ""
        candidates = self.manager.search(query, limit=10)
        if self.reranker is not None:
            try:
                candidates = self.reranker(query, candidates)
            except Exception:
                pass  # rerank 失败，保留 BM25 基础排序（降级，不中断注入）
        selected = candidates[: decision.max_entries]
        self._last_injected_ids = [e.id for e in selected]
        self._last_inject_key = key
        self._last_inject_time = now
        return "\n".join(
            f"- [{e.source}] {e.content[:decision.max_chars_each]}"
            for e in selected
        )

    def write_verified_fact(
        self,
        content: str,
        *,
        source: str = "",
        tags: list[str] | None = None,
        category: str = "general",
        verified: bool = True,
    ) -> MemoryEntry:
        """写一条已验证的记忆。

        未验证（verified=False）抛异常不写——课件验收「未验证任务不会被 Reflection
        写成成功经验」：模型口头说「做成了」不算数，只有验证通过的事实才沉淀为记忆。
        """
        if not verified:
            raise ValueError("unverified reflection cannot become project memory")
        entry = self.manager.add(
            MemoryScope.PROJECT, content, category=category, tags=tags, source=source
        )
        self.manager.save()
        return entry

    def feedback(self, task_success: bool) -> None:
        """任务结果 → 记忆置信度（闭环学习）。

        成功 → 上次注入的记忆 confidence +0.1（正强化）；失败 → -0.1（衰减，它们可能
        误导了 agent）。confidence 会乘进 BM25 评分，所以成功过的记忆下次更容易被召回，
        失败过的记忆下次更靠后。
        """
        if not self._last_injected_ids:
            return
        delta = 0.1 if task_success else -0.1
        for scope in MemoryScope:
            for entry in self.manager.list(scope):
                if entry.id in self._last_injected_ids:
                    entry.confidence = min(1.0, max(0.0, entry.confidence + delta))
        self.manager.save()

    def register_hooks(self, hooks) -> None:
        """把自身接入 hook：inject 挂 AGENT_START、feedback 挂 AGENT_STOP。

        Day 23 起 loop 不再直接调 MemoryPipeline，而是 fire 事件；本方法把「记忆
        流水线如何接入事件」的知识内聚在这里，装配方（runtime_factory / 集成测试）
        构造 MemoryPipeline 后调用一次即可，不用各自重复写闭包。
        """
        def _on_start(ctx):
            task = ctx.data.get("task")
            ratio = ctx.data.get("context_ratio", 0.0)
            box = ctx.data.get("inject_box")
            if box is not None:
                box["project_text"] = self.inject(task.goal if task else "", ratio)

        def _on_stop(ctx):
            self.feedback(task_success=ctx.data.get("task_success", False))

        hooks.register(HookEvent.AGENT_START, _on_start, description="memory inject")
        hooks.register(HookEvent.AGENT_STOP, _on_stop, description="memory feedback")

    def maintain(self) -> int:
        """维护：失效过期的记忆（expires_at 已过），返回失效条数。

        一次性事实（如「本机临时改了端口」）设了 expires_at，过期后自动失效，不再注入。
        这是记忆生命周期的收尾——不失效的过期记忆会一直占位、误导。
        """
        now = time.time()
        expired = 0
        for scope in MemoryScope:
            for entry in self.manager.list(scope):
                if entry.valid and entry.expires_at is not None and entry.expires_at < now:
                    entry.valid = False
                    expired += 1
        if expired:
            self.manager.save()
        return expired
