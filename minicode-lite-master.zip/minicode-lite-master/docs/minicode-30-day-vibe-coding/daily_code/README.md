# 30 天每日 Python 代码参照

这里的代码与主课程 Day 1–30 一一对应。每个文件都满足三个目标：

1. 只展示当天最关键的接口和数据流；
2. 可以单独阅读，大多数文件可直接运行自带 Demo；
3. 告诉你它在正式项目中应被哪些模块替换或扩展。

这些文件是教学参照，不是把 `minicode/` 源码复制一遍。安全、跨平台和 Provider 协议等生产级边界仍应按照主课程的验收项补齐。

## 使用方式

```powershell
python -m compileall -q daily_code
python daily_code/day07_agent_loop.py
python daily_code/day12_reviewed_edit.py
python daily_code/day30_eval_harness.py
```

建议先不看代码，按当天课程自行实现；卡住或完成第一版后，再打开对应文件比较接口和控制流。

## 对照表

| Day | 代码 | 正式项目主要对应模块 |
| --- | --- | --- |
| 1 | `day01_product_contract.py` | 产品说明、验收矩阵 |
| 2 | `day02_protocols.py` | `types.py`、`tooling.py` |
| 3 | `day03_config_and_logging.py` | `config.py`、`logging_config.py` |
| 4 | `day04_scripted_model.py` | `mock_model.py` |
| 5 | `day05_tool_registry.py` | `tooling.py`、`tools/__init__.py` |
| 6 | `day06_readonly_tools.py` | `workspace.py`、只读工具 |
| 7 | `day07_agent_loop.py` | `agent_loop.py` |
| 8 | `day08_tool_scheduler.py` | `agent_intelligence.py`、`agent_metrics.py` |
| 9 | `day09_prompt_pipeline.py` | `prompt.py`、`prompt_pipeline.py` |
| 10 | `day10_provider_adapter.py` | 模型注册与 Provider Adapter |
| 11 | `day11_permissions.py` | `permissions.py`、`auto_mode.py` |
| 12 | `day12_reviewed_edit.py` | `file_review.py`、写入工具 |
| 13 | `day13_command_runner.py` | `run_command.py`、`test_runner.py` |
| 14 | `day14_turn_kernel.py` | `turn_kernel.py`、验证控制 |
| 15 | `day15_session_store.py` | `session.py`、`state.py` |
| 16 | `day16_safe_rewind.py` | Replay、Resume、Rewind |
| 17 | `day17_context_budget.py` | `context_manager.py`、结果预算 |
| 18 | `day18_compaction.py` | `context_compactor.py`、工作记忆 |
| 19 | `day19_project_memory.py` | `memory.py` |
| 20 | `day20_memory_pipeline.py` | Injector、Reranker、Pipeline |
| 21 | `day21_runtime_factory.py` | CLI、Headless、运行时装配 |
| 22 | `day22_tui_events.py` | `tty_app.py`、`tui/` |
| 23 | `day23_skills_hooks.py` | `skills.py`、`hooks.py` |
| 24 | `day24_mcp_protocol.py` | `mcp.py` |
| 25 | `day25_product_surfaces.py` | `product_surfaces.py`、能力注册 |
| 26 | `day26_delegation.py` | 后台任务、子 Agent、Task Graph |
| 27 | `day27_routing_and_verification.py` | 路由、成本、验证、审计 |
| 28 | `day28_pid_control.py` | 反馈、预测、上下文/成本控制 |
| 29 | `day29_control_orchestrator.py` | Orchestrator、自愈、消融 |
| 30 | `day30_eval_harness.py` | Harness、Readiness、发布评估 |

