"""Day 14: 显式阶段、预算、验证证据和终止判断。"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Phase(str, Enum):
    EXPLORE = "explore"
    EXECUTE = "execute"
    VERIFY = "verify"


@dataclass(slots=True)
class TurnState:
    max_steps: int = 8
    step: int = 0
    changed_version: str = ""
    verified_version: str = ""
    tool_observations: int = 0
    phase: Phase = Phase.EXPLORE

    def record_change(self, version: str) -> None:
        self.changed_version = version
        self.verified_version = ""
        self.phase = Phase.EXECUTE

    def record_verification(self, version: str, passed: bool) -> None:
        self.tool_observations += 1
        if passed:
            self.verified_version = version
        self.phase = Phase.VERIFY

    def evidence_ready(self) -> bool:
        return bool(self.changed_version) and self.changed_version == self.verified_version


@dataclass(frozen=True, slots=True)
class Decision:
    terminal: bool
    reason: str
    nudge: str = ""


def decide_final(state: TurnState, requires_verification: bool) -> Decision:
    if state.step >= state.max_steps:
        return Decision(True, "max_steps")
    if requires_verification and not state.evidence_ready():
        return Decision(False, "verification_missing", "运行与当前文件版本相关的验证后再结束。")
    return Decision(True, "done")


if __name__ == "__main__":
    state = TurnState()
    state.record_change("hash-v1")
    assert not decide_final(state, True).terminal
    state.record_verification("hash-v1", passed=True)
    assert decide_final(state, True).reason == "done"
    state.record_change("hash-v2")
    assert not state.evidence_ready()
    print("turn kernel: OK")

