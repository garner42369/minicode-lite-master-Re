"""Day 15：history 用户输入历史的契约测试。"""

from minicode.history import InputHistory


class TestInputHistory:
    def test_add_ignores_empty_and_consecutive_duplicate(self):
        h = InputHistory()
        h.add("ls")
        h.add("ls")   # 连续重复，去重
        h.add("")     # 空输入，忽略
        h.add("read")
        print(f"entries after add: {h.entries()}")
        assert h.entries() == ["ls", "read"]

    def test_previous_navigates_newest_to_oldest(self):
        h = InputHistory()
        for text in ("a", "b", "c"):
            h.add(text)
        seq = [h.previous(), h.previous(), h.previous(), h.previous()]
        print(f"previous 序列: {seq}")
        # 上键：c -> b -> a -> a（到最早后停在最早，不再往前）
        assert seq == ["c", "b", "a", "a"]

    def test_next_returns_none_after_newest(self):
        h = InputHistory()
        for text in ("a", "b"):
            h.add(text)
        assert h.previous() == "b"
        assert h.previous() == "a"
        seq = [h.next(), h.next()]
        print(f"next 序列: {seq}")
        # 下键：b -> None（越过末尾回到当前输入）
        assert seq == ["b", None]

    def test_navigation_on_empty_history(self):
        h = InputHistory()
        print(f"空历史 previous={h.previous()!r} next={h.next()!r}")
        assert h.previous() is None
        assert h.next() is None
