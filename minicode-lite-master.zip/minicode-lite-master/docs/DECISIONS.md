# MiniCode 设计决策记录（DECISIONS）

> 记录有代价的选择及复查条件。不是流水账，只在「选 A 而非 B 有可逆/不可逆代价」时新增一条。

## 决策格式

每条包含：决策、备选方案、选择的理由、代价、复查条件（什么信号出现时重新评估）。

## D1 完整复现到 V1.0，不逐行照搬

- 决策：完整复现全部 ~130 模块，但用自己的结构实现，不复制源码。
- 备选：只做核心闭环；或直接搬运源码。
- 代价：慢；某些边界需对照源码才能对齐。
- 复查条件：若某个增强层（控制论等）投入产出比过低，可降级为「实现职责 + 可关闭骨架」。

## D2 自研运行时，零运行时依赖

- 决策：运行时零依赖，用 `urllib.request` 直调 API、`subprocess` 执行命令、标准库实现 TUI。
- 备选：引入 LangChain/LlamaIndex 等 Agent 框架，或 httpx/rich 等现代依赖。
- 代价：网络重试、流式、编码、TUI 都要自己写，坑更多（符合学习目标）。
- 复查条件：若标准库在 TUI（Day 22）或 Provider（Day 10）上严重阻碍进度，可评估引入单个务实依赖。

## D3 Python 3.11

- 决策：`requires-python >= 3.11`，使用 dataclass slots、`X | Y` 类型等 3.10+ 特性。
- 代价：锁定解释器版本。
- 复查条件：本机为 Anaconda Python 3.11.7，已满足；无。

## D4 mock 优先，真实 Provider 后置

- 决策：Day 1–9 全程用 Mock Model 离线运行，Day 10 再接真实 Provider。
- 代价：前 9 天不验证真实 API 行为。
- 复查条件：Day 10 需确认真实 API key 可用性（届时再问）。

## D5 严格 30 天逐日推进

- 决策：按 30 天课程逐日实现，每天停下由用户 review + 改 bug 后再进下一天。
- 备选：14 天压缩版，或一次性连续实现。
- 代价：慢，但对「理解 + 踩坑」最有利。
- 复查条件：若用户确认节奏需调整，再改。

## D6 参考源码的角色

- 决策：docs 为主干，参考源码（D:\Project\MiniCode-Python）作深度对照，自上而下看架构。
- 代价：可能过度聚焦单文件而丢失整体架构——需时刻回到分层图。
- 复查条件：若发现 docs 与源码冲突，以「外部行为契约」为准，记录差异。

## D7 验收标准（待定）

- 决策：是否复用参考仓库 1164 个测试作为契约，尚未决定。
- 代价：复用=最强验收但工作量大；自写=快但可能偏离参考行为。
- 复查条件：到首次需要测试验证时再定（见 PRODUCT_SPEC 验收故事）。

## D8 工具描述信息归 metadata

- 决策：name / description / input_schema 放在 ToolMetadata，ToolDefinition 只保留 validator / run / metadata。
- 备选：删 metadata 侧，让 ToolDefinition 持有这些字段。
- 理由：metadata 可以自包含地独立传递（如构建 prompt 时只需描述、不需执行函数）。
- 代价：metadata 变必填；访问工具名是 tool.metadata.name 而非 tool.name。
- 复查条件：若 Day 5 Registry 或后续发现 tool.metadata.name 访问繁琐，可评估在 ToolDefinition 上加委托 property。

## D9 types.py 与标准库重名，运行方式用 -m

- 决策：保留 `types.py` 文件名（与参考源码一致），约定从项目根 `python -m minicode.main` 运行，而非 `cd minicode && python main.py`。
- 备选：重命名 `types.py` 为 `protocols.py`，彻底避免与标准库 types 冲突。
- 理由：`types` 是标准库模块名，从包目录内直接运行会遮蔽标准库导致循环导入；`-m` 是 Python 包的标准运行方式，参考源码也如此。
- 代价：不能 `cd minicode && python main.py` 直接运行。
- 复查条件：若后续大量场景需要从包内直接运行，再评估重命名。

## D10 工作区边界用 resolve() 而非字符串前缀检查

- 决策：`resolve_workspace_path` 先 `resolve()` 消解 `..`/符号链接/相对路径，再 `relative_to(root)` 判边界。
- 备选：只做字符串前缀检查（`startswith(root)`）。
- 理由：字符串前缀检查能被 `..`、符号链接、Windows junction 绕过，直接读到工作区外。
- 代价：指向工作区外的符号链接被拒绝；指向内部的符号链接被消解成真实路径，丢失「符号链接语义」。
- 复查条件：若后续需支持 monorepo 软链 / 工作区内符号链接，重新评估「允许符号链接但限定其解析目标」。

## D11 Agent 核心循环通过回调推送事件，不 import UI

- 决策：`run_agent_turn` 用 `on_tool_start` / `on_tool_result` / `on_assistant_message` 三个回调把事件推出去，核心循环不 import 任何 UI 模块。
- 备选：Loop 直接调用 TUI / Headless 的渲染函数。
- 理由：让核心闭环与界面解耦，同一份逻辑被 TUI / Headless / 测试复用，也能完全离线测试。
- 代价：事件类型增多时回调参数列表会膨胀。
- 复查条件：Day 22 TUI 接入时若回调不够用，评估引入事件队列或统一 `RuntimeEvent` 通道。

## D12 调度器只分组+回填+记录，不做并发/熔断决策

- 决策：`execute_calls` 只按 `concurrency_safe` 能力标志分组并发/串行、恢复原顺序、记录指标；并发上限硬编码 `min(4, len)`，不做熔断/自适应。
- 备选：Day 8 就引入熔断或依据历史成功率动态调并发（参考实现的 `ToolSchedulerController`）。
- 理由：熔断和自适应并发是「根据指标做决策」，属 Day 27 控制论；Day 8 提前做会和 Day 27 撞车，也让 V0 闭环变复杂。
- 代价：Day 8 并发上限是固定值，不随负载/错误率调整。
- 复查条件：Day 27 实现控制论时，把硬编码的 `min(4, len)` 换成控制器决策。

## D13 模块合并为 scheduler.py，不照课件拆分

- 决策：Day 8 的三个能力（调度/错误分类/指标）合并进 `scheduler.py` + 错误分类纯函数进 `tooling.py`，不照课件建 `agent_intelligence.py` + `agent_metrics.py`。
- 备选：跟随课件模块名，便于对照参考源码与课件模块地图。
- 理由：三个职责都小，拆三个文件是「为凑文件名而拆」；错误分类作为 `error_code → 建议` 纯函数更内聚。
- 代价：偏离课件模块地图，`docs/TASKS.md` 的 Day 8 验收命令从 `test_agent_intelligence.py` 改为 `test_scheduler.py`。
- 复查条件：若后续对照参考源码时发现模块边界频繁对不上，重新评估是否跟随课件命名。

## D14 错误分类用结构化 error_code，不用关键词匹配

- 决策：恢复建议由 `ToolResult.error_code` 映射（`unknown_tool`/`invalid_input`/`tool_crash`/`not_found`/…），而非匹配 `output` 文本关键词。
- 备选：照参考实现 `ErrorClassifier` 用关键词子串匹配，细分 network/permission/resource/timeout/logic。
- 理由：error_code 是工具/Registry 显式声明的结构化信号，可靠；关键词匹配脆弱（换措辞就误判）。
- 代价：放弃 network/permission/resource 细分，`tool_crash` 粒度粗（所有异常一锅端）。
- 复查条件：Day 10 接真实 Provider 后，若需区分网络错误做退避重试，重新评估 error_code 粒度（可能拆分 tool_crash）。

## D15 恢复建议载体的边界：工具失败用系统注记，空响应 nudge 用 user 消息

- 决策：工具失败的恢复建议附在 `ToolResult.metadata["recovery_hint"]`（走 tool_result 通道，语义是「环境对这次动作的纠正」）；空响应重试的唤醒提示用 `role: "user"` 消息。
- 备选：所有运行时 steering 一律用 user 消息，或一律用 system 注记。
- 理由：工具失败建议有 tool_result 通道可附，伪装成 user 会污染任务意图；空响应没有通道可附、必须让模型产生下一个回复，只有 user 能承载。
- 代价：两处 steering 载体不一致，读者可能误以为矛盾（实为不同场景）。
- 复查条件：Day 10 接真实 Provider 时，确认中途插入 user 消息在目标 Provider 协议下兼容。

## D16 砍掉 Day 22 TUI，交互入口由 CLI + Headless 承担

- 决策：不做 Day 22 的 19 模块全屏 TUI；交互入口由 Day 21 的 CLI + Headless 承担。
- 备选：完整实现 TUI；或只做事件流骨架（RuntimeEvent→TranscriptEntry 映射 + 纯函数 reducer + input parser）。
- 理由：TUI 的硬骨头是终端工程（Raw Mode / ANSI / CJK 宽度 / Windows 控制台 / SSH / 终端恢复），与「掌握 agent 内核」目标偏离，投入产出比低；CLI + Headless 已覆盖交互入口。Loop 已用 on_tool_start / on_tool_result / on_assistant_message 回调暴露事件，D11 的「UI 只消费事件、不复制业务」契约不因砍 TUI 而损失。
- 代价：「完全复刻」不再完整，Day 22 课件未落地；types.py 的「控制论 RuntimeEvent」与课件「UI 流式事件」命名冲突成为无消费者的遗留，可忽略。
- 复查条件：若需比 CLI 更强的交互体验（演示 / 对外发布），重新评估补 TUI（可只做事件流骨架）。

## D17 Hook 失败策略只 continue，不做超时/block

- 决策：Hook 异常只隔离（continue）、不阻断主流程；不做超时、不做 FailurePolicy.BLOCK / fail-closed。
- 备选：完整实现 timeout + FailurePolicy（continue/block），如课件 daily_code 与主文档「失败策略」表格（安全预检 fail-closed）。
- 理由：对齐参考项目 hooks.py 实际实现（try/except 隔离）；hook 是辅助（日志/通知/策略检查），失败不该击穿主循环；block 需要 fire 能中断流程，当前无场景。
- 代价：丢掉「安全预检 fail-closed」能力；未来做安全类 hook 需先扩展 FailurePolicy。
- 复查条件：当需要「hook 阻断动作」的安全场景（如强制代码审查门禁）时，扩展 failure_policy。

## D18 Skill description 提取按课件，不兼容无 frontmatter

- 决策：extract_description 只认 frontmatter 的 `description:` 前缀，找不到返回空串，不回退「正文首段」。
- 备选：参考项目 extract_description（提取正文首段，兼容无 frontmatter 的 SKILL.md）。
- 理由：用户明确「按课件实现，不兼容无 frontmatter」；课件 daily_code 用 `description:` 前缀。
- 代价：无 frontmatter 的 SKILL.md 会被发现但 description 为空（prompt 清单里只有名字）。
- 复查条件：若未来要兼容 Claude Code 生态里无 frontmatter 的 SKILL.md，再评估回退正文首段。

## D19 MCP 传输做双协议 auto-detect

- 决策：stdio 传输同时支持 content-length + newline-json，按首行是否 `Content-Length:` 头自动探测。
- 备选：只 newline-json（课件 daily_code 只做这个，简单）。
- 理由：用户拍板「还是用双协议」；兼容官方 content-length 规范和早期 newline-json 实现。
- 代价：reader 线程更复杂（长度帧解析）。
- 复查条件：无。

## D20 MCP 命令安全验证裁剪版

- 决策：不做硬编码命令白名单（ALLOWED_COMMANDS / 绝对路径白名单 / 危险 shell 封禁），只做「项目级 .mcp.json 默认不信任」+「参数 shell 元字符检查」。
- 备选：完整对齐参考项目（命令白名单 + 绝对路径白名单 + 危险 shell + 元字符）。
- 理由：用户拍板「裁剪版」；参考项目白名单太绑定其部署环境；信任边界放在「项目级默认不信任」。
- 代价：显式启用后信任配置里的 command，不做命令名/路径校验。
- 复查条件：若需连接不受信来源的 MCP server，再评估命令白名单。

## D21 Day 25 裁剪复现：能力目录做纯元数据，快照裁剪三样未做的依赖

- 决策：CapabilityRegistry 做纯元数据登记（name/domain/scope/enabled/description），不存 handler、不做调用统计、不做执行；ProductSnapshot 裁剪 extension.json / model fallback / background_tasks。
- 备选：完整对齐参考项目（依赖图/标签索引/搜索/装饰器 + ExtensionManifest + fallback 感知 Readiness）。
- 理由：参考项目完整版为「大量能力可发现性 + extension.json + model fallback + 后台任务」产品形态服务，这三样我们都没做；Registry 存 handler/统计会变成「第二套执行路径」；fallback 切换是 Day 27 路由职责、background_tasks 是 Day 26。
- 代价：无依赖检查/搜索/统计；Readiness 无 fallback 感知；快照无后台任务。
- 复查条件：能力增多需可发现性、引入通用插件系统、或 Day 26/27 接入后台/fallback 时，逐项重新评估。

## D22 模型路由走纯函数评分，裁剪关键词堆砌

- 决策：模型路由用课件纯函数评分（能力匹配 `1-|power-complexity|` + 预算惩罚 `budget×cost×0.5` + 延迟惩罚 `latency×power×0.2`）；复杂度是连续分数 0-1，基于意图映射（intent_parser 已分类 SEARCH/DEBUG/CODE/REFACTOR）+ 长度/改动加成。
- 备选：参考项目 agent_router.py 的关键词分类（8 个关键词集合 + SIMPLE/MODERATE/COMPLEX/CRITICAL 离散档位）。
- 理由：关键词堆砌是课件警告的「不可验证的启发式堆叠」——权重是魔法数字、漏词就误判、八个集合互相重叠；纯函数每一项含义明确、可单测、确定性、可解释。系数 0.5/0.2 是「相对权重」（能力匹配 > 预算 > 延迟），可调、靠 Day 29 消融验证。
- 代价：复杂度提取依赖意图分类，不覆盖「意图之外」的复杂度信号（如安全/合规领域的专用知识）。
- 复查条件：若路由需要领域专用复杂度信号，再评估引入额外显式信号源（但仍走显式信号，不堆关键词）。

## D23 控制论「了解意义为主」，PID 做最小实现，阈值可能够用

- 决策：控制论按「了解意义为主」做——PID 做最小实现（限幅 + 条件积分 anti-windup + reset），前馈/预测做「了解意义」级轻量实现；裁剪参考项目的卡尔曼滤波 / RGA 解耦 / 正反馈强化 / 多指标预测。
- 备选：完整复刻参考项目 2500+ 行控制论（feedback 三 PID + 正反馈 + 振荡检测、state_observer 卡尔曼、context_cybernetics 857 行）。
- 理由：minicode 已有「阈值压缩 + 熔断」简单规则，PID 是锦上添花；课件「阈值够用就别上 PID」；「值得裁剪的是缺依据和验证的复杂性，不是听起来高级的算法」。
- 代价：无卡尔曼最优估计、无 RGA 解耦、无自适应调参；前馈/预测非完整实现。
- 复查条件：Day 29 消融（阈值 vs PID 跑真实任务）若证明 PID 有稳定收益，再启用；否则默认关闭控制论、保留阈值规则。

## D24 Day 29 消融先合成画像，接线最小，结论「阈值够用」

- 决策：Day 29 消融用合成画像（不调真实模型），接线最小（orchestrator 的 after_tool 只接 compact 动作触发压缩）；裁剪参考项目 cybernetic_orchestrator 的 15 控制器 orchestration。
- 备选：完整复刻参考项目（15 控制器 orchestration + 854 行 ablation 依赖一堆我们没有的控制器 + 8 故障自愈）。
- 理由：合成画像快、确定性、可单测，先回答「方向对不对」；真实任务消融贵，Day 30 固定任务补。实测 delta 全 0（阈值 == PID），诚实证明「阈值够用，PID 默认关闭」。
- 代价：合成画像不是真实任务，「阈值够用」是初步证据，需 Day 30 真实任务验证。
- 复查条件：Day 30 真实任务消融若证明 PID 有稳定收益，再启用；否则默认关闭控制论、保留阈值规则。

## D25 Day 30 真实修复任务描述模糊 + 打包结项

- 决策：真实 Provider 修复（v04）的任务描述刻意模糊（只说「有测试失败」，不透露 bug 位置和改法）；打包构建 wheel 验证「能装能用」。
- 备选：任务描述直接说「divide 用了 // 改成 /」（喂答案）。
- 理由：模糊描述才验证「模型自己定位 bug」；直接说改法退化成「照指令改」，验证不了模型的理解能力。
- 代价：模糊描述下模型可能定位慢或失败（真实能力暴露）。
- 复查条件：无（结项）。


