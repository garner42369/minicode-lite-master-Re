"""minicode：本地 AI Coding Agent Runtime。"""

# 包版本号，供 pyproject.toml 的打包与运行时的版本展示复用
__version__ = "0.1.0"
