"""minicode 的工作区路径解析：所有本地文件访问的唯一入口。

安全关键点：必须先 resolve() 消解 ..、符号链接和相对路径，再检查边界。
如果只做字符串前缀检查，`..`、符号链接或 Windows junction 都能绕过工作区边界。

Day 11 强化：显式的大小写不敏感边界判断（Windows 文件系统大小写不敏感），
覆盖盘符、UNC、外部路径等 Windows 特有边界。
"""

from __future__ import annotations

import os
from pathlib import Path

from minicode.tooling import ToolContext


def _normcase(path: Path) -> str:
    """把路径规范成大小写不敏感的比较键。

    os.path.normcase 在 Windows 上转小写 + 反斜杠（对应文件系统大小写不敏感），
    在 POSIX 上原样返回（大小写敏感）。用字符串做边界比较，显式可控、可测，
    不依赖 pathlib 各平台相对大小写敏感性的内部细节。
    """
    return os.path.normcase(str(path))


def is_within_workspace(root: Path, target: Path) -> bool:
    """判断 target 是否在 root 内（Windows 大小写不敏感）。

    root、target 都应是已 resolve 的绝对路径。不同盘符（D:\\ vs C:\\）、
    UNC 路径（\\\\server\\share）与本地根不在同一根下，必然返回 False。

    用「target == root 或以 root+分隔符 开头」判断，避免 /foo 误匹配 /foobar。
    """
    root_key = _normcase(root)
    target_key = _normcase(target)
    prefix = root_key.rstrip(os.sep) + os.sep
    return target_key == root_key or target_key.startswith(prefix)


def resolve_workspace_path(context: ToolContext, raw_path: str) -> Path:
    """把用户/模型给的路径解析成工作区内的规范真实路径。

    越界（../、绝对外部路径、指向外部的符号链接、不同盘符、UNC）抛 PermissionError。
    """
    root = Path(context.cwd).resolve()
    candidate = Path(raw_path)
    target = (candidate if candidate.is_absolute() else root / candidate).resolve()
    if not is_within_workspace(root, target):
        raise PermissionError(f"path escapes workspace: {raw_path}")
    return target
