"""minicode 的模型路由（Day 27）。先有信号，再谈自动调节。

本模块做「显式信号 → 路由决策」的纯函数评分：
- `choose_model`：给定复杂度/预算/延迟压力 + 本轮失败集合，选分数最高的模型；
- `extract_complexity`：从意图 + 任务长度 + 改动数提取 0-1 复杂度 + 理由 + 置信度；
- `DecisionAudit`：记录每个自动决策的候选/理由/证据（回答「为什么换模型」）。

裁剪说明（裁剪复现）：参考项目 agent_router.py 用 8 个关键词集合分类复杂度（关键词
堆砌，权重是魔法数字、漏词就误判），这是课件警告的「不可验证的启发式堆叠」。这里走
课件纯函数 + 显式信号——意图已在 intent_parser 分类，路由只做「意图→复杂度」的显式
映射和线性评分，可单测、确定性。
"""

from __future__ import annotations

from dataclasses import dataclass, field

from minicode.intent_parser import Intent


@dataclass(frozen=True, slots=True)
class ModelProfile:
    """路由用的模型能力画像。power/relative_cost 是可更新配置，非不可变事实。"""

    name: str
    power: float          # 0-1 能力（主观估计，可更新）
    relative_cost: float  # 相对成本（1.0 = 最贵）
    long_context: bool = False


# 路由画像：deepseek-v4-pro（强、贵）vs deepseek-v4-flash（弱、便宜 ~8% 成本）。
MODEL_PROFILES: dict[str, ModelProfile] = {
    "deepseek-v4-pro": ModelProfile("deepseek-v4-pro", power=0.9, relative_cost=1.0, long_context=True),
    "deepseek-v4-flash": ModelProfile("deepseek-v4-flash", power=0.55, relative_cost=0.08, long_context=True),
}


@dataclass(frozen=True, slots=True)
class RoutingSignal:
    complexity: float          # 0-1 任务复杂度
    budget_pressure: float     # 0-1 预算压力（越高越要省钱）
    latency_pressure: float    # 0-1 延迟压力（越高越快）
    requires_long_context: bool = False


@dataclass(frozen=True, slots=True)
class RoutingDecision:
    model: str
    score: float
    reasons: tuple[str, ...]


def choose_model(
    profiles: dict[str, ModelProfile],
    signal: RoutingSignal,
    failed: set[str],
) -> RoutingDecision:
    """纯函数评分选模型。

    评分 = 能力匹配（1 - |power - complexity|）
         - 预算压力 × 相对成本 × 0.5
         - 延迟压力 × power × 0.2
    排除本轮已失败的模型（failed 集合）和不满足长上下文需求的模型。
    全部排除则抛错（fallback 耗尽，调用方据此处理，而不是静默选坏模型）。
    """
    candidates: list[tuple[float, ModelProfile]] = []
    for profile in profiles.values():
        if profile.name in failed:
            continue
        if signal.requires_long_context and not profile.long_context:
            continue
        score = 1.0 - abs(profile.power - signal.complexity)
        score -= signal.budget_pressure * profile.relative_cost * 0.5
        score -= signal.latency_pressure * profile.power * 0.2
        candidates.append((score, profile))
    if not candidates:
        raise RuntimeError("no eligible fallback model")
    score, selected = max(candidates, key=lambda row: row[0])
    return RoutingDecision(
        selected.name,
        score,
        (f"power={selected.power:.2f}", f"cost={selected.relative_cost:.2f}"),
    )


@dataclass(frozen=True, slots=True)
class ComplexitySignal:
    complexity: float
    reasons: tuple[str, ...]
    confidence: float


def extract_complexity(
    intent: Intent,
    task_length: int,
    changed_files: int = 0,
) -> ComplexitySignal:
    """从显式信号提取复杂度分数 + 理由 + 置信度。

    不走关键词堆砌——意图已在 intent_parser 分类，这里做「意图→复杂度」的显式映射，
    再叠加长度/改动数加成。确定性、可单测。
    """
    base = {
        Intent.SEARCH: 0.2,
        Intent.DEBUG: 0.5,
        Intent.CODE: 0.6,
        Intent.REFACTOR: 0.8,
    }.get(intent, 0.5)
    reasons = [f"intent={intent.value}"]

    length_factor = min(task_length / 2000.0, 1.0) * 0.2
    if length_factor > 0:
        reasons.append(f"length_factor={length_factor:.2f}")

    files_factor = min(changed_files / 5.0, 1.0) * 0.2
    if files_factor > 0:
        reasons.append(f"files_factor={files_factor:.2f}")

    complexity = min(1.0, base + length_factor + files_factor)
    # 意图映射是强信号（intent_parser 已分类），给高置信；长度/改动是弱加成
    return ComplexitySignal(complexity, tuple(reasons), confidence=0.9)


@dataclass(slots=True)
class DecisionAudit:
    """记录每个自动决策的候选/理由/证据，回答「为什么换模型/扩大验证」。"""

    rows: list[dict] = field(default_factory=list)

    def record(self, kind: str, decision: object, evidence: str) -> None:
        self.rows.append({"kind": kind, "decision": repr(decision), "evidence": evidence})

    def to_dict(self) -> list[dict]:
        return list(self.rows)
