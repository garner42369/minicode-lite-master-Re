"""验收测试：权限层（六种 verdict、turn-scoped、session 记忆、plan/bypass）。"""

from minicode.permissions import (
    Mode,
    PermissionDecision,
    PermissionKind,
    PermissionManager,
    PermissionRequest,
    RiskLevel,
)


def _request(kind=PermissionKind.PATH, scope="/workspace/src/main.py", risk=RiskLevel.MEDIUM):
    return PermissionRequest(kind=kind, scope=scope, summary=scope, risk=risk)


class TestVerdicts:
    def test_allow_once_not_remembered(self):
        mgr = PermissionManager("/workspace", mode=Mode.AUTO, prompt=lambda r: PermissionDecision("allow_once"))
        assert mgr.check(_request()).verdict == "allow_once"
        # allow_once 不记忆，第二次仍询问
        assert mgr.check(_request()).verdict == "allow_once"

    def test_allow_turn_scoped(self):
        calls = []

        def prompt(r):
            calls.append(r)
            return PermissionDecision("allow_turn")

        mgr = PermissionManager("/workspace", mode=Mode.AUTO, prompt=prompt)
        mgr.check(_request())
        mgr.check(_request())  # 同 scope，本轮不再询问
        assert len(calls) == 1

    def test_allow_always_cross_turn(self):
        mgr = PermissionManager("/workspace", mode=Mode.AUTO, prompt=lambda r: PermissionDecision("allow_always"))
        mgr.check(_request())
        mgr.begin_turn()  # 新轮，session 记忆仍保留
        assert mgr.check(_request()).verdict == "allow_once"  # 不再询问

    def test_deny_always_wins_over_allow(self):
        mgr = PermissionManager("/workspace", mode=Mode.AUTO)
        # 先永久拒绝
        mgr.check(_request())  # prompt=None → deny_once（不记忆）
        # 手动注入 session deny
        mgr._session_deny.add((PermissionKind.PATH, "/workspace/src/main.py"))
        mgr.prompt = lambda r: PermissionDecision("allow_always")
        assert mgr.check(_request()).verdict == "deny_always"

    def test_deny_with_feedback_does_not_change_config(self):
        feedback = "Please keep this file stable"
        mgr = PermissionManager("/workspace", mode=Mode.AUTO, prompt=lambda r: PermissionDecision("deny_with_feedback", feedback))
        decision = mgr.check(_request())
        assert decision.verdict == "deny_with_feedback"
        assert decision.feedback == feedback
        # deny_with_feedback 不记忆
        assert len(mgr._session_deny) == 0


class TestModes:
    def test_plan_blocks_write(self):
        mgr = PermissionManager("/workspace", mode=Mode.PLAN)
        req = _request(kind=PermissionKind.EDIT, risk=RiskLevel.MEDIUM)
        assert mgr.check(req).verdict == "deny_once"

    def test_plan_allows_safe_read(self):
        mgr = PermissionManager("/workspace", mode=Mode.PLAN)
        req = _request(kind=PermissionKind.PATH, risk=RiskLevel.SAFE)
        assert mgr.check(req).verdict == "allow_once"

    def test_bypass_skips_prompt(self):
        mgr = PermissionManager("/workspace", mode=Mode.BYPASS, prompt=lambda r: pytest.fail("should not prompt"))
        assert mgr.check(_request(risk=RiskLevel.DANGEROUS)).verdict == "allow_once"

    def test_auto_allows_safe(self):
        mgr = PermissionManager("/workspace", mode=Mode.AUTO)
        assert mgr.check(_request(risk=RiskLevel.SAFE)).verdict == "allow_once"

    def test_no_prompt_defaults_deny(self):
        mgr = PermissionManager("/workspace", mode=Mode.DEFAULT)
        assert mgr.check(_request(risk=RiskLevel.DANGEROUS)).verdict == "deny_once"
