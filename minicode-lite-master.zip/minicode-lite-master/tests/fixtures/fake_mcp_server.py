"""fake MCP server：极简 stdio MCP 服务端，用于 Day 24 端到端测试（无网络依赖）。

自适应两种帧协议：请求首行是 ``Content-Length:`` 头则按长度帧读，否则按 newline-json
读，响应用匹配的协议写。支持 initialize / tools/list / tools/call(echo) /
resources/list / resources/read / prompts/list / prompts/get。

``--exit-after N``：处理 N 个请求后退出（测「进程退出释放等待者」）。
``--delay SEC``：每个请求前 sleep（测「超时」）。
"""

from __future__ import annotations

import argparse
import json
import sys
import time


def read_request() -> tuple[dict | None, str]:
    """读一个 JSON-RPC 请求，返回 (message, protocol)。EOF 返回 (None, "")."""
    line = sys.stdin.buffer.readline()
    if not line:
        return None, ""
    stripped = line.strip()
    if stripped.lower().startswith(b"content-length:"):
        length = int(stripped.split(b":", 1)[1].strip())
        while True:
            header = sys.stdin.buffer.readline()
            if not header or header.strip() == b"":
                break
        body = sys.stdin.buffer.read(length)
        return json.loads(body), "content-length"
    return json.loads(stripped), "newline-json"


def write_response(message: dict, protocol: str) -> None:
    payload = json.dumps(message, ensure_ascii=False).encode("utf-8")
    if protocol == "content-length":
        sys.stdout.buffer.write(f"Content-Length: {len(payload)}\r\n\r\n".encode("utf-8") + payload)
    else:
        sys.stdout.buffer.write(payload + b"\n")
    sys.stdout.buffer.flush()


def handle(method: str, params: dict) -> tuple[dict | None, dict | None]:
    """返回 (result, error)。error 非 None 表示 JSON-RPC 协议错误。"""
    if method == "initialize":
        return {"protocolVersion": "2024-11-05", "capabilities": {}, "serverInfo": {"name": "fake", "version": "1.0"}}, None
    if method == "tools/list":
        return {"tools": [
            {
                "name": "echo",
                "description": "Echo the input text back",
                "inputSchema": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
            }
        ]}, None
    if method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments", {}) or {}
        if name == "echo":
            return {"content": [{"type": "text", "text": f"echo: {arguments.get('text', '')}"}]}, None
        # 业务错误：用 isError 而非 JSON-RPC error（客户端据此置 ToolResult.ok=False）
        return {"isError": True, "content": [{"type": "text", "text": f"unknown tool {name}"}]}, None
    if method == "resources/list":
        return {"resources": [{"uri": "file:///demo/readme", "name": "demo", "description": "A demo resource"}]}, None
    if method == "resources/read":
        return {"contents": [{"uri": params.get("uri", ""), "text": "demo resource content"}]}, None
    if method == "prompts/list":
        return {"prompts": [{"name": "greet", "description": "A greeting prompt", "arguments": [{"name": "who", "required": False}]}]}, None
    if method == "prompts/get":
        who = (params.get("arguments") or {}).get("who", "world")
        return {"description": "greet", "messages": [{"role": "user", "content": f"hello {who}"}]}, None
    return None, {"code": -32601, "message": f"unknown method {method}"}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--exit-after", type=int, default=0, help="处理 N 个请求后退出")
    parser.add_argument("--delay", type=float, default=0.0, help="每个请求前 sleep 秒数")
    args = parser.parse_args()

    count = 0
    while True:
        request, protocol = read_request()
        if request is None:
            break
        if request.get("method") == "notifications/initialized":
            continue  # notification 无响应
        if args.delay:
            time.sleep(args.delay)
        result, error = handle(request.get("method", ""), request.get("params", {}))
        body = {"jsonrpc": "2.0", "id": request.get("id")}
        if error is not None:
            body["error"] = error
        else:
            body["result"] = result
        write_response(body, protocol)
        count += 1
        if args.exit_after and count >= args.exit_after:
            break


if __name__ == "__main__":
    main()
