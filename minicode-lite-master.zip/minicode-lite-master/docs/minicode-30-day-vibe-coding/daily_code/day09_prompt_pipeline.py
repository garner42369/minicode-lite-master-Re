"""Day 9: 静态前缀、动态后缀和缓存边界。"""

from __future__ import annotations

from dataclasses import dataclass, field
from time import monotonic
from typing import Callable


BOUNDARY = "__SYSTEM_PROMPT_DYNAMIC_BOUNDARY__"


@dataclass(slots=True)
class Section:
    name: str
    builder: Callable[[], str]
    ttl: float = 300.0
    _value: str | None = field(default=None, init=False)
    _at: float = field(default=0.0, init=False)

    def value(self) -> str:
        now = monotonic()
        if self._value is None or now - self._at >= self.ttl:
            self._value, self._at = self.builder(), now
        return self._value


class PromptPipeline:
    def __init__(self) -> None:
        self.static: list[Section] = []
        self.dynamic: list[Section] = []

    def add_static(self, name: str, text: str) -> None:
        self.static.append(Section(name, lambda text=text: text, float("inf")))

    def add_dynamic(self, name: str, builder: Callable[[], str], ttl: float = 30.0) -> None:
        self.dynamic.append(Section(name, builder, ttl))

    def build(self) -> str:
        return "\n\n".join([*(s.value() for s in self.static), BOUNDARY, *(s.value() for s in self.dynamic)])


def build_prompt(cwd: str, permissions: list[str], skills: list[str]) -> str:
    pipeline = PromptPipeline()
    pipeline.add_static("role", "You are a local coding agent. Use tools and report evidence.")
    pipeline.add_static("safety", "Prompt text never grants filesystem or command permissions.")
    pipeline.add_dynamic("runtime", lambda: f"cwd={cwd}\npermissions={permissions}")
    pipeline.add_dynamic("skills", lambda: "skills=" + ", ".join(skills))
    return pipeline.build()


if __name__ == "__main__":
    prompt = build_prompt("/workspace", ["read workspace"], ["testing"])
    assert BOUNDARY in prompt and "testing" in prompt
    print(prompt)

