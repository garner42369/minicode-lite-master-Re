"""V0.1 可靠性验证的运行时装配脚本。

Day 14 之后、Day 21 之前的临时装配入口：把 config + 真实 DeepSeek + 工具 +
权限 + Loop + Kernel 串起来，接收一个任务指令，跑完整闭环，返回结果与停止
原因。用于连续跑 15 个任务、记录失败模式。

运行（项目根目录）：
    python tests/v01_harness.py "<任务指令>" --cwd <工作目录>
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.agent_loop import run_agent_turn
from minicode.config import load_runtime_config
from minicode.cost_tracker import CostTracker
from minicode.model_registry import build_adapter
from minicode.permissions import Mode, PermissionDecision, PermissionManager, RiskLevel
from minicode.prompt import build_prompt
from minicode.task_object import build_task_object
from minicode.tools import create_full_tool_registry


def run_task(task_text: str, cwd: str, *, mode: Mode = Mode.AUTO):
    """跑一个任务，返回 (history, stop_reason, cost_totals)。"""
    config = load_runtime_config()
    tools = create_full_tool_registry()
    tracker = CostTracker()
    adapter = build_adapter(config, tools=tools.list(), cost_tracker=tracker)

    # 自动化验证：auto 模式 + 自动允许（审批体验单独观察，这里不卡在交互上）。
    # 但模拟真实用户：危险命令（dangerous）默认拒绝，不放行 rm -rf 这类破坏性操作。
    def prompt(request):
        if request.risk is RiskLevel.DANGEROUS:
            print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> deny")
            return PermissionDecision("deny_once")
        print(f"    [审批] {request.kind.value}:{request.scope} (risk={request.risk.value}) -> allow")
        return PermissionDecision("allow_once")

    permissions = PermissionManager(cwd, mode, prompt=prompt)
    task = build_task_object(task_text, model=adapter)

    messages = [
        {"role": "system", "content": build_prompt(cwd)},
        {"role": "user", "content": task_text},
    ]

    history, stop = run_agent_turn(
        adapter,
        tools,
        messages,
        cwd,
        task=task,
        permissions=permissions,
        on_tool_start=lambda c: print(f"    [工具] {c.name}({c.arguments})"),
        on_tool_result=lambda c, r: print(f"    [工具结果] {c.name} ok={r.ok}"),
        on_nudge=lambda n: print(f"    [Kernel拦截] {n}"),
    )
    return history, stop, tracker.totals()


def main():
    parser = argparse.ArgumentParser(description="V0.1 可靠性验证装配脚本")
    parser.add_argument("task", help="任务指令")
    parser.add_argument("--cwd", default=".", help="工作目录")
    args = parser.parse_args()

    history, stop, totals = run_task(args.task, args.cwd)
    print(f"\n=== 结果 ===")
    print(f"  stop_reason: {stop}")
    print(f"  最终回答: {history[-1]['content'][:500]}")
    print(f"  成本: 调用 {totals.calls} 次, 输入 {totals.input_tokens}, 输出 {totals.output_tokens}, ${totals.cost_usd:.6f}")


if __name__ == "__main__":
    main()
