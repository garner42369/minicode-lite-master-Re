"""Day 7：最小 Agent Loop 闭环的契约测试。"""

from pathlib import Path

import minicode.agent_loop as loop_module

from minicode.agent_loop import run_agent_turn
from minicode.intent_parser import Intent
from minicode.mock_model import ScriptedModel
from minicode.task_object import TaskObject
from minicode.tools import create_core_tool_registry
from minicode.types import AgentStep, ChatMessage, ToolCall


class TestAgentLoop:
    def test_final_answer_returns_done(self):
        model = ScriptedModel([AgentStep(type="assistant", kind="final", content="完成")])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], "."
        )
        assert stop_reason == "done"
        assert history[-1]["role"] == "assistant"
        assert history[-1]["content"] == "完成"

    def test_tool_result_is_fed_back(self, tmp_path: Path):
        # 核心验收：第二次模型调用收到第一次工具结果
        (tmp_path / "a.txt").write_text("hello", encoding="utf-8")
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "list_files", {"path": "."})]),
            AgentStep(type="tool_calls", calls=[ToolCall("2", "read_file", {"path": "a.txt"})]),
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "侦察"}], str(tmp_path)
        )
        assert stop_reason == "done"
        # 第二次模型调用收到的历史里，包含第一次工具的结果
        second_call_messages = model.received_messages[1]
        assert any(m.get("role") == "tool_result" for m in second_call_messages)
        print("\n=== 完整历史（模型—工具—模型闭环）===")
        for m in history:
            print(m)

    def test_tool_failure_is_fed_back(self, tmp_path: Path):
        # 工具失败（未知工具）也回填，模型有机会改正
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "no_such_tool", {})]),
            AgentStep(type="assistant", kind="final", content="我改一下"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "做点事"}], str(tmp_path)
        )
        tool_results = [m for m in history if m.get("role") == "tool_result"]
        assert tool_results[0]["is_error"] is True

    def test_progress_does_not_end_loop(self):
        model = ScriptedModel([
            AgentStep(type="assistant", kind="progress", content="正在处理…"),
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], "."
        )
        assert stop_reason == "done"
        roles = [m["role"] for m in history]
        assert "assistant_progress" in roles  # 进度消息在历史里
        assert roles[-1] == "assistant"       # 最终回答正常结束

    def test_max_steps_stops_without_extra_call(self):
        # 3 个 progress 步骤，max_steps=2 → 只调 2 次，无第 3 次请求
        model = ScriptedModel([
            AgentStep(type="assistant", kind="progress", content="p1"),
            AgentStep(type="assistant", kind="progress", content="p2"),
            AgentStep(type="assistant", kind="progress", content="p3"),
        ])
        history, stop_reason = run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "hi"}], ".", max_steps=2
        )
        assert stop_reason == "max_steps"
        assert len(model.received_messages) == 2  # 没有第 3 次模型请求

    def test_input_messages_not_mutated(self):
        messages: list[ChatMessage] = [{"role": "user", "content": "hi"}]
        model = ScriptedModel([AgentStep(type="assistant", kind="final", content="done")])
        run_agent_turn(model, create_core_tool_registry(), messages, ".")
        assert messages == [{"role": "user", "content": "hi"}]  # 调用方列表不被污染

    def test_callbacks_fire(self, tmp_path: Path):
        (tmp_path / "a.txt").write_text("hi", encoding="utf-8")
        events: list[str] = []
        model = ScriptedModel([
            AgentStep(type="tool_calls", calls=[ToolCall("1", "list_files", {"path": "."})]),
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        run_agent_turn(
            model, create_core_tool_registry(), [{"role": "user", "content": "侦察"}], str(tmp_path),
            on_tool_start=lambda c: events.append(f"start:{c.name}"),
            on_tool_result=lambda c, r: events.append(f"result:{c.name}"),
            on_assistant_message=lambda s: events.append(f"msg:{s.type}"),
        )
        assert "start:list_files" in events
        assert "result:list_files" in events
        assert "msg:assistant" in events

    def test_on_compact_fires_when_compacting(self, monkeypatch):
        # 降低压缩阈值，让短历史也能触发压缩（正常 128k 阈值测试造不出来）
        monkeypatch.setattr(loop_module, "DEFAULT_CONTEXT_WINDOW", 50)
        monkeypatch.setattr(loop_module, "_COMPACT_RATIO", 0.5)
        monkeypatch.setattr(loop_module, "_COMPACT_KEEP_RECENT", 2)

        events: list[dict] = []
        task = TaskObject(goal="侦察", intent=Intent.SEARCH)
        model = ScriptedModel([
            AgentStep(type="assistant", kind="final", content="完成"),
        ])
        # 5 条 user 消息，总 token 超阈值，触发压缩
        messages = [{"role": "user", "content": "x" * 1000} for _ in range(5)]
        history, stop = run_agent_turn(
            model, create_core_tool_registry(), messages, ".",
            task=task, on_compact=lambda e: events.append(e),
        )
        print(f"\n压缩事件: {events}")
        assert stop == "done"
        assert len(events) >= 1
        assert events[0]["type"] == "compaction"
        assert events[0]["strategy"] == "full"
        assert events[0]["messages_removed"] > 0
        assert events[0]["tokens_after"] < events[0]["tokens_before"]
        assert len(messages) == 5  # 原始完整历史不被压缩覆盖，供持久化到 Session
