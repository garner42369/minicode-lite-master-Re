"""Day 17：context_manager 的契约测试。"""

from minicode.context_manager import (
    ContextStats,
    context_window_for,
    estimate_tokens,
    threshold_events,
)


class TestEstimateTokens:
    def test_ascii_and_cjk(self):
        # ASCII 约 4 字符/token，CJK 约 1 字/token
        ascii_tokens = estimate_tokens("a" * 40)
        cjk_tokens = estimate_tokens("你" * 10)
        print(f"ascii(40字符)={ascii_tokens}, cjk(10字)={cjk_tokens}")
        assert ascii_tokens == 10  # 40 // 4
        assert cjk_tokens == 10    # 10 字


class TestContextStats:
    def test_usage_ratio_reserves_output(self):
        # 预留输出后，使用率按「可用窗口」算，不是按整个窗口
        stats = ContextStats(70_000, 100_000, 20_000)
        print(f"usage_ratio={stats.usage_ratio}")
        assert stats.usage_ratio == 0.875  # 70000 / (100000 - 20000)


class TestThresholdEvents:
    def test_fires_once_per_threshold(self):
        # 核心契约：同一阈值只触发一次，不刷屏
        fired = set()
        events = threshold_events(ContextStats(60_000, 100_000, 0), fired)
        events += threshold_events(ContextStats(60_000, 100_000, 0), fired)  # 重复，不应再触发
        print(f"events={events}")
        assert len(events) == 1  # 只触发 50% 一次


class TestContextWindowFor:
    def test_known_and_unknown_model(self):
        print(f"known={context_window_for('deepseek-v4-pro')}, unknown={context_window_for('x')}")
        assert context_window_for("deepseek-v4-pro") == 1_000_000
        assert context_window_for("unknown") == 128_000
