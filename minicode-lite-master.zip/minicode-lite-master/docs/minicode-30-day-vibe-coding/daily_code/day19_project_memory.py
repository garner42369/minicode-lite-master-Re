"""Day 19: 有 scope、来源、有效状态和关键词评分的项目记忆。"""

from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path


@dataclass(slots=True)
class MemoryEntry:
    id: str
    content: str
    scope: str
    source: str
    tags: list[str]
    confidence: float
    valid: bool
    updated_at: float


class MemoryStore:
    def __init__(self, path: Path, workspace_id: str) -> None:
        self.path, self.workspace_id = path, workspace_id
        self.entries = self._load()

    def _load(self) -> list[MemoryEntry]:
        if not self.path.exists():
            return []
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if data.get("workspace_id") != self.workspace_id:
            raise ValueError("memory belongs to another workspace")
        return [MemoryEntry(**item) for item in data.get("entries", [])]

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"workspace_id": self.workspace_id, "entries": [asdict(e) for e in self.entries]}
        self.path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    def add(self, content: str, source: str, tags: list[str]) -> MemoryEntry:
        if re.search(r"(?i)(api[_ -]?key|password|secret)\s*[:=]", content):
            raise ValueError("refusing to store possible secret")
        entry = MemoryEntry(uuid.uuid4().hex, content, "project", source, tags, 1.0, True, time.time())
        self.entries.append(entry)
        return entry

    def search(self, query: str, limit: int = 5) -> list[MemoryEntry]:
        terms = set(re.findall(r"\w+", query.lower()))
        ranked = []
        for entry in self.entries:
            if not entry.valid:
                continue
            haystack = set(re.findall(r"\w+", (entry.content + " " + " ".join(entry.tags)).lower()))
            score = len(terms & haystack) * entry.confidence
            if score:
                ranked.append((score, entry.updated_at, entry))
        ranked.sort(reverse=True, key=lambda row: (row[0], row[1]))
        return [entry for _, _, entry in ranked[:limit]]


if __name__ == "__main__":
    import tempfile

    with tempfile.TemporaryDirectory() as directory:
        store = MemoryStore(Path(directory) / "memory.json", "workspace-A")
        store.add("项目测试命令是 pytest -q", "README.md", ["test", "pytest"])
        assert store.search("pytest test")
        store.save()
        assert MemoryStore(store.path, "workspace-A").entries
        print("project memory: OK")

