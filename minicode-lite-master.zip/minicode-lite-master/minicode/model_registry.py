"""minicode 的模型注册表：模型元数据、Provider 检测与 Adapter 工厂。

Day 10 引入。把「选哪个模型、走哪个 Provider、怎么建 Adapter」集中到一处，
让上层（入口/装配）只需根据配置拿到一个可用的 ModelAdapter，不关心细节。

关键约束（课件「今日易错点」）：模型目录里的价格、上下文窗口、模型名会
随时间变化，必须视为「可更新配置」，不能让正确性依赖某个永远不变的静态表。
所以这里用普通 dict 存目录；价格/窗口都是可覆盖的默认值，目录里查不到的
模型降级为 0（不计价、不限制），而不是抛错——宁可少算成本，也不能因目录
过期而让真实调用失败。
"""

from __future__ import annotations

from dataclasses import dataclass

from minicode.config import RuntimeConfig
from minicode.cost_tracker import CostTracker
from minicode.openai_adapter import OpenAIAdapter
from minicode.tooling import ToolDefinition
from minicode.types import ModelAdapter

# Provider 标识：OpenAI 兼容协议 vs Anthropic 原生协议
PROVIDER_OPENAI = "openai"
PROVIDER_ANTHROPIC = "anthropic"


@dataclass(frozen=True, slots=True)
class ModelInfo:
    """一个模型的静态元数据。价格/窗口视为可更新配置，非不可变事实。"""

    name: str                      # API 模型名，如 deepseek-v4-pro
    provider: str                  # 走哪个协议："openai" / "anthropic"
    context_window: int = 0        # 上下文窗口（token），0 表示未知
    input_price_per_mtok: float = 0.0    # 输入价 USD / 1M tokens
    output_price_per_mtok: float = 0.0   # 输出价 USD / 1M tokens


# 模型目录：当前只录入 DeepSeek V4 两个型号（价格参考官方 2026-10 定价）。
# 这里是「默认值」而非「事实来源」——价格变化时只需改这里，不影响调用正确性。
MODEL_CATALOG: dict[str, ModelInfo] = {
    "deepseek-v4-pro": ModelInfo(
        name="deepseek-v4-pro",
        provider=PROVIDER_OPENAI,
        context_window=1_000_000,
        input_price_per_mtok=1.74,
        output_price_per_mtok=3.48,
    ),
    "deepseek-v4-flash": ModelInfo(
        name="deepseek-v4-flash",
        provider=PROVIDER_OPENAI,
        context_window=1_000_000,
        input_price_per_mtok=0.14,
        output_price_per_mtok=0.28,
    ),
}


def detect_provider(model: str, base_url: str = "") -> str:
    """判断一个模型走哪个 Provider 协议。

    判定顺序：目录里显式声明的 provider 最优先；否则按 base_url 关键字猜测；
    最后退回 OpenAI 兼容（覆盖面最广）。
    """
    info = MODEL_CATALOG.get(model)
    if info is not None:
        return info.provider
    if "anthropic" in base_url:
        return PROVIDER_ANTHROPIC
    return PROVIDER_OPENAI


def build_adapter(
    config: RuntimeConfig,
    *,
    tools: list[ToolDefinition] | None = None,
    cost_tracker: CostTracker | None = None,
) -> ModelAdapter:
    """根据 RuntimeConfig 构造一个可用的 ModelAdapter。

    - model == "mock"：返回离线 MockModelAdapter（保留 Day 4 的离线路径）；
    - 真实模型：按 provider 分发到对应 Adapter，并把目录里的价格传给 Adapter
      用于成本折算。
    """
    if config.model == "mock":
        from minicode.mock_model import MockModelAdapter

        return MockModelAdapter()

    # 真实模型必须有 base_url，否则请求 URL 会拼错。这是系统边界（配置来自
    # 外部 .env），尽早用清晰错误暴露，而不是等请求发出后报难懂的 URLError。
    if not config.base_url:
        raise ValueError("base_url is required for a real model (set MINI_CODE_BASE_URL)")

    provider = detect_provider(config.model, config.base_url)
    info = MODEL_CATALOG.get(config.model)
    input_price = info.input_price_per_mtok if info else 0.0
    output_price = info.output_price_per_mtok if info else 0.0

    if provider == PROVIDER_ANTHROPIC:
        # 第二个 Provider 推迟实现：没有 Anthropic 凭据时无法做「真实模型测试」，
        # 写了不测违背本项目约定。等有凭据时再补，且届时真实验证。
        raise NotImplementedError(
            "Anthropic adapter is not implemented yet; provide credentials and enable real testing first."
        )

    return OpenAIAdapter(
        model=config.model,
        base_url=config.base_url,
        api_key=config.api_key,
        tools=tools,
        cost_tracker=cost_tracker,
        input_price_per_mtok=input_price,
        output_price_per_mtok=output_price,
    )
