"""Day 15: 可版本化、原子写入的最小 Session Store。"""

from __future__ import annotations

import json
import os
import tempfile
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


SCHEMA_VERSION = 1


@dataclass(slots=True)
class SessionData:
    session_id: str
    workspace: str
    created_at: float
    updated_at: float
    messages: list[dict[str, Any]] = field(default_factory=list)
    events: list[dict[str, Any]] = field(default_factory=list)
    checkpoints: list[dict[str, Any]] = field(default_factory=list)
    schema_version: int = SCHEMA_VERSION

    @classmethod
    def create(cls, workspace: str) -> "SessionData":
        now = time.time()
        return cls(uuid.uuid4().hex, str(Path(workspace).resolve()), now, now)


def save_session(session: SessionData, directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    session.updated_at = time.time()
    target = directory / f"{session.session_id}.json"
    fd, temporary = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(asdict(session), handle, ensure_ascii=False, indent=2)
        os.replace(temporary, target)
    except Exception:
        Path(temporary).unlink(missing_ok=True)
        raise
    return target


def load_session(path: Path) -> SessionData:
    data = json.loads(path.read_text(encoding="utf-8"))
    if data.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported session schema")
    return SessionData(**data)


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as directory:
        session = SessionData.create(".")
        session.messages.append({"role": "user", "content": "hello"})
        path = save_session(session, Path(directory))
        assert load_session(path).messages == session.messages
        print(path.name)

