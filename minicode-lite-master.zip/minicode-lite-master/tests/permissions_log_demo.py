"""Day 11 权限决策脱敏日志演示。

运行（项目根目录）：
    python tests/permissions_log_demo.py

展示 PermissionManager.check() 如何把决策写入脱敏日志：允许走 debug、拒绝走
warning、超长反馈被截断到 80 字符。日志输出到 stderr（print 在 stdout，两路
会交错显示，属正常）。
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.logging_config import setup_logging
from minicode.permissions import (
    Mode,
    PermissionDecision,
    PermissionKind,
    PermissionManager,
    PermissionRequest,
    RiskLevel,
)


def main():
    # DEBUG 级别让「允许」的 debug 日志也显示；log_to_file=False 避免落盘副作用
    setup_logging(level="DEBUG", log_to_file=False)

    read_req = PermissionRequest(PermissionKind.PATH, "README.md", "读文件", RiskLevel.SAFE)
    write_req = PermissionRequest(PermissionKind.PATH, "README.md", "写文件", RiskLevel.MEDIUM)

    print("== auto 模式：读(允许，debug 日志) + 写(拒绝，warning 日志) ==")
    auto = PermissionManager(".", Mode.AUTO)
    auto.check(read_req)
    auto.check(write_req)

    print("\n== deny_with_feedback：超长反馈被截断到 80 字符 ==")
    long_feedback = "这个文件受保护，请改用只读方式处理它" * 8  # 远超 80 字符

    def deny_ask(request):
        return PermissionDecision("deny_with_feedback", long_feedback)

    deny_mgr = PermissionManager(".", Mode.DEFAULT, prompt=deny_ask)
    deny_mgr.check(write_req)
    print(f"(原始反馈长度 {len(long_feedback)}，日志里只记前 80 字符)")


if __name__ == "__main__":
    main()
