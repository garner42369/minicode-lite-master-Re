"""Day 22: TUI 只消费类型化 Runtime Event，并通过 reducer 更新状态。"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass(frozen=True, slots=True)
class RuntimeEvent:
    type: Literal["assistant_delta", "progress", "tool_start", "tool_result", "turn_done", "turn_error"]
    text: str = ""
    tool_name: str = ""
    call_id: str = ""
    ok: bool | None = None


@dataclass(slots=True)
class TranscriptEntry:
    kind: str
    body: str
    status: str = ""
    call_id: str = ""


@dataclass(slots=True)
class ScreenState:
    transcript: list[TranscriptEntry] = field(default_factory=list)
    streaming_text: str = ""
    busy: bool = False


def reduce_event(state: ScreenState, event: RuntimeEvent) -> ScreenState:
    if event.type == "assistant_delta":
        state.streaming_text += event.text
    elif event.type == "progress":
        state.transcript.append(TranscriptEntry("progress", event.text))
    elif event.type == "tool_start":
        state.busy = True
        state.transcript.append(TranscriptEntry("tool", event.tool_name, "running", event.call_id))
    elif event.type == "tool_result":
        for entry in reversed(state.transcript):
            if entry.call_id == event.call_id:
                entry.body += "\n" + event.text
                entry.status = "success" if event.ok else "error"
                break
    elif event.type in {"turn_done", "turn_error"}:
        if state.streaming_text:
            state.transcript.append(TranscriptEntry("assistant", state.streaming_text))
            state.streaming_text = ""
        state.busy = False
    return state


if __name__ == "__main__":
    state = ScreenState()
    reduce_event(state, RuntimeEvent("tool_start", tool_name="read_file", call_id="c1"))
    reduce_event(state, RuntimeEvent("tool_result", text="FILE: demo.py", call_id="c1", ok=True))
    assert state.transcript[0].status == "success"
    print(state.transcript)

