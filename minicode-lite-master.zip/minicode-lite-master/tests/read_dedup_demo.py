"""Day 17 ReadDedup 演示：重复读取去重 + 文件变化失效。

运行（项目根目录）：
    python tests/read_dedup_demo.py
"""

import sys
from pathlib import Path

# 把项目根加入 sys.path（命令行直接运行时会找不到 minicode 包）
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

from minicode.context_compactor import ReadDedupManager


def main():
    dedup = ReadDedupManager()

    # 1. 第一次读
    text, is_dup = dedup.process("a.py", "hello content")
    print(f"第一次读:     {text!r}  去重={is_dup}")

    # 2. 相同内容重复读 → stub
    text, is_dup = dedup.process("a.py", "hello content")
    print(f"重复读:       {text!r}  去重={is_dup}")

    # 3. 文件变化后读 → 返回新内容（失效）
    text, is_dup = dedup.process("a.py", "changed content")
    print(f"变化后读:     {text!r}  去重={is_dup}")


if __name__ == "__main__":
    main()
