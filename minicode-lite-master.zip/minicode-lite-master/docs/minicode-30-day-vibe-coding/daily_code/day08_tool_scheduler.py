"""Day 8: 只读工具并发、有副作用工具串行，结果恢复原顺序。"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from time import perf_counter

from day02_protocols import ToolCall, ToolResult
from day05_tool_registry import ToolContext, ToolRegistry


@dataclass(slots=True)
class ToolMetric:
    name: str
    duration_ms: float
    ok: bool


@dataclass(slots=True)
class SchedulerResult:
    observations: list[tuple[ToolCall, ToolResult]]
    metrics: list[ToolMetric] = field(default_factory=list)


def execute_calls(calls: list[ToolCall], registry: ToolRegistry, context: ToolContext) -> SchedulerResult:
    indexed = list(enumerate(calls))
    parallel = [(i, call) for i, call in indexed if (tool := registry.find(call.name)) and tool.concurrency_safe]
    serial = [(i, call) for i, call in indexed if not ((tool := registry.find(call.name)) and tool.concurrency_safe)]
    completed: dict[int, tuple[ToolCall, ToolResult]] = {}
    metrics: list[ToolMetric] = []

    def run(item: tuple[int, ToolCall]) -> tuple[int, ToolCall, ToolResult, float]:
        index, call = item
        started = perf_counter()
        result = registry.execute(call.name, call.arguments, context)
        return index, call, result, (perf_counter() - started) * 1000

    if parallel:
        with ThreadPoolExecutor(max_workers=min(4, len(parallel))) as pool:
            futures = [pool.submit(run, item) for item in parallel]
            for future in as_completed(futures):
                index, call, result, duration = future.result()
                completed[index] = (call, result)
                metrics.append(ToolMetric(call.name, duration, result.ok))
    for item in serial:
        index, call, result, duration = run(item)
        completed[index] = (call, result)
        metrics.append(ToolMetric(call.name, duration, result.ok))
    return SchedulerResult([completed[i] for i in range(len(calls))], metrics)


if __name__ == "__main__":
    from day05_tool_registry import ECHO

    calls = [ToolCall("2", "echo", {"text": "B"}), ToolCall("1", "echo", {"text": "A"})]
    result = execute_calls(calls, ToolRegistry([ECHO]), ToolContext("."))
    assert [call.id for call, _ in result.observations] == ["2", "1"]
    print([observation.output for _, observation in result.observations])

